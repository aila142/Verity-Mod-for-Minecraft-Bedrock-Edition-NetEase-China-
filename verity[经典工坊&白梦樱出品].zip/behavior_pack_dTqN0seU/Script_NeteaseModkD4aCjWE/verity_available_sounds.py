# -*- coding: utf-8 -*-
# Auto-generated from sounds/*.ogg
SOUND_SLUGS = set([
    'bianyi',
    'chuchanger',
    'guaiwuchuxianyiyue',
    'guaiwujiao',
    'huhan',
    'jiancha',
    'jieshumama',
    'kaichang',
    'nabian',
    'nishiwode',
    'no',
    'santianhou',
    'shijierdedongxi',
    'shilai',
    'shoushang',
    'sihou',
    'tantiao',
    'xianzaixiaole',
    'ya',
    'yesnanbian',
    'yinyueyi',
    'yiyueer',
    'youdongxijingguo',
    'zhuangji',
])

VOICE_EVENT_BY_SLUG = {
    'bianyi': 'verity.voice.bianyi',
    'chuchanger': 'verity.voice.chuchanger',
    'guaiwuchuxianyiyue': 'verity.voice.guaiwuchuxianyiyue',
    'guaiwujiao': 'verity.voice.guaiwujiao',
    'huhan': 'verity.voice.huhan',
    'jiancha': 'verity.voice.jiancha',
    'jieshumama': 'verity.voice.jieshumama',
    'kaichang': 'verity.voice.kaichang',
    'nabian': 'verity.voice.nabian',
    'nishiwode': 'verity.voice.nishiwode',
    'no': 'verity.voice.no',
    'santianhou': 'verity.voice.santianhou',
    'shijierdedongxi': 'verity.voice.shijierdedongxi',
    'shilai': 'verity.voice.shilai',
    'shoushang': 'verity.voice.shoushang',
    'sihou': 'verity.voice.sihou',
    'tantiao': 'verity.voice.tantiao',
    'xianzaixiaole': 'verity.voice.xianzaixiaole',
    'ya': 'verity.voice.ya',
    'yesnanbian': 'verity.voice.yesnanbian',
    'yinyueyi': 'verity.voice.yinyueyi',
    'yiyueer': 'verity.voice.yiyueer',
    'youdongxijingguo': 'verity.voice.youdongxijingguo',
    'zhuangji': 'verity.voice.zhuangji',
}
