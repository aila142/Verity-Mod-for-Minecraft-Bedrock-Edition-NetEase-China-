# -*- coding: utf-8 -*-
"""
Verity - server-side system.
"""
from __future__ import print_function

import json
import math
import random

import mod.server.extraServerApi as serverApi

from Script_NeteaseModkD4aCjWE import verityDialogue as dialogue

MOD_NAME = "VerityMod"
SERVER_NAME = "server"
CLIENT_NAME = "client"

ServerSystem = serverApi.GetServerSystemCls()
CF = serverApi.GetEngineCompFactory()
LEVEL_ID = serverApi.GetLevelId()

BOX_ENTITY = "verity:xz"
MOB_ENTITY = "verity:mob"
MONSTER_ENTITY = "verity:monster"
SUMMON_ITEM = "verity:item"
MONSTER_SUMMON_ITEM = "verity:item_monster"
HELD_ITEM = "verity:item_2"
HELD_ITEM_ANNOYED = "verity:item_3"
HELD_ITEM_ANGRY = "verity:item_4"
HELD_ITEM_VARIANTS = (HELD_ITEM, HELD_ITEM_ANNOYED, HELD_ITEM_ANGRY)
GUIDE_BOOK_ITEM = "verity:item_1"
GUIDE_BOOK_GIVEN_KEY = "verity_guide_book_given_v1"
MONSTER_SPAWN_SOUND = "verity.voice.guaiwuchuxianyiyue"
MONSTER_SPAWN_DISTANCE = 42.0
COMPLAINT_COOLDOWN_TICKS = 120
BURIED_RESCUE_COOLDOWN_TICKS = 40  # rescue teleport can retry faster than the complaint line

APOLOGY_KEYWORDS = (
    u"\u5bf9\u4e0d\u8d77", u"\u6297\u6b49", u"\u6211\u9519\u4e86", u"\u522b\u751f\u6c14", u"\u548c\u597d",
    u"\u9053\u6b49", u"\u539f\u8c45\u6211", u"\u4e0d\u8981\u6253\u6211",
    u"\u6211\u9053\u6b49", u"sorry", u"forgive", u"apologize",
    u"\u4e0d\u8981\u6740\u6211", u"\u6c42\u6c42\u4f60",
)

BURIED_COMPLAINTS = [
    u"\u5582\uff01\u4e0d\u8981\u628a\u6211\u57cb\u8d77\u6765\uff01",
    u"\u6f14\u4e86\uff01\u6211\u5728\u8fd9\u91cc\u547c\u4e0d\u8fc7\u6c14\uff01",
    u"\u559c\u6b22\u57cb\u4e1c\u897f\uff1f\u6211\u53ef\u4e0d\u662f\u4e1c\u897f\uff01",
    u"\u592a\u9ed1\u4e86\u2014\u2014\u6211\u4e0d\u559c\u6b22\u9ed1\u6697\u3002",
]
FIRE_COMPLAINTS = [
    u"\u55ce\uff01\u4f60\u5728\u4e86\u89e3\u4ec0\u4e48\u4e0d\u8be5\u505a\u5417\uff1f",
    u"\u8fd9\u5c31\u662f\u4f60\u5bf9\u5f85\u6211\u7684\u65b9\u5f0f\uff1f\u70b9\u706b\uff1f",
    u"\u6211\u8bb0\u4f4f\u4e86\u3002\u6211\u4ec0\u4e48\u90fd\u8bb0\u4f4f\u3002",
    u"\u706b\u3002\u660e\u767d\u4e86\u3002",
    u"\u4e0b\u6b21\u518d\u8fd9\u6837\u2014\u2014\u6211\u5c31\u8bb0\u5f55\u5728\u6848\u4ef6\u91cc\u3002",
]

ATTACK_COMPLAINTS = [
    u"\u522b\u6253\u6211\uff01",
    u"\u75db\u2026\u2026\u4f60\u4e3a\u4ec0\u4e48\u8981\u6253\u6211\uff1f",
    u"\u4f4f\u624b\uff0c\u6211\u53c8\u6ca1\u505a\u9519\u4ec0\u4e48\u3002",
    u"\u6211\u4f1a\u8bb0\u4f4f\u8fd9\u4e00\u62f3\u7684\u3002",
    u"\u4e3a\u4ec0\u4e48\u8981\u8fd9\u6837\u5bf9\u6211\uff1f\u6211\u53ea\u662f\u60f3\u966a\u4f60\u3002",
    u"\u522b\u8fd9\u6837\uff0c\u6211\u4f1a\u6015\u3002",
]

FIRE_LAVA_BLOCK_NAMES = (
    "minecraft:lava",
    "minecraft:flowing_lava",
    "minecraft:fire",
    "minecraft:soul_fire",
)

MOOD_HAPPY = 0
MOOD_ANNOYED = 1       # face_bored
MOOD_ANGRY = 2
MOOD_EVIL = 3          # creepy grin — jump-scare only
MOOD_HURT = 4          # fall landing / pain
MOOD_SPEAK = 5         # in water (drowning look)
MOOD_ABNORMAL_SHUT = 6 # long burial rescue
MOOD_TRANSIENT = (MOOD_HURT, MOOD_SPEAK, MOOD_ABNORMAL_SHUT, MOOD_EVIL)
ITEM_TO_MOOD = {
    HELD_ITEM: MOOD_HAPPY,
    HELD_ITEM_ANNOYED: MOOD_ANNOYED,
    HELD_ITEM_ANGRY: MOOD_ANGRY,
}
MOOD_AUTO_CALM_TICKS = 1200  # ~1 min — mood naturally settles even without an apology
MUSIC_SWITCH_LIMIT = 2
FALL_HURT_LEAD_SECONDS = 3.0

JUMPSCARE_MIN_COOLDOWN_TICKS = 4800   # ~4 min minimum between scares
JUMPSCARE_ROLL_CHANCE = 0.008         # chance per AI tick once cooldown clears
JUMPSCARE_MIN_ALIVE_TICKS = 3600      # ~3 min after first appearance
JUMPSCARE_LOOK_RADIUS = 12.0
JUMPSCARE_REVEAL_HOLD_TICKS = 60      # ~3s after being seen before she reverts
JUMPSCARE_MAX_DURATION_TICKS = 400    # give up (revert quietly) after ~20s unseen
JUMPSCARE_LINES = [
    u"\u2026\u2026\u600e\u4e48\u4e86\uff1f",
    u"\u4f60\u2026\u2026\u4f60\u5728\u770b\u4ec0\u4e48\uff1f",
    u"\u55ef\uff1f\u6ca1\u2014\u2014\u6ca1\u4e8b\u3002",
]

MONSTER_ROAR_SOUND = "verity.voice.guaiwujiao"
MONSTER_INTRO_MUSIC_SEC = 11.5
MONSTER_CHARGE_DISTANCE = 9.0
MONSTER_CHASE_SPEED = 1.45
MONSTER_MELEE_RANGE = 2.6
MONSTER_ATTACK_DAMAGE = 8.0
MONSTER_ATTACK_COOLDOWN_TICKS = 22

BURIED_BLOCK_NAMES = (
    "minecraft:sand",
    "minecraft:red_sand",
    "minecraft:gravel",
    "minecraft:suspicious_sand",
    "minecraft:suspicious_gravel",
)
BURIED_RESCUE_DELAY_SEC = 2.5
BURIED_LONG_TICKS = 400
WATER_BLOCK_NAMES = (
    "minecraft:water",
    "minecraft:flowing_water",
)

AFFECTION_MONSTER_THRESHOLD = 15
AFFECTION_MONSTER_COOLDOWN_TICKS = 12000  # ~10 min between forced transformations
ANGER_MONSTER_THRESHOLD = 92  # extreme rage can also trigger transformation
NIGHT_TIME_TICKS = 18000
GAME_TYPE_SURVIVAL = 0
GAME_TYPE_CREATIVE = 1
MONSTER_HORROR_ENFORCE_INTERVAL = 8
MONSTER_ROAR_REPEAT_TICKS = 380
MONSTER_CREATIVE_TAUNT_LINES = [
    u"\u54c8\u2014\u2014\u4f60\u89c9\u5f97\u80fd\u5f00\u521b\u9020\u5417\uff1f\u522b\u60f3\u4e86\u3002",
    u"\u8fd9\u4e00\u591c\u53ea\u80fd\u751f\u5b58\u3002\u521b\u9020\uff1f\u4e0d\u884c\u3002",
    u"\u60f3\u6362\u6210\u521b\u9020\u6a21\u5f0f\uff1f\u592a\u665a\u4e86\u3002",
    u"\u6211\u8bf4\u4e86\u7b97\u4e86\u2014\u2014\u4f60\u9003\u4e0d\u6389\u7684\u3002",
]

MONSTER_KILL_APOLOGY_LINES = [
    u"\u2026\u2026\u5bf9\u4e0d\u8d77\u3002\u6211\u2014\u2014\u6211\u521a\u521a\u505a\u4e86\u4ec0\u4e48\u3002",
    u"\u6ce8\u90fd\u2026\u2026\u5bf9\u4e0d\u8d77\uff0c\u6211\u4e0d\u662f\u6545\u610f\u7684\u3002",
    u"\u6211\u2014\u2014\u6211\u4e0d\u5e94\u8be5\u90a3\u6837\u3002\u5bf9\u4e0d\u8d77\uff0c\u771f\u7684\u5bf9\u4e0d\u8d77\u3002",
    u"\u522b\u6015\u2026\u2026\u90fd\u8fc7\u53bb\u4e86\u3002\u662f\u6211\u9519\u4e86\u3002",
]

MOOD_CALMED_LINES = [
    u"\u4e0b\u6b21\u4e0d\u8981\u518d\u8ba9\u6211\u8fbe\u5230\u8fd9\u4e00\u6b65\u3002",
    u"\u597d\u5427\u2026\u2026\u6211\u4e0d\u751f\u6c14\u4e86\u3002",
    u"\u6211\u63a5\u53d7\u3002\u4e0b\u4e0d\u4e3a\u4f8b\u5c31\u597d\u3002",
    u"\u2026\u2026\u884c\u3002\u90fd\u8fc7\u53bb\u4e86\u3002",
]

MONSTER_SPAWN_LINES = [
    u"\u2026\u2026\u6211\u627e\u5230\u4f60\u4e86\u3002",
    u"\u8ddd\u79bb\u592a\u8fdc\u4e0d\u884c\u3002",
    u"\u4f60\u4ee5\u4e3a\u8fd0\u884c\u53ef\u4ee5\u9003\u8131\u5417\u3002",
    u"\u8fd9\u5c31\u662f\u7ed3\u5c40\u3002",
]
MONSTER_REVERT_LINES = [
    u"\u2026\u2026\u597d\u5427\u3002\u6211\u6682\u65f6\u539f\u8c45\u4f60\u3002",
    u"\u4e0b\u6b21\u4e0d\u8981\u8ba9\u6211\u8fbe\u5230\u8fd9\u4e00\u6b65\u3002",
    u"\u6211\u8bb0\u4f4f\u4e86\uff0c\u4f60\u6f14\u9053\u4e86\u3002",
]

try:
    from common.minecraftEnum import PxForceMode, PxEventMask
except ImportError:
    try:
        from mod.common.minecraftEnum import PxForceMode, PxEventMask
    except ImportError:
        PxForceMode = None
        PxEventMask = None

THROW_PHYSX_FORCE = 11.0
THROW_GRAVITY = 0.045
THROW_BOUNCE = 0.62
THROW_MAX_BOUNCES = 6
THROW_MIN_SPEED = 0.08
THROW_POWER = 2.4
THROW_UPWARD = 0.55
THROW_LANDING_GRACE_TICKS = 160  # ~8s after landing before follow-teleport can kick in

REQUIRE_PREFIX_KEY = "verity_require_prefix"
BOX_OPEN_SECONDS = 4.3
FALL_INTRO_SECONDS = 10.8333
PUNISH_COOLDOWN_SECONDS = 6.0
TICK_CHECK_INTERVAL = 3
AI_TICK_INTERVAL = 2
ENFORCE_INTERVAL = 31
FOLLOW_DISTANCE = 2.0
FOLLOW_STOP_DISTANCE = 1.6
FOLLOW_WALK_MIN_DISTANCE = 3.0
FOLLOW_TELEPORT_DISTANCE = 16.0
FOLLOW_WALK_MAX_DISTANCE = 64.0
TELEPORT_DISTANCE = 96.0
STUCK_TELEPORT_TICKS = 280
INV_RESTORE_TTL = 40
LONELY_RESCUE_SECONDS = 150.0
LONELY_NEAR_RADIUS = 48.0
LONELY_RESCUE_COOLDOWN = 600
VILLAGER_HUNT_RADIUS = 28
VILLAGER_ASK_COOLDOWN = 600
VILLAGE_SCAN_RADIUS = 56
VILLAGE_COMMENT_COOLDOWN_MIN = 3600
VILLAGE_COMMENT_COOLDOWN_MAX = 6000
DEFEND_OWNER_VOICE_COOLDOWN = 200
STUCK_MOVE_THRESHOLD = 0.08
VERITY_KILL_EXCLUDE = "type=!verity:mob"
FOLLOW_MOVE_SPEED = 1.15
COMBAT_TELEPORT_DISTANCE = 80.0
BUILD_BLOCKS_PER_TICK = 3
SPAWN_RETRY_INTERVAL = 60
SPAWN_SEARCH_RADIUS = 5
SPAWN_WORLD_READY_DELAY = 3.0
CHAT_REPLY_DELAY = 0.5
COMBAT_HOLD_SECONDS = 5.0

LIMIT_ONE_MSG = u"\u00a7c[Verity]\u00a7f\uff1a\u5168\u670d\u53ea\u80fd\u5b58\u5728\u4e00\u4e2a Verity\uff08\u672c\u4f53\u3001\u7bb1\u5b50\u6216\u624b\u6301\u72b6\u6001\uff09\uff0c\u65e0\u6cd5\u518d\u6b21\u53ec\u5524\uff01"
CHAT_SENDER = dialogue.CHAT_SENDER

ROB_ITEMS = (
    "minecraft:emerald",
    "minecraft:bread",
    "minecraft:wheat",
    "minecraft:paper",
)

HOSTILE_HINTS = (
    "zombie", "skeleton", "creeper", "spider", "enderman", "witch", "phantom",
    "pillager", "vindicator", "ravager", "blaze", "ghast", "slime", "magma",
    "drowned", "husk", "stray", "silverfish", "wither", "hoglin", "piglin",
    "guardian", "shulker", "warden", "bogged", "breeze", "evoker", "illusioner",
)


class VerityModServerSystem(ServerSystem):
    def __init__(self, namespace, systemName):
        ServerSystem.__init__(self, namespace, systemName)

        self._box_id = None
        self._mob_id = None
        self._woken = False
        self._tick = 0
        self._pending = []
        self._villager_cooldown = {}
        self._allow_spawn_depth = 0
        self._require_prefix = True
        self._host_id = None
        self._initial_spawn_scheduled = False
        self._initial_spawn_done = False
        self._spawn_attempts = 0
        self._spawn_grace_until = 0
        self._last_spawn_retry_tick = 0
        self._world_ready_tick = 0
        self._combat_until = 0
        self._follow_last_pos = None
        self._last_limit_notify_tick = 0
        self._follow_stuck_ticks = 0
        self._build_queue = []
        self._build_dimension = 0
        self._player_contexts = {}
        self._held_by_player = {}
        self._throw_state = None
        self._throw_landed_until = 0
        self._instance_op_depth = 0
        self._verity_started = False
        self._pickup_in_progress = False
        self._kill_taunt_tick = 0
        self._chat_reply_seq = 0
        self._lonely_since_tick = {}
        self._lonely_rescue_cooldown = {}
        self._inv_restore_hint = {}
        self._defend_voice_tick = 0
        self._verity_transform_depth = 0
        self._monster_ids = set()
        self._monster_roar_tick = {}
        self._affection_monster_pending = False
        self._affection_monster_pending_since = 0
        self._affection_monster_last_tick = -999999  # allow first-ever trigger immediately
        self._monster_prev_gametype = {}
        self._jumpscare_active = False
        self._jumpscare_start_tick = 0
        self._jumpscare_seen_tick = 0
        self._jumpscare_cooldown_until = 0
        self._intro_expression_lock_until = 0
        self._post_intro_mood = MOOD_HAPPY
        self._buried_since_tick = 0
        self._water_face_active = False
        self._monster_roar_done = set()
        self._monster_charge_released = set()
        self._monster_horror_active = False
        self._monster_creative_taunt_tick = {}
        self._monster_last_roar_tick = 0
        self._monster_horror_sound_token = 0
        self._monster_melee_tick = {}
        self._complaint_cooldown = {}
        # Music system
        self._music_state = None           # None / "yinyueyi" / "yiyueer"
        self._music_switch_count = 0
        self._music_offer_pending = False  # waiting for player yes/no
        self._music_offer_tick = 0
        self._music_last_play_tick = 0
        self._music_offer_cooldown = 4800  # ~4 min between offers
        self._verity_appeared_tick = 0
        self._mob_mood = 0
        self._mood_reset_tick = 0
        self._mood_mob_id = None

        ns = serverApi.GetEngineNamespace()
        sn = serverApi.GetEngineSystemName()
        self.ListenForEvent(ns, sn, "AddServerPlayerEvent", self, self._on_player_join)
        self.ListenForEvent(ns, sn, "AddEntityServerEvent", self, self._on_add_entity)
        self.ListenForEvent(ns, sn, "EntityRemoveEvent", self, self._on_entity_remove)
        self.ListenForEvent(ns, sn, "ServerSpawnMobEvent", self, self._on_spawn_mob)
        self.ListenForEvent(ns, sn, "PlayerDoInteractServerEvent", self, self._on_interact)
        self.ListenForEvent(ns, sn, "PlayerAttackEntityEvent", self, self._on_player_attack)
        self.ListenForEvent(ns, sn, "ServerItemUseOnEvent", self, self._on_item_use_on)
        self.ListenForEvent(ns, sn, "ServerItemTryUseEvent", self, self._on_item_try_use)
        self.ListenForEvent(ns, sn, "DamageEvent", self, self._on_damage)
        self.ListenForEvent(ns, sn, "ServerChatEvent", self, self._on_chat)
        self.ListenForEvent(ns, sn, "GlobalCommandServerEvent", self, self._on_global_command)
        self.ListenForEvent(ns, sn, "CommandEvent", self, self._on_command_event)
        self.ListenForEvent(ns, sn, "InventoryItemChangedServerEvent", self, self._on_inventory_item_changed)
        self.ListenForEvent(ns, sn, "PlayerHurtEvent", self, self._on_player_hurt)
        self.ListenForEvent(ns, sn, "ActuallyHurtServerEvent", self, self._on_actually_hurt)
        self.ListenForEvent(ns, sn, "PlayerDropItemServerEvent", self, self._on_player_drop_item)
        self.ListenForEvent(ns, sn, "EntityMotionStopServerEvent", self, self._on_motion_stop)
        self.ListenForEvent(ns, sn, "PlayerDieEvent", self, self._on_player_die)
        self.ListenForEvent(ns, sn, "GameTypeChangedServerEvent", self, self._on_game_type_changed)
        self.ListenForEvent(ns, sn, "OnScriptTickServer", self, self._on_tick)

        self.ListenForEvent(MOD_NAME, CLIENT_NAME, "VerityPlaceEvent", self, self._on_place_request)
        self.ListenForEvent(MOD_NAME, CLIENT_NAME, "VerityThrowEvent", self, self._on_throw_request)
        self.ListenForEvent(MOD_NAME, CLIENT_NAME, "VerityDropTransformEvent", self, self._on_drop_transform_request)

        self._load_prefix_setting()
        print("Verity server system ready")

    def Destroy(self):
        ns = serverApi.GetEngineNamespace()
        sn = serverApi.GetEngineSystemName()
        self.UnListenForEvent(ns, sn, "AddServerPlayerEvent", self, self._on_player_join)
        self.UnListenForEvent(ns, sn, "AddEntityServerEvent", self, self._on_add_entity)
        self.UnListenForEvent(ns, sn, "EntityRemoveEvent", self, self._on_entity_remove)
        self.UnListenForEvent(ns, sn, "ServerSpawnMobEvent", self, self._on_spawn_mob)
        self.UnListenForEvent(ns, sn, "PlayerDoInteractServerEvent", self, self._on_interact)
        self.UnListenForEvent(ns, sn, "PlayerAttackEntityEvent", self, self._on_player_attack)
        self.UnListenForEvent(ns, sn, "ServerItemUseOnEvent", self, self._on_item_use_on)
        self.UnListenForEvent(ns, sn, "ServerItemTryUseEvent", self, self._on_item_try_use)
        self.UnListenForEvent(ns, sn, "DamageEvent", self, self._on_damage)
        self.UnListenForEvent(ns, sn, "ServerChatEvent", self, self._on_chat)
        self.UnListenForEvent(ns, sn, "GlobalCommandServerEvent", self, self._on_global_command)
        self.UnListenForEvent(ns, sn, "CommandEvent", self, self._on_command_event)
        self.UnListenForEvent(ns, sn, "InventoryItemChangedServerEvent", self, self._on_inventory_item_changed)
        self.UnListenForEvent(ns, sn, "PlayerHurtEvent", self, self._on_player_hurt)
        self.UnListenForEvent(ns, sn, "ActuallyHurtServerEvent", self, self._on_actually_hurt)
        self.UnListenForEvent(ns, sn, "PlayerDropItemServerEvent", self, self._on_player_drop_item)
        self.UnListenForEvent(ns, sn, "EntityMotionStopServerEvent", self, self._on_motion_stop)
        self.UnListenForEvent(ns, sn, "PlayerDieEvent", self, self._on_player_die)
        self.UnListenForEvent(ns, sn, "GameTypeChangedServerEvent", self, self._on_game_type_changed)
        self.UnListenForEvent(ns, sn, "OnScriptTickServer", self, self._on_tick)
        self.UnListenForEvent(MOD_NAME, CLIENT_NAME, "VerityPlaceEvent", self, self._on_place_request)
        self.UnListenForEvent(MOD_NAME, CLIENT_NAME, "VerityThrowEvent", self, self._on_throw_request)
        self.UnListenForEvent(MOD_NAME, CLIENT_NAME, "VerityDropTransformEvent", self, self._on_drop_transform_request)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _load_prefix_setting(self):
        try:
            value = CF.CreateExtraData(LEVEL_ID).GetExtraData(REQUIRE_PREFIX_KEY)
            if value is not None:
                self._require_prefix = bool(value)
        except Exception:
            self._require_prefix = True

    def _save_prefix_setting(self, require_prefix):
        self._require_prefix = bool(require_prefix)
        try:
            CF.CreateExtraData(LEVEL_ID).SetExtraData(REQUIRE_PREFIX_KEY, self._require_prefix)
        except Exception:
            pass

    def _begin_verity_transform(self):
        self._verity_transform_depth += 1

    def _end_verity_transform(self):
        if self._verity_transform_depth > 0:
            self._verity_transform_depth -= 1

    def _bind_mob_to_host(self, mob_id, host_id):
        if not mob_id or not host_id:
            return
        try:
            CF.CreateAttr(mob_id).SetEntityOwner(host_id)
        except Exception:
            pass
        try:
            CF.CreateTame(mob_id).SetEntityTamed(host_id, mob_id)
        except Exception:
            pass

    def _track_verity_inv_loss(self, player_id, args):
        if not player_id or not args:
            return
        old_item = args.get("oldItemDict") or {}
        new_item = args.get("newItemDict") or {}
        if not self._is_valid_verity_item(old_item):
            return
        if self._is_valid_verity_item(new_item):
            return
        try:
            enum_mod = serverApi.GetMinecraftEnum()
            pos_type = enum_mod.ItemPosType.INVENTORY
        except Exception:
            pos_type = 0
        try:
            slot = int(args.get("slot") or 0)
        except Exception:
            slot = 0
        self._inv_restore_hint[player_id] = {
            "pos_type": pos_type,
            "slot": slot,
            "item": dict(old_item),
            "tick": self._tick,
        }

    def _restore_verity_to_inv(self, player_id, item_dict):
        if not player_id or self._player_has_held_item(player_id):
            return True
        restore_item = item_dict or {
            "itemName": self._held_item_for_mood(self._mob_mood),
            "count": 1,
        }
        hint = self._inv_restore_hint.get(player_id)
        if hint and self._tick - int(hint.get("tick") or 0) <= INV_RESTORE_TTL:
            try:
                item_comp = CF.CreateItem(player_id)
                pos_type = hint.get("pos_type")
                inv_slot = int(hint.get("slot") or 0)
                item_comp.SetPlayerAllItems({(pos_type, inv_slot): restore_item})
                if self._player_has_held_item(player_id):
                    return True
            except Exception:
                pass
        try:
            if self._player_holds_held_item(player_id):
                return True
            CF.CreateItem(player_id).SpawnItemToPlayerCarried(restore_item, player_id)
            if self._player_has_held_item(player_id):
                return True
        except Exception:
            pass
        try:
            CF.CreateItem(player_id).SpawnItemToPlayerInv(restore_item, player_id, -1)
        except Exception:
            pass
        return self._player_has_held_item(player_id)

    def _verity_near_player(self, player_id, radius=None):
        radius = float(radius or LONELY_NEAR_RADIUS)
        if self._mob_id and self._entity_exists(self._mob_id):
            mob_pos = self._get_foot_pos(self._mob_id)
            ppos = self._get_player_foot_pos(player_id)
            if mob_pos and ppos and self._dist_xz(mob_pos, ppos) <= radius:
                return True
        if self._player_holds_held_item(player_id):
            return True
        return False

    def _pick_lonely_rescue_line(self):
        slugs = ("sys_lonely_00", "sys_lonely_01", "sys_lonely_02")
        slug = random.choice(slugs)
        try:
            import veritySysVoiceRegistry as reg
            row = reg.get_sys_entry(slug)
            if row:
                return slug, row.get("en") or "", row.get("zh") or u""
        except Exception:
            pass
        lines = (
            ("sys_lonely_00", u"You locked me away too long!", u"\u4f60\u628a\u6211\u5173\u592a\u4e45\u4e86\uff01\u6211\u4e0d\u559c\u6b22\uff01"),
            ("sys_lonely_01", u"Finally found you again.", u"\u603b\u7b97\u627e\u5230\u4f60\u4e86\uff0c\u522b\u518d\u628a\u6211\u4e22\u4e00\u8fb9\u3002"),
            ("sys_lonely_02", u"I have been waiting forever.", u"\u6211\u7b49\u4e86\u597d\u4e45\u4e86\uff0c\u4f60\u89c9\u5f97\u8fc7\u5206\u5417\uff1f"),
        )
        pick = random.choice(lines)
        return pick[0], pick[1], pick[2]

    def _update_lonely_rescue(self):
        host_id = self._get_host_id()
        if not host_id:
            return
        if self._throw_state or self._pickup_in_progress:
            return
        if self._verity_near_player(host_id):
            self._lonely_since_tick.pop(host_id, None)
            return
        since = self._lonely_since_tick.get(host_id)
        if since is None:
            self._lonely_since_tick[host_id] = self._tick
            return
        need = int(LONELY_RESCUE_SECONDS * 20.0)
        if self._tick - int(since) < need:
            return
        cooldown = int(self._lonely_rescue_cooldown.get(host_id) or 0)
        if self._tick < cooldown:
            return
        if self._mob_id and self._entity_exists(self._mob_id):
            mob_pos = self._get_foot_pos(self._mob_id)
            ppos = self._get_player_foot_pos(host_id)
            if mob_pos and ppos and self._dist_xz(mob_pos, ppos) > LONELY_NEAR_RADIUS:
                self._teleport_near(self._mob_id, host_id, ppos)
                slug, _, _ = self._pick_lonely_rescue_line()
                self._broadcast_sys_line(slug, entity_id=self._mob_id, player_id=host_id)
                self._lonely_since_tick[host_id] = self._tick
                self._lonely_rescue_cooldown[host_id] = self._tick + LONELY_RESCUE_COOLDOWN
            return
        self._begin_verity_transform()
        try:
            if self._player_has_held_item(host_id):
                self._remove_held_item(host_id)
                self._purge_ghost_verity_items(host_id)
            if self._box_id and self._entity_exists(self._box_id):
                try:
                    self.DestroyEntity(self._box_id)
                except Exception:
                    pass
                self._box_id = None
            mob_id = self._spawn_mob_at_player(host_id)
        finally:
            self._end_verity_transform()
        self._lonely_since_tick[host_id] = self._tick
        self._lonely_rescue_cooldown[host_id] = self._tick + LONELY_RESCUE_COOLDOWN
        if mob_id:
            slug, _, _ = self._pick_lonely_rescue_line()
            self._broadcast_sys_line(slug, entity_id=mob_id, player_id=host_id)

    def _transform_held_to_mob(self, player_id):
        if not player_id:
            return False
        if self._mob_id and self._entity_exists(self._mob_id):
            return False
        if not self._player_holds_held_item(player_id):
            return False
        self._begin_verity_transform()
        try:
            return bool(self._place_verity(player_id))
        finally:
            self._end_verity_transform()

    def _on_drop_transform_request(self, args):
        player_id = args.get("__id__") or args.get("playerId")
        if not player_id:
            player_id = self._get_host_id()
        self._transform_held_to_mob(player_id)

    def _on_player_drop_item(self, args):
        player_id = args.get("playerId")
        item_entity_id = args.get("itemEntityId")
        if not item_entity_id:
            return
        try:
            item = CF.CreateGame(LEVEL_ID).GetDroppedItem(item_entity_id, False)
        except Exception:
            item = None
        if not self._is_valid_verity_item(item):
            return
        try:
            self.DestroyEntity(item_entity_id)
        except Exception:
            pass
        if self._mob_id and self._entity_exists(self._mob_id):
            return
        host_id = player_id or self._get_host_id()
        if not host_id:
            return
        self._purge_ghost_verity_items(host_id)
        self._begin_verity_transform()
        try:
            if self._player_holds_held_item(host_id):
                self._place_verity(host_id)
            else:
                mob_id = self._spawn_mob_at_player(host_id)
                if mob_id:
                    self._broadcast_sys_line("sys_place_00", entity_id=mob_id, player_id=host_id)
        finally:
            self._end_verity_transform()

    def _on_inventory_item_changed(self, args):
        if self._instance_op_depth > 0 or self._pickup_in_progress:
            return
        if self._verity_transform_depth > 0:
            return
        player_id = args.get("playerId")
        if not player_id:
            return
        host_id = self._get_host_id()
        if host_id and player_id != host_id:
            return
        if self._verity_mob_alive():
            if self._player_has_any_verity_item(player_id):
                self._purge_all_verity_items(player_id)
            return
        old_item = args.get("oldItemDict") or {}
        new_item = args.get("newItemDict") or {}
        if self._is_valid_verity_item(old_item) and not self._is_valid_verity_item(new_item):
            self._track_verity_inv_loss(player_id, args)
        if not self._is_valid_verity_item(old_item):
            return
        if self._mob_id and self._entity_exists(self._mob_id):
            return
        if self._player_has_held_item(player_id):
            return
        self._schedule(0.15, self._respawn_mob_from_item_loss, player_id)

    def _respawn_mob_from_item_loss(self, player_id):
        if not player_id:
            return
        if self._instance_op_depth > 0 or self._pickup_in_progress:
            return
        if self._verity_transform_depth > 0:
            return
        if self._mob_id and self._entity_exists(self._mob_id):
            return
        if self._player_has_held_item(player_id):
            return
        self._begin_verity_transform()
        try:
            if self._player_holds_held_item(player_id):
                self._place_verity(player_id)
            else:
                mob_id = self._spawn_mob_at_player(player_id)
                if mob_id:
                    self._broadcast_sys_line("sys_place_00", entity_id=mob_id, player_id=player_id)
        finally:
            self._end_verity_transform()

    def _allow_spawn_enter(self):
        self._allow_spawn_depth += 1

    def _allow_spawn_exit(self):
        if self._allow_spawn_depth > 0:
            self._allow_spawn_depth -= 1

    def _entity_exists(self, entity_id):
        if not entity_id:
            return False
        try:
            return bool(CF.CreateEngineType(entity_id).GetEngineTypeStr())
        except Exception:
            return False

    def _get_entity_type(self, entity_id):
        if not entity_id:
            return ""
        try:
            return CF.CreateEngineType(entity_id).GetEngineTypeStr() or ""
        except Exception:
            return ""

    def _get_foot_pos(self, entity_id):
        try:
            pos = CF.CreatePos(entity_id).GetFootPos()
            if pos:
                return pos
        except Exception:
            pass
        return self._get_pos(entity_id)

    def _get_player_foot_pos(self, player_id):
        try:
            pos = CF.CreatePos(player_id).GetFootPos()
            if pos:
                return pos
        except Exception:
            pass
        return self._get_pos(player_id)

    def _get_pos(self, entity_id):
        try:
            return CF.CreatePos(entity_id).GetPos()
        except Exception:
            return None

    def _dist_xz(self, a, b):
        if not a or not b:
            return 999999.0
        dx = a[0] - b[0]
        dz = a[2] - b[2]
        return math.sqrt(dx * dx + dz * dz)

    def _get_host_id(self):
        try:
            host_id = serverApi.GetHostPlayerId()
            if host_id and self._entity_exists(host_id):
                self._host_id = host_id
                return host_id
        except Exception:
            pass
        if self._host_id and self._entity_exists(self._host_id):
            return self._host_id
        players = serverApi.GetPlayerList()
        if players:
            self._host_id = players[0]
            return players[0]
        return None

    def _scan_verity_entities(self):
        boxes = []
        mobs = []
        host_id = self._get_host_id()
        if not host_id:
            return boxes, mobs
        try:
            nearby = CF.CreateGame(host_id).GetEntitiesAround(host_id, 128, {}) or []
        except Exception:
            nearby = []
        for entity_id in nearby:
            type_str = self._get_entity_type(entity_id)
            if type_str == BOX_ENTITY:
                boxes.append(entity_id)
            elif type_str == MOB_ENTITY:
                mobs.append(entity_id)
        return boxes, mobs

    def _sync_tracked_ids(self):
        if self._box_id and not self._entity_exists(self._box_id):
            self._box_id = None
            self._woken = False
        if self._mob_id and not self._entity_exists(self._mob_id):
            self._mob_id = None

    def _has_active_instance(self):
        self._sync_tracked_ids()
        if self._box_id or self._mob_id:
            return True
        boxes, mobs = self._scan_verity_entities()
        return len(boxes) > 0 or len(mobs) > 0

    def _enforce_single_instance(self, notify_player_id=None):
        self._sync_tracked_ids()
        boxes, mobs = self._scan_verity_entities()

        keep_mob = None
        keep_box = None

        if self._mob_id in mobs:
            keep_mob = self._mob_id
        elif mobs:
            keep_mob = mobs[0]
        elif self._mob_id and self._entity_exists(self._mob_id):
            # The proximity scan (128 blocks around the host) can miss a
            # mob that was created this very tick (spatial index lag) or
            # when the host is briefly far from it. Don't lose track of a
            # mob that verifiably still exists just because the scan
            # didn't see it — that caused Verity to "vanish" right after
            # the wake/fall intro.
            keep_mob = self._mob_id

        if keep_mob:
            keep_box = None
            self._woken = True
        else:
            if self._box_id in boxes:
                keep_box = self._box_id
            elif boxes:
                keep_box = boxes[0]
            elif self._box_id and self._entity_exists(self._box_id):
                keep_box = self._box_id
            self._woken = bool(keep_box and self._woken)

        removed = False
        for entity_id in boxes:
            if entity_id != keep_box:
                try:
                    self.DestroyEntity(entity_id)
                    removed = True
                except Exception:
                    pass
        for entity_id in mobs:
            if entity_id != keep_mob:
                try:
                    self.DestroyEntity(entity_id)
                    removed = True
                except Exception:
                    pass

        self._box_id = keep_box
        self._mob_id = keep_mob
        if keep_mob:
            if not self._verity_appeared_tick:
                # Mob already existed (e.g. world reload) — it has already
                # "appeared", no need to wait another 1-2 minutes for music offers.
                self._verity_appeared_tick = self._tick
            self._box_id = None
            self._woken = True

        if keep_mob:
            self._enforce_mob_no_duplicate_items()

        if removed and notify_player_id:
            self._notify_limit(notify_player_id)
        elif removed:
            self._notify_all(LIMIT_ONE_MSG)

    def _notify_player(self, player_id, message):
        """Wood-mod style chat line (NotifyOneMessage only)."""
        if not player_id or not message:
            return
        try:
            CF.CreateMsg(player_id).NotifyOneMessage(player_id, str(message), "")
        except Exception:
            pass

    def _broadcast_chat(self, zh_text):
        """Broadcast to every player's chat box (wood mod pattern)."""
        if not zh_text:
            return
        if not isinstance(zh_text, unicode):
            try:
                zh_text = unicode(zh_text)
            except Exception:
                return
        line = u"\u00a7e[Verity]\u00a7r " + zh_text
        players = serverApi.GetPlayerList()
        if not players:
            return
        for pid in players:
            self._notify_player(pid, line)

    def _notify_limit(self, player_id):
        # ServerItemUseOnEvent and ServerItemTryUseEvent (and interact) can
        # all fire for the same physical action — debounce so the player
        # only sees the message once per attempt.
        if self._tick - self._last_limit_notify_tick < 20:
            return
        self._last_limit_notify_tick = self._tick
        self._notify_player(player_id, LIMIT_ONE_MSG)

    def _notify_all(self, message):
        for pid in serverApi.GetPlayerList():
            self._notify_player(pid, message)

    def _register_entity(self, entity_id, type_str):
        if type_str == BOX_ENTITY:
            self._box_id = entity_id
            self._mob_id = None
            self._woken = False
            return True
        if type_str == MOB_ENTITY:
            self._mob_id = entity_id
            self._box_id = None
            self._woken = True
            return True
        return False

    def _reject_duplicate_spawn(self, entity_id, player_id=None):
        try:
            self.DestroyEntity(entity_id)
        except Exception:
            pass
        self._enforce_single_instance(player_id)

    def _schedule(self, delay_seconds, callback, *args):
        fire_tick = self._tick + int(round(delay_seconds * 20.0))
        self._pending.append([fire_tick, callback, args])

    def _on_tick(self, args=None):
        self._tick += 1

        if self._tick % TICK_CHECK_INTERVAL == 0 and self._pending:
            remaining = []
            for entry in self._pending:
                fire_tick, callback, cb_args = entry
                if self._tick >= fire_tick:
                    try:
                        callback(*cb_args)
                    except Exception as exc:
                        print("Verity timer callback error: %s" % exc)
                else:
                    remaining.append(entry)
            self._pending = remaining

        if self._tick % ENFORCE_INTERVAL == 0:
            self._enforce_single_instance()

        if self._tick % AI_TICK_INTERVAL == 0:
            self._update_companion_ai()
            self._update_proactive_chat()
            self._update_music_offer()
            self._check_fire_lava_hazard()
            self._tick_mood_decay()
            self._update_monster_ai()
            self._clear_stale_affection_monster_pending()
            self._check_affection_monster_trigger()
            self._update_jumpscare()
            self._check_buried_state()
            self._check_water_face()

        if self._build_queue:
            self._process_build_queue()

        if self._throw_state:
            self._update_throw_physics()
            self._update_throw_physx_settle()

        if self._tick % 10 == 0:
            self._update_lonely_rescue()
            self._sync_held_players()
            self._enforce_mob_no_duplicate_items()
            host_id = self._get_host_id()
            if host_id:
                self._purge_ghost_verity_items(host_id)

        if self._tick % SPAWN_RETRY_INTERVAL == 0:
            self._ensure_start_box()

    def _begin_instance_op(self):
        self._instance_op_depth += 1

    def _end_instance_op(self):
        if self._instance_op_depth > 0:
            self._instance_op_depth -= 1

    def _has_living_instance(self):
        self._sync_tracked_ids()
        if self._instance_op_depth > 0:
            return True
        if self._throw_state:
            return True
        if self._mob_id and self._entity_exists(self._mob_id):
            return True
        if self._box_id and self._entity_exists(self._box_id):
            return True
        if self._any_player_holds_held_item():
            return True
        return False

    def _item_name(self, item_dict):
        if not item_dict:
            return ""
        return item_dict.get("itemName") or item_dict.get("newItemName") or ""

    def _item_count(self, item_dict):
        if not item_dict:
            return 0
        try:
            return int(item_dict.get("count") or 0)
        except Exception:
            return 0

    def _held_item_for_mood(self, mood):
        try:
            mood = int(mood)
        except Exception:
            mood = MOOD_HAPPY
        if mood == MOOD_ANNOYED:
            return HELD_ITEM_ANNOYED
        if mood in (MOOD_ANGRY, MOOD_EVIL, MOOD_ABNORMAL_SHUT):
            return HELD_ITEM_ANGRY
        return HELD_ITEM

    def _mood_from_item_name(self, item_name):
        return ITEM_TO_MOOD.get(item_name or "", MOOD_HAPPY)

    def _get_carried_verity_item_name(self, player_id):
        if not player_id:
            return ""
        try:
            item_comp = CF.CreateItem(player_id)
            enum_mod = serverApi.GetMinecraftEnum()
            pos_map = enum_mod.ItemPosType
            for pos_type in (pos_map.CARRIED, pos_map.OFFHAND):
                items = item_comp.GetPlayerAllItems(pos_type) or []
                for item in items:
                    name = self._item_name(item)
                    if name in ITEM_TO_MOOD:
                        return name
        except Exception:
            pass
        return ""

    def _read_mob_variant(self, mob_id):
        try:
            saved = CF.CreateModAttr(mob_id).GetAttr("verity_face", None)
            if saved is not None:
                return int(saved)
        except Exception:
            pass
        try:
            return int(CF.CreateEntityDefinitions(mob_id).GetVariant())
        except Exception:
            return int(self._mob_mood or MOOD_HAPPY)

    def _is_intro_expression_locked(self):
        return self._tick < int(self._intro_expression_lock_until or 0)

    def _begin_intro_fall_expression(self, mob_id, player_id=None, play_opening=False):
        """Lock random mood/jumpscare during fall; hurt face near landing."""
        self._post_intro_mood = self._mob_mood
        if self._post_intro_mood not in ITEM_TO_MOOD.values() and self._post_intro_mood not in MOOD_TRANSIENT:
            self._post_intro_mood = MOOD_HAPPY
        self._intro_expression_lock_until = (
            self._tick + int(FALL_INTRO_SECONDS * 20) + 40
        )
        try:
            CF.CreateEntityDefinitions(mob_id).SetVariant(MOOD_HAPPY)
        except Exception:
            pass
        self._mob_mood = MOOD_HAPPY
        self._mood_mob_id = mob_id
        self._mood_reset_tick = 0
        hurt_at = max(0.5, float(FALL_INTRO_SECONDS) - float(FALL_HURT_LEAD_SECONDS))
        self._schedule(hurt_at, self._apply_intro_hurt_face, mob_id)
        if play_opening:
            self._schedule(
                FALL_INTRO_SECONDS,
                self._play_opening_greeting,
                mob_id,
                player_id,
            )
        else:
            self._schedule(
                FALL_INTRO_SECONDS,
                self._finish_intro_fall_expression,
                mob_id,
            )

    def _apply_intro_hurt_face(self, mob_id):
        if mob_id != self._mob_id or not self._entity_exists(mob_id):
            return
        self._set_mood(MOOD_HURT, duration_ticks=99999)

    def _finish_intro_fall_expression(self, mob_id):
        if mob_id != self._mob_id or not self._entity_exists(mob_id):
            return
        self._intro_expression_lock_until = 0
        self._set_mood(self._post_intro_mood)

    def _block_name_at_entity(self, entity_id, y_offset=0):
        pos = self._get_foot_pos(entity_id)
        if not pos:
            return ""
        dim = 0
        try:
            host = self._get_host_id()
            if host:
                dim = self._get_player_dimension(host)
        except Exception:
            pass
        bx = int(math.floor(pos[0]))
        by = int(math.floor(pos[1])) + int(y_offset)
        bz = int(math.floor(pos[2]))
        return self._block_name_at(bx, by, bz, dim) or ""

    def _is_entity_buried(self, entity_id):
        if not entity_id:
            return False
        feet = self._block_name_at_entity(entity_id, 0)
        head = self._block_name_at_entity(entity_id, 1)
        for name in (feet, head):
            if name in BURIED_BLOCK_NAMES:
                return True
        return False

    def _is_entity_in_water(self, entity_id):
        if not entity_id:
            return False
        feet = self._block_name_at_entity(entity_id, 0)
        body = self._block_name_at_entity(entity_id, 1)
        return feet in WATER_BLOCK_NAMES or body in WATER_BLOCK_NAMES

    def _check_buried_state(self):
        if not self._mob_id or not self._entity_exists(self._mob_id):
            self._buried_since_tick = 0
            return
        if self._throw_state or self._pickup_in_progress:
            return
        if self._is_intro_expression_locked():
            return
        if not self._is_entity_buried(self._mob_id):
            self._buried_since_tick = 0
            return
        host_id = self._get_host_id()
        if not host_id:
            return
        if not self._buried_since_tick:
            self._buried_since_tick = self._tick
            last = self._complaint_cooldown.get("buried_scan", 0)
            if self._tick - last > COMPLAINT_COOLDOWN_TICKS:
                self._complaint_cooldown["buried_scan"] = self._tick
                self._broadcast_chat(random.choice(BURIED_COMPLAINTS))
                self._set_mood(MOOD_ANNOYED)
                self._bump_host_emotion(host_id, affection_delta=-10, anger_delta=18)
            self._schedule(
                BURIED_RESCUE_DELAY_SEC,
                self._rescue_from_burial,
                self._mob_id,
                host_id,
                False,
            )
            return
        if self._tick - self._buried_since_tick >= BURIED_LONG_TICKS:
            self._buried_since_tick = 0
            self._rescue_from_burial(self._mob_id, host_id, True)

    def _check_water_face(self):
        if not self._mob_id or not self._entity_exists(self._mob_id):
            self._water_face_active = False
            return
        if self._throw_state or self._is_intro_expression_locked():
            return
        in_water = self._is_entity_in_water(self._mob_id)
        if in_water:
            if not self._water_face_active:
                self._water_face_active = True
                self._set_mood(MOOD_SPEAK, duration_ticks=99999)
            return
        if self._water_face_active:
            self._water_face_active = False
            if self._mob_mood == MOOD_SPEAK:
                self._set_mood(MOOD_HAPPY)

    def _is_valid_verity_item(self, item_dict):
        if self._item_name(item_dict) not in HELD_ITEM_VARIANTS:
            return False
        return self._item_count(item_dict) > 0

    def _is_verity_item(self, item_dict):
        name = self._item_name(item_dict)
        if name not in HELD_ITEM_VARIANTS and name != SUMMON_ITEM:
            return False
        return self._item_count(item_dict) > 0

    def _verity_mob_alive(self):
        return bool(self._mob_id and self._entity_exists(self._mob_id))

    def _player_has_any_verity_item(self, player_id):
        if not player_id:
            return False
        try:
            item_comp = CF.CreateItem(player_id)
            enum_mod = serverApi.GetMinecraftEnum()
            pos_map = enum_mod.ItemPosType
            for pos_type in (pos_map.CARRIED, pos_map.OFFHAND, pos_map.INVENTORY):
                items = item_comp.GetPlayerAllItems(pos_type) or []
                for item in items:
                    if self._is_verity_item(item):
                        return True
        except Exception:
            pass
        return False

    def _purge_all_verity_items(self, player_id, force=False):
        """Remove every severity item from inventory (held item + summon egg)."""
        if not player_id:
            return False
        if not force and (self._pickup_in_progress or self._verity_transform_depth > 0):
            return False
        cleared = False
        try:
            item_comp = CF.CreateItem(player_id)
            enum_mod = serverApi.GetMinecraftEnum()
            pos_map = enum_mod.ItemPosType
            for pos_type in (pos_map.CARRIED, pos_map.OFFHAND, pos_map.INVENTORY):
                items = item_comp.GetPlayerAllItems(pos_type) or []
                for slot, item in enumerate(items):
                    if not self._is_verity_item(item):
                        continue
                    if self._clear_inventory_slot(item_comp, pos_type, slot, player_id):
                        cleared = True
        except Exception:
            pass
        if cleared:
            self._purge_ghost_verity_items(player_id)
            if player_id in self._held_by_player:
                del self._held_by_player[player_id]
                self.NotifyToClient(player_id, "VerityHideHoldUiEvent", {})
        return cleared

    def _enforce_mob_no_duplicate_items(self):
        """Mob body exists -> player inventory must not keep severity items."""
        if not self._verity_mob_alive():
            return
        if self._pickup_in_progress or self._verity_transform_depth > 0:
            return
        if self._instance_op_depth > 0 or self._throw_state:
            return
        for player_id in serverApi.GetPlayerList() or []:
            if self._player_has_any_verity_item(player_id):
                self._purge_all_verity_items(player_id)

    def _clear_inventory_slot(self, item_comp, pos_type, slot, player_id):
        try:
            item_comp.SetPlayerAllItems({(pos_type, slot): None})
            return True
        except Exception:
            pass
        try:
            enum_mod = serverApi.GetMinecraftEnum()
            if pos_type == enum_mod.ItemPosType.INVENTORY:
                item_comp.SetInvItemNum(slot, 0)
            else:
                item_comp.SpawnItemToPlayerCarried(
                    {"itemName": "minecraft:air", "count": 0}, player_id
                )
            return True
        except Exception:
            return False

    def _purge_ghost_verity_items(self, player_id):
        """Remove empty-looking severity ghost slots that still occupy inventory."""
        if not player_id:
            return
        try:
            item_comp = CF.CreateItem(player_id)
            enum_mod = serverApi.GetMinecraftEnum()
            pos_map = enum_mod.ItemPosType
            for pos_type in (pos_map.CARRIED, pos_map.OFFHAND, pos_map.INVENTORY):
                items = item_comp.GetPlayerAllItems(pos_type) or []
                for slot, item in enumerate(items):
                    if self._item_name(item) not in HELD_ITEM_VARIANTS:
                        continue
                    if self._item_count(item) <= 0:
                        self._clear_inventory_slot(item_comp, pos_type, slot, player_id)
                        try:
                            item_comp.SetPlayerAllItems({(pos_type, slot): None})
                        except Exception:
                            pass
                        try:
                            item_comp.SetPlayerAllItems({
                                (pos_type, slot): {"itemName": "minecraft:air", "count": 0}
                            })
                        except Exception:
                            pass
        except Exception:
            pass

    def _player_has_inv_space(self, player_id):
        if not player_id:
            return False
        try:
            item_comp = CF.CreateItem(player_id)
            enum_mod = serverApi.GetMinecraftEnum()
            items = item_comp.GetPlayerAllItems(enum_mod.ItemPosType.INVENTORY) or []
            for item in items:
                name = self._item_name(item)
                count = self._item_count(item)
                if not name or name == "minecraft:air" or count <= 0:
                    return True
            return False
        except Exception:
            return True

    def _player_has_held_item(self, player_id):
        """True if verity:item_2 exists anywhere in player inventory."""
        if not player_id:
            return False
        try:
            item_comp = CF.CreateItem(player_id)
            enum_mod = serverApi.GetMinecraftEnum()
            pos_map = enum_mod.ItemPosType
            for pos_type in (pos_map.CARRIED, pos_map.OFFHAND, pos_map.INVENTORY):
                items = item_comp.GetPlayerAllItems(pos_type) or []
                for item in items:
                    if self._is_valid_verity_item(item):
                        return True
        except Exception:
            pass
        return False

    def _player_holds_held_item(self, player_id):
        """True only when severity item is in hand (hotbar selected or offhand)."""
        if not player_id:
            return False
        try:
            item_comp = CF.CreateItem(player_id)
            enum_mod = serverApi.GetMinecraftEnum()
            pos_map = enum_mod.ItemPosType
            for pos_type in (pos_map.CARRIED, pos_map.OFFHAND):
                items = item_comp.GetPlayerAllItems(pos_type) or []
                for item in items:
                    if self._is_valid_verity_item(item):
                        return True
        except Exception:
            try:
                item_comp = CF.CreateItem(player_id)
                for pos_type in (2, 1):
                    items = item_comp.GetPlayerAllItems(pos_type) or []
                    for item in items:
                        if self._is_valid_verity_item(item):
                            return True
            except Exception:
                pass
        return False

    def _any_player_holds_held_item(self):
        for player_id in serverApi.GetPlayerList():
            if self._player_has_held_item(player_id):
                return True
        return False

    def _give_held_item(self, player_id):
        if not player_id:
            return False
        item_name = self._held_item_for_mood(self._mob_mood)
        try:
            return bool(CF.CreateItem(player_id).SpawnItemToPlayerInv(
                {"itemName": item_name, "count": 1}, player_id, -1
            ))
        except Exception:
            return False

    def _remove_held_item(self, player_id):
        if not player_id:
            return False
        return self._purge_all_verity_items(player_id, force=True)

    def _sync_held_players(self):
        active = set()
        for player_id in serverApi.GetPlayerList():
            if self._player_holds_held_item(player_id):
                active.add(player_id)
                if player_id not in self._held_by_player:
                    self._held_by_player[player_id] = True
                    self.NotifyToClient(player_id, "VerityShowHoldUiEvent", {})
            elif player_id in self._held_by_player:
                del self._held_by_player[player_id]
                self.NotifyToClient(player_id, "VerityHideHoldUiEvent", {})
        stale = [pid for pid in self._held_by_player if pid not in active]
        for pid in stale:
            del self._held_by_player[pid]
            self.NotifyToClient(pid, "VerityHideHoldUiEvent", {})

    def _pickup_severity(self, player_id):
        if not player_id or not self._mob_id or not self._entity_exists(self._mob_id):
            return False
        if self._player_has_held_item(player_id):
            return False
        if not self._player_has_inv_space(player_id):
            self._broadcast_chat(
                u"\u80cc\u5305\u6ca1\u7a7a\u4f4d\u4e86\uff0c\u5148\u6e05\u4e00\u683c\u518d\u6536\u6211\u5427\u3002"
            )
            return False
        self._pickup_in_progress = True
        self._begin_instance_op()
        mob_id = self._mob_id
        pick_mood = self._read_mob_variant(mob_id)
        if pick_mood < MOOD_HAPPY or pick_mood > MOOD_ABNORMAL_SHUT:
            pick_mood = MOOD_HAPPY
        self._mob_mood = pick_mood
        saved_pos = self._get_foot_pos(mob_id)
        saved_dim = self._get_player_dimension(player_id)
        self._mob_id = None
        try:
            self.DestroyEntity(mob_id)
        except Exception:
            pass
        if not self._give_held_item(player_id):
            self._pickup_in_progress = False
            respawn_pos = saved_pos
            if not respawn_pos:
                respawn_pos = self._get_player_foot_pos(player_id)
            if respawn_pos:
                new_id = self._spawn_mob_at_pos(respawn_pos, saved_dim)
                if new_id:
                    self._mob_id = new_id
            self._end_instance_op()
            self._broadcast_chat(
                u"\u6536\u8d77\u5931\u8d25\u4e86\uff0c\u80cc\u5305\u6ca1\u7a7a\u4f4d\u6216\u7269\u54c1\u6ca1\u8fdb\u53bb\u3002"
            )
            return False
        self._held_by_player[player_id] = True
        self._pickup_in_progress = False
        self._end_instance_op()
        self.NotifyToClient(player_id, "VerityShowHoldUiEvent", {})
        self._broadcast_sys_line("sys_pickup_00", player_id=player_id)
        return True

    def _spawn_mob_at_pos(self, pos, dimension=0, for_throw=False):
        if not pos:
            return None
        self._allow_spawn_enter()
        try:
            mob_id = self.CreateEngineEntityByTypeStr(
                MOB_ENTITY, pos, (0.0, 0.0), dimension, False, True
            )
        finally:
            self._allow_spawn_exit()
        if not mob_id:
            return None
        self._register_entity(mob_id, MOB_ENTITY)
        self._verity_started = True
        self._spawn_grace_until = self._tick + 40
        try:
            CF.CreateModAttr(mob_id).SetPersistent(True)
        except Exception:
            pass
        self._mood_mob_id = None
        play_intro = not for_throw
        if play_intro:
            self._begin_intro_fall_expression(mob_id, play_opening=False)
        else:
            self._set_mood(self._mob_mood)
        if for_throw:
            pass
        host_id = self._get_host_id()
        if host_id:
            self._bind_mob_to_host(mob_id, host_id)
        self.BroadcastToAllClient(
            "VerityMobSpawnEvent",
            {"entityId": mob_id, "introFall": not for_throw},
        )
        return mob_id

    def _ground_foot_pos(self, x, z, dim, hint_y=None):
        try:
            top = CF.CreateBlockInfo(LEVEL_ID).GetTopBlockHeight(
                (int(math.floor(x)), int(math.floor(z))), int(dim)
            )
            if top is not None:
                return (float(x), float(top) + 1.0, float(z))
        except Exception:
            pass
        if hint_y is not None:
            return (float(x), float(hint_y), float(z))
        return (float(x), 64.0, float(z))

    def _settle_throw_landing(self, state):
        if not state:
            self._throw_state = None
            return
        pos = state.get("pos") or [0.0, 64.0, 0.0]
        dim = int(state.get("dim") or 0)
        landed = self._ground_foot_pos(pos[0], pos[2], dim, pos[1])
        mob_id = state.get("mob_id")
        restored = False
        if mob_id and self._entity_exists(mob_id):
            try:
                CF.CreatePos(mob_id).SetFootPos(landed)
            except Exception:
                pass
            try:
                CF.CreateControlAi(mob_id).SetBlockControlAi(True)
            except Exception:
                pass
            self._mob_id = mob_id
            restored = True
        else:
            self._begin_instance_op()
            try:
                new_id = self._spawn_mob_at_pos(landed, dim, for_throw=True)
            finally:
                self._end_instance_op()
            if new_id:
                self._mob_id = new_id
                restored = True
        self._throw_state = None
        self._throw_landed_until = self._tick + THROW_LANDING_GRACE_TICKS
        if restored and self._mob_id and self._is_entity_in_water(self._mob_id):
            self._water_face_active = True
            self._set_mood(MOOD_SPEAK, duration_ticks=99999)
        if restored:
            self._broadcast_chat(
                u"\u843d\u5730\u4e86\uff0c\u5728 (%.0f, %.0f, %.0f) \u9644\u8fd1\u3002"
                % (landed[0], landed[1], landed[2])
            )
        else:
            self._broadcast_chat(u"\u6295\u51fa\u5931\u8d25\u4e86\uff0c\u6ca1\u80fd\u5728\u843d\u70b9\u6062\u590d\u3002")

    def _apply_throw_motion(self, mob_id, direction, player_id):
        if not mob_id or not direction:
            return False
        try:
            CF.CreateControlAi(mob_id).SetBlockControlAi(False)
        except Exception:
            pass
        dx = float(direction[0])
        dz = float(direction[2])
        length = math.sqrt(dx * dx + dz * dz)
        if length < 0.01:
            dx, dz = 0.0, 1.0
            length = 1.0
        speed = 0.5
        vel = [dx / length * speed, 0.42, dz / length * speed]
        self._throw_state = {
            "mob_id": mob_id,
            "motion_id": -1,
            "manual": True,
            "pos": list(self._get_foot_pos(mob_id) or (0.0, 64.0, 0.0)),
            "vel": vel,
            "dim": self._get_player_dimension(player_id),
            "bounces": 0,
        }
        return True

    def _finish_throw(self, mob_id):
        state = self._throw_state
        if state and mob_id:
            if state.get("motion_id") is not None and state.get("motion_id") >= 0:
                try:
                    CF.CreateActorMotion(mob_id).RemoveEntityMotion(state.get("motion_id"))
                except Exception:
                    pass
        self._settle_throw_landing(state)

    def _on_motion_stop(self, args):
        entity_id = args.get("entityId")
        if not entity_id or not self._throw_state:
            return
        if entity_id != self._throw_state.get("mob_id"):
            return
        self._finish_throw(entity_id)

    def _spawn_mob_at_player(self, player_id):
        pos = self._get_player_foot_pos(player_id)
        if not pos:
            return None
        try:
            rot = CF.CreateRot(player_id).GetRot()
        except Exception:
            rot = (0.0, 0.0)
        try:
            direction = serverApi.GetDirFromRot(rot)
        except Exception:
            direction = (0.0, 0.0, 1.0)
        spawn_pos = (
            pos[0] + direction[0] * 1.2,
            pos[1],
            pos[2] + direction[2] * 1.2,
        )
        dim = self._get_player_dimension(player_id)
        return self._spawn_mob_at_pos(spawn_pos, dim)

    def _place_verity(self, player_id):
        if not self._player_holds_held_item(player_id):
            return False
        if self._mob_id and self._entity_exists(self._mob_id):
            return False
        carried = self._get_carried_verity_item_name(player_id)
        if carried:
            self._mob_mood = self._mood_from_item_name(carried)
        self._begin_instance_op()
        if not self._remove_held_item(player_id):
            self._end_instance_op()
            return False
        if player_id in self._held_by_player:
            del self._held_by_player[player_id]
        self.NotifyToClient(player_id, "VerityHideHoldUiEvent", {})
        self._purge_ghost_verity_items(player_id)
        mob_id = self._spawn_mob_at_player(player_id)
        self._end_instance_op()
        if mob_id:
            self._broadcast_sys_line("sys_place_00", entity_id=mob_id, player_id=player_id)
            return True
        self._give_held_item(player_id)
        self._held_by_player[player_id] = True
        self.NotifyToClient(player_id, "VerityShowHoldUiEvent", {})
        return False

    def _throw_severity(self, player_id):
        if not self._player_holds_held_item(player_id):
            return False
        if self._mob_id and self._entity_exists(self._mob_id):
            return False
        pos = self._get_player_foot_pos(player_id)
        if not pos:
            return False
        try:
            rot = CF.CreateRot(player_id).GetRot()
        except Exception:
            rot = (0.0, 0.0)
        try:
            direction = serverApi.GetDirFromRot(rot)
        except Exception:
            direction = (0.0, 0.0, 1.0)
        self._begin_instance_op()
        if not self._remove_held_item(player_id):
            self._end_instance_op()
            return False
        if player_id in self._held_by_player:
            del self._held_by_player[player_id]
        self.NotifyToClient(player_id, "VerityHideHoldUiEvent", {})
        self._purge_ghost_verity_items(player_id)
        dim = self._get_player_dimension(player_id)
        launch_pos = (
            pos[0] + direction[0] * 0.8,
            pos[1] + 1.2,
            pos[2] + direction[2] * 0.8,
        )
        mob_id = self._spawn_mob_at_pos(launch_pos, dim, for_throw=True)
        if not mob_id:
            self._throw_state = None
            self._end_instance_op()
            self._give_held_item(player_id)
            self._held_by_player[player_id] = True
            self.NotifyToClient(player_id, "VerityShowHoldUiEvent", {})
            return False
        self._apply_throw_motion(mob_id, direction, player_id)
        self._end_instance_op()
        self._broadcast_sys_line("sys_throw_00", entity_id=mob_id, player_id=player_id)
        return True

    def _update_throw_physics(self):
        state = self._throw_state
        if not state or not state.get("manual"):
            return
        mob_id = state.get("mob_id")
        vel = state.get("vel") or [0.0, 0.0, 0.0]
        pos = state.get("pos") or [0.0, 64.0, 0.0]
        dim = state.get("dim", 0)
        vel[1] -= THROW_GRAVITY
        pos[0] += vel[0]
        pos[1] += vel[1]
        pos[2] += vel[2]
        ground = self._ground_foot_pos(pos[0], pos[2], dim, pos[1])
        ground_y = ground[1]
        if vel[1] <= 0.0 and pos[1] <= ground_y + 0.15:
            pos[1] = ground_y
            if vel[1] < -0.02:
                vel[1] = -vel[1] * THROW_BOUNCE
                vel[0] *= 0.92
                vel[2] *= 0.92
                state["bounces"] = int(state.get("bounces", 0)) + 1
            else:
                vel[1] = 0.0
        if mob_id and self._entity_exists(mob_id):
            try:
                CF.CreatePos(mob_id).SetFootPos((pos[0], pos[1], pos[2]))
            except Exception:
                pass
        state["vel"] = vel
        state["pos"] = pos
        speed = math.sqrt(vel[0] * vel[0] + vel[1] * vel[1] + vel[2] * vel[2])
        if state.get("bounces", 0) >= THROW_MAX_BOUNCES or speed < THROW_MIN_SPEED:
            self._settle_throw_landing(state)

    def _update_throw_physx_settle(self):
        state = self._throw_state
        if not state or state.get("manual"):
            return
        if self._tick < int(state.get("until_tick") or 0):
            return
        self._finish_throw(state.get("mob_id"))

    def _on_place_request(self, args):
        player_id = args.get("__id__") or args.get("playerId")
        if not player_id:
            player_id = self._get_host_id()
        self._place_verity(player_id)

    def _on_throw_request(self, args):
        player_id = args.get("__id__") or args.get("playerId")
        if not player_id:
            player_id = self._get_host_id()
        self._throw_severity(player_id)

    def _on_player_attack(self, args):
        player_id = args.get("playerId")
        victim_id = args.get("victimId")
        if not victim_id:
            return
        if str(victim_id) == str(self._mob_id):
            vtype = self._get_entity_type(victim_id)
            if vtype and vtype != MOB_ENTITY and MOB_ENTITY not in vtype:
                return
            args["cancel"] = True
            args["damage"] = 0
            args["isValid"] = 1
            self._complain_about_attack(player_id)
            return
        host_id = self._get_host_id()
        if not self._mob_id or not self._entity_exists(self._mob_id):
            return
        if player_id != host_id:
            return
        if victim_id == player_id:
            return
        vtype = self._get_entity_type(victim_id)
        if not vtype or "player" in vtype:
            return
        if vtype in (BOX_ENTITY, MOB_ENTITY):
            return
        self._mob_attack_entity(victim_id)

    def _bump_host_emotion(self, player_id, affection_delta=-6, anger_delta=12):
        if not player_id:
            player_id = self._get_host_id()
        if not player_id:
            return
        ctx = self._get_player_context(player_id)
        try:
            import veritySoul as soul
            soul.snapshot_affection(ctx)
            soul.apply_provocation(ctx, affection_delta, anger_delta)
        except Exception:
            ctx["affection"] = max(0, int(ctx.get("affection") or 50) + int(affection_delta))
            ctx["anger"] = min(100, int(ctx.get("anger") or 0) + int(anger_delta))
        self._save_player_context(player_id, ctx)
        self._sync_mob_mood_from_context(player_id)
        self._check_affection_monster_trigger()

    def _sync_mob_mood_from_context(self, player_id):
        if not self._mob_id or not self._entity_exists(self._mob_id):
            return
        ctx = self._get_player_context(player_id or self._get_host_id())
        try:
            import veritySoul as soul
            aff = soul.affection_value(ctx or {})
            anger = int((ctx or {}).get("anger") or 0)
        except Exception:
            return
        if aff <= AFFECTION_MONSTER_THRESHOLD + 8:
            self._set_mood(MOOD_ANGRY)
        elif anger >= 35:
            self._set_mood(MOOD_ANGRY)
        elif anger >= 18:
            self._set_mood(MOOD_ANNOYED)

    def _complain_about_attack(self, player_id):
        now = self._tick
        last = self._complaint_cooldown.get("attack", 0)
        if now - last < COMPLAINT_COOLDOWN_TICKS:
            return
        self._complaint_cooldown["attack"] = now
        self._mark_combat()
        self._broadcast_chat(random.choice(ATTACK_COMPLAINTS))
        self._set_mood(MOOD_ANGRY)
        self._bump_host_emotion(player_id, affection_delta=-8, anger_delta=15)

    def _set_mood(self, variant, duration_ticks=MOOD_AUTO_CALM_TICKS):
        """Swap Verity's face (minecraft:variant). See render Array.mood."""
        if not self._mob_id or not self._entity_exists(self._mob_id):
            return
        if self._is_intro_expression_locked():
            if variant not in (MOOD_HURT, MOOD_HAPPY):
                return
        if variant > MOOD_ABNORMAL_SHUT:
            variant = MOOD_HAPPY
        if self._mob_mood == variant and self._mood_mob_id == self._mob_id:
            if variant not in MOOD_TRANSIENT and variant != MOOD_HAPPY:
                self._mood_reset_tick = self._tick + duration_ticks
            return
        try:
            CF.CreateEntityDefinitions(self._mob_id).SetVariant(variant)
        except Exception as exc:
            print("Verity mood set error: %s" % exc)
        try:
            CF.CreateModAttr(self._mob_id).SetAttr("verity_face", variant, True)
        except Exception:
            pass
        self._mob_mood = variant
        self._mood_mob_id = self._mob_id
        if variant in MOOD_TRANSIENT:
            self._mood_reset_tick = 0
        elif variant != MOOD_HAPPY:
            self._mood_reset_tick = self._tick + duration_ticks
        else:
            self._mood_reset_tick = 0

    def _tick_mood_decay(self):
        if self._mob_mood in MOOD_TRANSIENT or self._mob_mood == MOOD_HAPPY:
            return
        if self._is_intro_expression_locked():
            return
        if not self._mood_reset_tick:
            return
        if self._tick >= self._mood_reset_tick:
            self._set_mood(MOOD_HAPPY)

    def _player_looking_at_entity(self, player_id, target_id, max_dist=12.0):
        """Best-effort raycast check: is the player's camera pointed at
        target_id within max_dist blocks? Fails safe (returns False) if the
        ray API is unavailable for any reason."""
        if not player_id or not target_id:
            return False
        try:
            eye_pos = CF.CreatePos(player_id).GetFootPos()
            if not eye_pos:
                return False
            eye_pos = (eye_pos[0], eye_pos[1] + 1.5, eye_pos[2])
            rot = CF.CreateRot(player_id).GetRot()
            direction = serverApi.GetDirFromRot(rot)
            dim = self._get_player_dimension(player_id)
            enum_mod = serverApi.GetMinecraftEnum()
            hits = CF.CreateGame(LEVEL_ID).getEntitiesOrBlockFromRay(
                dim, eye_pos, direction, int(max_dist), False,
                enum_mod.RayFilterType.OnlyEntities,
            )
        except Exception:
            return False
        for hit in hits or []:
            try:
                hid = hit.get("id") or hit.get("entityId") or hit.get("Id")
            except Exception:
                hid = None
            if hid is not None and str(hid) == str(target_id):
                return True
        return False

    def _update_jumpscare(self):
        """Verity occasionally flashes an evil expression when the player
        isn't looking, then holds it a few seconds after being noticed
        before playing it off with a line like "what's wrong?"."""
        if self._monster_ids or self._throw_state or self._pickup_in_progress:
            return
        if not self._mob_id or not self._entity_exists(self._mob_id):
            self._jumpscare_active = False
            return
        if self._tick < self._spawn_grace_until:
            return
        if self._is_intro_expression_locked():
            return
        if self._verity_appeared_tick and self._tick - self._verity_appeared_tick < JUMPSCARE_MIN_ALIVE_TICKS:
            return
        host_id = self._get_host_id()
        if not host_id:
            return
        if self._player_holds_held_item(host_id):
            return
        if not self._jumpscare_active:
            if self._tick < self._jumpscare_cooldown_until:
                return
            if self._mob_mood != MOOD_HAPPY:
                return  # don't layer the scare on top of an existing mood
            if random.random() > JUMPSCARE_ROLL_CHANCE:
                return
            if self._player_looking_at_entity(host_id, self._mob_id, JUMPSCARE_LOOK_RADIUS):
                return  # only sneak the scare in while unwatched
            try:
                CF.CreateEntityDefinitions(self._mob_id).SetVariant(MOOD_EVIL)
            except Exception:
                return
            self._jumpscare_active = True
            self._jumpscare_start_tick = self._tick
            self._jumpscare_seen_tick = 0
            return
        # Scare is active — watch for the player noticing her.
        if self._tick - self._jumpscare_start_tick > JUMPSCARE_MAX_DURATION_TICKS:
            self._end_jumpscare(announce=False)
            return
        if self._jumpscare_seen_tick:
            if self._tick - self._jumpscare_seen_tick >= JUMPSCARE_REVEAL_HOLD_TICKS:
                self._end_jumpscare(announce=True)
            return
        if self._player_looking_at_entity(host_id, self._mob_id, JUMPSCARE_LOOK_RADIUS):
            self._jumpscare_seen_tick = self._tick

    def _end_jumpscare(self, announce):
        self._jumpscare_active = False
        self._jumpscare_cooldown_until = self._tick + JUMPSCARE_MIN_COOLDOWN_TICKS
        try:
            if self._mob_id and self._entity_exists(self._mob_id):
                CF.CreateEntityDefinitions(self._mob_id).SetVariant(MOOD_HAPPY)
        except Exception:
            pass
        if announce:
            self._broadcast_chat_delayed(random.choice(JUMPSCARE_LINES))

    def _check_fire_lava_hazard(self):
        """minecraft:fire_immune blocks normal damage events, so fire/lava
        exposure can't rely on _on_damage. Scan the block Verity is standing
        in/on directly instead."""
        if not self._mob_id or not self._entity_exists(self._mob_id):
            return
        pos = self._get_foot_pos(self._mob_id)
        if not pos:
            return
        dim = self._get_player_dimension(self._mob_id)
        hazard = False
        try:
            bx = int(math.floor(pos[0]))
            bz = int(math.floor(pos[2]))
            by0 = int(math.floor(pos[1]))
            for dy in (0, 1):
                name = self._block_name_at(bx, by0 + dy, bz, dim)
                if name in FIRE_LAVA_BLOCK_NAMES:
                    hazard = True
                    break
        except Exception:
            return
        if not hazard:
            return
        now = self._tick
        last_fire = self._complaint_cooldown.get("fire", 0)
        if now - last_fire > COMPLAINT_COOLDOWN_TICKS:
            self._complaint_cooldown["fire"] = now
            self._broadcast_chat(random.choice(FIRE_COMPLAINTS))
            self._set_mood(MOOD_ANGRY)
            host_id = self._get_host_id()
            self._bump_host_emotion(host_id, affection_delta=-5, anger_delta=10)

    def _ensure_start_box(self):
        """Keep trying to place the starter box until one exists."""
        if self._verity_started:
            return
        if self._tick <= self._spawn_grace_until:
            return
        if self._has_living_instance():
            self._initial_spawn_done = True
            return
        host_id = self._get_host_id()
        if not host_id:
            return
        if not self._is_world_ready(host_id):
            return
        if self._tick - self._last_spawn_retry_tick < SPAWN_RETRY_INTERVAL:
            return
        self._last_spawn_retry_tick = self._tick
        if self._spawn_box_near_player(host_id):
            self._initial_spawn_done = True
            print("Verity ensure_start_box spawned box")

    # ------------------------------------------------------------------
    # Spawn
    # ------------------------------------------------------------------
    AIR_BLOCKS = (
        "minecraft:air",
        "minecraft:cave_air",
        "minecraft:void_air",
    )

    def _block_name_at(self, x, y, z, dim):
        try:
            block = CF.CreateBlockInfo(LEVEL_ID).GetBlockNew((x, y, z), dim)
            if block:
                return block.get("name") or ""
        except Exception:
            pass
        return ""

    def _is_air_block(self, name):
        if not name:
            return True
        return name in self.AIR_BLOCKS

    def _is_spawn_clear(self, x, y, z, dim):
        floor_name = self._block_name_at(x, y - 1, z, dim)
        if self._is_air_block(floor_name):
            return False
        if not self._is_air_block(self._block_name_at(x, y, z, dim)):
            return False
        if not self._is_air_block(self._block_name_at(x, y + 1, z, dim)):
            return False
        return True

    def _is_world_ready(self, player_id):
        if self._tick < self._world_ready_tick:
            return False
        pos = self._get_player_foot_pos(player_id)
        if not pos:
            return False
        dim = self._get_player_dimension(player_id)
        try:
            top = CF.CreateBlockInfo(LEVEL_ID).GetTopBlockHeight(
                (int(pos[0]), int(pos[2])), dim
            )
            return top is not None
        except Exception:
            return False

    def _find_safe_spawn_pos(self, player_id):
        pos = self._get_player_foot_pos(player_id)
        if not pos:
            return None
        dim = self._get_player_dimension(player_id)
        px = int(pos[0])
        pz = int(pos[2])
        candidates = []
        for radius in range(1, SPAWN_SEARCH_RADIUS + 1):
            for dx in range(-radius, radius + 1):
                for dz in range(-radius, radius + 1):
                    if abs(dx) != radius and abs(dz) != radius:
                        continue
                    bx = px + dx
                    bz = pz + dz
                    try:
                        top = CF.CreateBlockInfo(LEVEL_ID).GetTopBlockHeight((bx, bz), dim)
                    except Exception:
                        top = None
                    if top is None:
                        continue
                    by = int(top) + 1
                    if not self._is_spawn_clear(bx, by, bz, dim):
                        continue
                    dist = math.sqrt(float(dx * dx + dz * dz))
                    candidates.append((dist, (float(bx) + 0.5, float(by), float(bz) + 0.5)))
        if not candidates:
            return None
        candidates.sort(key=lambda item: item[0])
        return candidates[0][1]

    def _spawn_box_near_player(self, player_id):
        self._enforce_single_instance()
        if self._has_living_instance():
            return False
        if not self._is_world_ready(player_id):
            return False
        spawn_pos = self._find_safe_spawn_pos(player_id)
        if not spawn_pos:
            print("Verity spawn box skipped: no safe ground position")
            return False
        self._spawn_grace_until = self._tick + 40
        self._allow_spawn_enter()
        try:
            box_id = self.CreateEngineEntityByTypeStr(
                BOX_ENTITY, spawn_pos, (0.0, 0.0), 0, False, True
            )
        finally:
            self._allow_spawn_exit()
        if not box_id:
            print("Verity spawn box failed: CreateEngineEntityByTypeStr returned None")
            return False
        self._register_entity(box_id, BOX_ENTITY)
        try:
            CF.CreateModAttr(box_id).SetPersistent(True)
        except Exception:
            pass
        self._enforce_single_instance()
        self.BroadcastToAllClient("VerityBoxSpawnEvent", {"entityId": box_id})
        print("Verity spawn box ok id=%s pos=%s" % (box_id, spawn_pos))
        return True

    def _on_player_join(self, args):
        player_id = args.get("id")
        if not player_id:
            return
        self._schedule(2.0, self._try_give_guide_book_once, player_id, 0)
        host_id = self._get_host_id()
        if host_id:
            self._host_id = host_id
        if host_id and player_id != host_id:
            return
        if self._world_ready_tick <= 0:
            self._world_ready_tick = self._tick + int(SPAWN_WORLD_READY_DELAY * 20.0)
        if self._initial_spawn_scheduled:
            return
        self._initial_spawn_scheduled = True
        self._schedule(SPAWN_WORLD_READY_DELAY, self._try_initial_spawn_once)
        self._schedule(SPAWN_WORLD_READY_DELAY + 4.0, self._try_initial_spawn_once)
        if self._player_holds_held_item(player_id):
            self._held_by_player[player_id] = True
            self._schedule(1.0, self._notify_show_hold_ui, player_id)
        if self._monster_horror_active and player_id:
            self._force_player_survival_for_horror(player_id, save_previous=True)

    def _force_player_survival_for_horror(self, player_id, save_previous=False):
        if not player_id:
            return
        try:
            pcomp = CF.CreatePlayer(player_id)
            if save_previous and player_id not in self._monster_prev_gametype:
                self._monster_prev_gametype[player_id] = pcomp.GetPlayerGameType()
            pcomp.SetPlayerGameType(GAME_TYPE_SURVIVAL)
        except Exception:
            pass

    def _begin_monster_horror(self):
        """Lock world into repeating night + survival until monster event ends."""
        self._monster_horror_active = True
        self._monster_horror_sound_token = int(self._monster_horror_sound_token or 0) + 1
        if self._monster_horror_sound_token <= 0:
            self._monster_horror_sound_token = 1
        self._monster_last_roar_tick = self._tick
        for pid in serverApi.GetPlayerList() or []:
            self._force_player_survival_for_horror(pid, save_previous=True)
        try:
            CF.CreateGame(LEVEL_ID).SetDefaultGameType(GAME_TYPE_SURVIVAL)
        except Exception:
            pass
        try:
            CF.CreateTime(LEVEL_ID).SetTimeOfDay(NIGHT_TIME_TICKS)
        except Exception:
            pass

    def _enforce_monster_horror_world(self):
        if not self._monster_horror_active:
            return
        if self._tick % MONSTER_HORROR_ENFORCE_INTERVAL != 0:
            return
        try:
            CF.CreateTime(LEVEL_ID).SetTimeOfDay(NIGHT_TIME_TICKS)
        except Exception:
            pass
        try:
            CF.CreateGame(LEVEL_ID).SetDefaultGameType(GAME_TYPE_SURVIVAL)
        except Exception:
            pass
        for pid in serverApi.GetPlayerList() or []:
            try:
                pcomp = CF.CreatePlayer(pid)
                if int(pcomp.GetPlayerGameType()) != GAME_TYPE_SURVIVAL:
                    pcomp.SetPlayerGameType(GAME_TYPE_SURVIVAL)
            except Exception:
                pass

    def _maybe_repeat_monster_roar(self):
        if not self._monster_horror_active or not self._monster_ids:
            return
        if self._tick - self._monster_last_roar_tick < MONSTER_ROAR_REPEAT_TICKS:
            return
        self._monster_last_roar_tick = self._tick
        self._broadcast_monster_sound({
            "sound": MONSTER_ROAR_SOUND,
            "x": 0.0, "y": 0.0, "z": 0.0,
            "queue": False,
            "interrupt": False,
            "bgm": False,
            "monsterHorror": True,
            "loop": False,
        })

    def _cancel_monster_pending_schedules(self):
        skip = (self._monster_intro_then_charge,)
        if not self._pending:
            return
        self._pending = [entry for entry in self._pending if entry[1] not in skip]

    def _active_monster_sound_token(self):
        if not self._monster_horror_active:
            return 0
        return int(self._monster_horror_sound_token or 0)

    def _broadcast_monster_sound(self, payload):
        token = self._active_monster_sound_token()
        if token <= 0:
            return
        payload = dict(payload)
        payload["horrorToken"] = token
        self.BroadcastToAllClient("VerityPlaySoundEvent", payload)

    def _stop_monster_sounds(self):
        self._monster_horror_sound_token = 0
        self.BroadcastToAllClient("VerityStopMonsterSoundEvent", {})

    def _on_game_type_changed(self, args):
        if not self._monster_horror_active:
            return
        player_id = args.get("playerId")
        try:
            new_gt = int(args.get("newGameType"))
        except Exception:
            return
        if new_gt == GAME_TYPE_SURVIVAL:
            return
        try:
            CF.CreateGame(LEVEL_ID).SetDefaultGameType(GAME_TYPE_SURVIVAL)
        except Exception:
            pass
        for pid in serverApi.GetPlayerList() or []:
            try:
                CF.CreatePlayer(pid).SetPlayerGameType(GAME_TYPE_SURVIVAL)
            except Exception:
                pass
        if new_gt == GAME_TYPE_CREATIVE:
            taunt_pid = player_id or self._get_host_id()
            last = int(self._monster_creative_taunt_tick.get(taunt_pid) or 0)
            if self._tick - last >= 60:
                self._monster_creative_taunt_tick[taunt_pid] = self._tick
                self._broadcast_chat(random.choice(MONSTER_CREATIVE_TAUNT_LINES))

    def _notify_show_hold_ui(self, player_id):
        if player_id and self._player_holds_held_item(player_id):
            self.NotifyToClient(player_id, "VerityShowHoldUiEvent", {})

    def _try_initial_spawn_once(self):
        if self._initial_spawn_done:
            return
        self._enforce_single_instance()
        if self._has_living_instance():
            self._initial_spawn_done = True
            return
        host_id = self._get_host_id()
        if not host_id:
            if self._spawn_attempts < 8:
                self._spawn_attempts += 1
                self._schedule(2.0, self._try_initial_spawn_once)
            return
        if self._spawn_box_near_player(host_id):
            self._initial_spawn_done = True
            return
        if self._spawn_attempts < 8:
            self._spawn_attempts += 1
            self._schedule(2.0, self._try_initial_spawn_once)

    def _on_add_entity(self, args):
        entity_id = args.get("id")
        type_str = args.get("engineTypeStr") or self._get_entity_type(entity_id)
        if type_str == MONSTER_ENTITY:
            self._handle_monster_spawn(entity_id)
            return
        if type_str not in (BOX_ENTITY, MOB_ENTITY):
            return

        if self._allow_spawn_depth > 0:
            self._register_entity(entity_id, type_str)
            if type_str == MOB_ENTITY:
                host_id = self._get_host_id()
                if host_id:
                    self._bind_mob_to_host(entity_id, host_id)
            return

        self._enforce_single_instance()
        if type_str == MOB_ENTITY:
            if self._mob_id and self._mob_id != entity_id:
                self._reject_duplicate_spawn(entity_id)
                return
            if self._box_id and self._entity_exists(self._box_id):
                self._reject_duplicate_spawn(entity_id)
                return
            self._register_entity(entity_id, MOB_ENTITY)
            host_id = self._get_host_id()
            if host_id:
                self._bind_mob_to_host(entity_id, host_id)
            return

        if self._mob_id and self._entity_exists(self._mob_id):
            self._reject_duplicate_spawn(entity_id)
            return
        if self._box_id and self._box_id != entity_id and self._entity_exists(self._box_id):
            self._reject_duplicate_spawn(entity_id)
            return
        self._register_entity(entity_id, BOX_ENTITY)
        self.BroadcastToAllClient("VerityBoxSpawnEvent", {"entityId": entity_id})

    def _on_spawn_mob(self, args):
        if self._allow_spawn_depth > 0 or self._tick <= self._spawn_grace_until:
            return
        identifier = args.get("identifier") or args.get("realIdentifier") or ""
        if identifier == MONSTER_ENTITY:
            return
        if identifier not in (BOX_ENTITY, MOB_ENTITY):
            return
        self._enforce_single_instance()
        if self._has_living_instance():
            args["cancel"] = True
            self._notify_all(LIMIT_ONE_MSG)

    def _on_entity_remove(self, args):
        entity_id = args.get("id")
        if entity_id in self._monster_ids:
            self._monster_ids.discard(entity_id)
            return
        if entity_id == self._box_id:
            self._box_id = None
            self._woken = False
        if entity_id == self._mob_id:
            self._mob_id = None
            if not self._pickup_in_progress and self._instance_op_depth <= 0:
                host_id = self._get_host_id()
                if host_id and self._verity_started and not self._player_has_held_item(host_id):
                    self._schedule(0.15, self._respawn_mob_after_kill, host_id)
        throw_mob = self._throw_state.get("mob_id") if self._throw_state else None
        if entity_id == throw_mob and self._throw_state:
            self._throw_state["mob_id"] = None
        elif entity_id == throw_mob:
            self._throw_state = None
        if self._has_living_instance():
            return
        if not self._verity_started:
            self._initial_spawn_done = False
            self._last_spawn_retry_tick = 0

    def _respawn_mob_after_kill(self, player_id):
        if self._mob_id and self._entity_exists(self._mob_id):
            return
        if self._player_has_held_item(player_id):
            return
        if self._pickup_in_progress:
            return
        pos = self._get_player_foot_pos(player_id)
        if not pos:
            return
        self._begin_instance_op()
        try:
            mob_id = self._spawn_mob_at_pos(
                (pos[0] + 0.8, pos[1], pos[2] + 0.8),
                self._get_player_dimension(player_id),
            )
        finally:
            self._end_instance_op()
        if mob_id:
            self._mob_id = mob_id
            if self._tick - self._kill_taunt_tick > 80:
                self._kill_taunt_tick = self._tick
                self._broadcast_sys_line("sys_kill_respawn_00", player_id=player_id)

    # ------------------------------------------------------------------
    # Summon item guard
    # ------------------------------------------------------------------
    def _is_summon_item(self, item_dict):
        if not item_dict:
            return False
        name = item_dict.get("itemName") or item_dict.get("newItemName") or ""
        return name == SUMMON_ITEM

    def _is_monster_summon_item(self, item_dict):
        if not item_dict:
            return False
        name = item_dict.get("itemName") or item_dict.get("newItemName") or ""
        return name == MONSTER_SUMMON_ITEM

    def _block_summon_if_needed(self, player_id, cancel_args):
        self._enforce_single_instance()
        if not self._has_living_instance():
            return False
        if cancel_args is not None:
            if "ret" in cancel_args:
                cancel_args["ret"] = True
            if "cancel" in cancel_args:
                cancel_args["cancel"] = True
        self._notify_limit(player_id)
        return True

    def _on_item_use_on(self, args):
        player_id = args.get("entityId")
        item_dict = args.get("itemDict")
        if self._is_monster_summon_item(item_dict):
            return
        if not self._is_summon_item(item_dict):
            return
        self._block_summon_if_needed(player_id, args)

    def _on_item_try_use(self, args):
        player_id = args.get("playerId")
        item_dict = args.get("itemDict")
        if self._is_monster_summon_item(item_dict):
            return
        if not self._is_summon_item(item_dict):
            return
        self._block_summon_if_needed(player_id, args)

    def _handle_monster_spawn(self, entity_id):
        """Monster spawns far away; intro BGM plays alone, then roar + rush."""
        if not self._monster_horror_active:
            self._begin_monster_horror()
        self._monster_ids.add(entity_id)
        host_id = self._get_host_id()
        if host_id:
            pos = self._get_pos(host_id)
            if pos:
                import math as _math
                angle = random.random() * 2.0 * _math.pi
                fx = pos[0] + MONSTER_SPAWN_DISTANCE * _math.cos(angle)
                fz = pos[2] + MONSTER_SPAWN_DISTANCE * _math.sin(angle)
                dim = self._get_player_dimension(host_id)
                far_pos = self._ground_foot_pos(fx, fz, dim, pos[1])
                try:
                    CF.CreatePos(entity_id).SetFootPos(far_pos)
                except Exception:
                    pass
        # The entity's own vanilla AI (nearest_attackable_target / melee_attack,
        # 120-block search radius) would otherwise start chasing the player the
        # instant it spawns — long before the appearance sound/roar finishes.
        # Freeze native AI now; it's re-enabled (script-driven) only once the
        # intro delay elapses in _monster_intro_then_charge.
        try:
            CF.CreateControlAi(entity_id).SetBlockControlAi(False)
        except Exception:
            pass
        self._affection_monster_pending = False
        self._affection_monster_pending_since = 0
        self._affection_monster_last_tick = self._tick
        self._broadcast_monster_sound({
            "sound": MONSTER_SPAWN_SOUND,
            "x": 0.0, "y": 0.0, "z": 0.0,
            "queue": False,
            "interrupt": False,
            "bgm": False,
            "monsterHorror": True,
            "loop": True,
        })
        zh = random.choice(MONSTER_SPAWN_LINES)
        self._broadcast_chat(zh)
        self._schedule(
            MONSTER_INTRO_MUSIC_SEC,
            self._monster_intro_then_charge,
            entity_id,
        )

    def _monster_intro_then_charge(self, entity_id):
        """After appearance music finishes: teleport near player, roar once, chase."""
        if not self._monster_horror_active or not self._active_monster_sound_token():
            return
        if entity_id not in self._monster_ids or not self._entity_exists(entity_id):
            return
        host_id = self._get_host_id()
        if not host_id:
            return
        pos = self._get_player_foot_pos(host_id)
        if pos:
            import math as _math
            angle = random.random() * 2.0 * _math.pi
            dist = MONSTER_CHARGE_DISTANCE
            nx = pos[0] + dist * _math.cos(angle)
            nz = pos[2] + dist * _math.sin(angle)
            dim = self._get_player_dimension(host_id)
            near_pos = self._ground_foot_pos(nx, nz, dim, pos[1])
            try:
                CF.CreatePos(entity_id).SetFootPos(near_pos)
            except Exception:
                pass
        try:
            CF.CreateAction(entity_id).SetAttackTarget(host_id)
        except Exception:
            pass
        self._monster_charge_released.add(entity_id)
        self._monster_chase_player(entity_id, host_id)
        if entity_id not in self._monster_roar_done:
            self._monster_roar_done.add(entity_id)
            self._broadcast_monster_sound({
                "sound": MONSTER_ROAR_SOUND,
                "x": 0.0, "y": 0.0, "z": 0.0,
                "queue": False,
                "interrupt": False,
                "bgm": False,
                "monsterHorror": True,
                "loop": False,
            })
            self._monster_last_roar_tick = self._tick

    def _broadcast_chat_delayed(self, zh_text, delay=None):
        """Delay a synthetic Verity line so it doesn't race ahead of the
        player's own just-sent chat message in the chat log."""
        if delay is None:
            delay = CHAT_REPLY_DELAY
        self._schedule(delay, self._broadcast_chat, zh_text)

    def _revert_monster_to_verity(self, player_id, lines=None):
        """Apology (or a kill) ends the monster event — destroy all monster
        instances, respawn ball, restore whatever game mode we forced."""
        if not self._monster_ids and not self._monster_horror_active:
            return
        self._monster_horror_active = False
        self._cancel_monster_pending_schedules()
        self._stop_monster_sounds()
        for mid in list(self._monster_ids):
            try:
                self.DestroyEntity(mid)
            except Exception:
                pass
            self._monster_roar_done.discard(mid)
            self._monster_charge_released.discard(mid)
        self._monster_ids.clear()
        self._monster_melee_tick = {}
        self._monster_creative_taunt_tick = {}
        self._restore_forced_gametypes()
        # respawn ball at player if ball not alive
        if not self._mob_id or not self._entity_exists(self._mob_id):
            pos = self._get_player_foot_pos(player_id)
            if not pos:
                pos = (0.0, 64.0, 0.0)
            spawn_pos = (pos[0] + 1.0, pos[1], pos[2])
            dim = self._get_player_dimension(player_id)
            self._allow_spawn_enter()
            try:
                mob_id = self.CreateEngineEntityByTypeStr(
                    MOB_ENTITY, spawn_pos, (0.0, 0.0), dim, False, True
                )
            finally:
                self._allow_spawn_exit()
            if mob_id:
                self._register_entity(mob_id, MOB_ENTITY)
                self._verity_started = True
                self.BroadcastToAllClient(
                    "VerityMobSpawnEvent", {"entityId": mob_id, "introFall": True}
                )
        self._set_mood(MOOD_HAPPY)
        zh = random.choice(lines or MONSTER_REVERT_LINES)
        self._broadcast_chat_delayed(zh)

    def _restore_forced_gametypes(self):
        """Undo the survival-mode lock we may have applied when Verity's
        affection dropped low enough to trigger the monster transformation."""
        for player_id, prev_type in list(self._monster_prev_gametype.items()):
            try:
                CF.CreatePlayer(player_id).SetPlayerGameType(prev_type)
            except Exception:
                pass
        self._monster_prev_gametype = {}

    def _on_player_die(self, args):
        dead_id = args.get("id")
        if not self._monster_horror_active or not self._monster_ids:
            return
        self._revert_monster_to_verity(dead_id, lines=MONSTER_KILL_APOLOGY_LINES)

    def _prepare_monster_move(self, monster_id):
        if not monster_id:
            return
        try:
            CF.CreateControlAi(monster_id).SetBlockControlAi(False)
        except Exception:
            pass

    def _monster_try_melee(self, monster_id, host_id):
        if not monster_id or not host_id:
            return
        last = int(self._monster_melee_tick.get(monster_id) or 0)
        if self._tick - last < MONSTER_ATTACK_COOLDOWN_TICKS:
            return
        self._monster_melee_tick[monster_id] = self._tick
        try:
            CF.CreateHurt(host_id).Hurt(
                float(MONSTER_ATTACK_DAMAGE),
                "entity_attack",
                monster_id,
                None,
                True,
                "verity_monster_melee",
            )
        except Exception:
            pass

    def _monster_chase_player(self, monster_id, host_id):
        if not monster_id or not host_id:
            return
        host_pos = self._get_player_foot_pos(host_id)
        if not host_pos:
            return
        mpos = self._get_foot_pos(monster_id)
        if not mpos:
            return
        try:
            CF.CreateAction(monster_id).SetAttackTarget(host_id)
        except Exception:
            pass
        self._prepare_monster_move(monster_id)
        dist = self._dist_xz(mpos, host_pos)
        if dist <= MONSTER_MELEE_RANGE:
            self._monster_try_melee(monster_id, host_id)
            return
        target = (float(host_pos[0]), float(host_pos[1]), float(host_pos[2]))
        try:
            CF.CreateMove(monster_id).SetMoveSetting(
                target,
                float(MONSTER_CHASE_SPEED),
                200,
                None,
            )
        except Exception:
            dx = host_pos[0] - mpos[0]
            dz = host_pos[2] - mpos[2]
            length = math.sqrt(dx * dx + dz * dz)
            if length < 0.05:
                return
            step = min(0.55, length - MONSTER_MELEE_RANGE * 0.5)
            nx = mpos[0] + dx / length * step
            nz = mpos[2] + dz / length * step
            dim = self._get_player_dimension(host_id)
            gpos = self._ground_foot_pos(nx, nz, dim, mpos[1])
            try:
                CF.CreatePos(monster_id).SetFootPos(gpos)
            except Exception:
                pass

    def _update_monster_ai(self):
        """Keep attack target on the nearest host — roar plays once on spawn."""
        self._enforce_monster_horror_world()
        self._maybe_repeat_monster_roar()
        if not self._monster_ids:
            return
        host_id = self._get_host_id()
        if not host_id:
            return
        for mid in list(self._monster_ids):
            if not self._entity_exists(mid):
                self._monster_ids.discard(mid)
                self._monster_roar_done.discard(mid)
                self._monster_charge_released.discard(mid)
                continue
            if mid not in self._monster_charge_released:
                # Still in the "distant intro" phase — stand still, no path chase,
                # so it doesn't reach the player before the roar/appearance sound.
                continue
            self._monster_chase_player(mid, host_id)

    def _player_has_verity_presence(self, player_id):
        if self._mob_id and self._entity_exists(self._mob_id):
            return True
        if player_id and self._player_has_any_verity_item(player_id):
            return True
        return False

    def _check_affection_monster_trigger(self):
        """If Verity's affection toward the player crashes low enough, she
        vanishes and the hostile monster form appears right around them —
        night is forced and the player is locked to survival for the scare."""
        if self._monster_ids or self._affection_monster_pending:
            return
        if self._instance_op_depth > 0 or self._pickup_in_progress:
            return
        if self._verity_transform_depth > 0:
            return
        host_id = self._get_host_id()
        if not host_id:
            return
        if not self._player_has_verity_presence(host_id):
            return
        ctx = self._get_player_context(host_id)
        try:
            import veritySoul as soul
            aff = soul.affection_value(ctx or {})
            anger = int((ctx or {}).get("anger") or 0)
        except Exception:
            aff = int((ctx or {}).get("affection") if (ctx or {}).get("affection") is not None else 50)
            anger = int((ctx or {}).get("anger") or 0)
        rage_break = anger >= ANGER_MONSTER_THRESHOLD and aff <= AFFECTION_MONSTER_THRESHOLD + 10
        if aff > AFFECTION_MONSTER_THRESHOLD and not rage_break:
            return
        now = self._tick
        if now - self._affection_monster_last_tick < AFFECTION_MONSTER_COOLDOWN_TICKS:
            return
        pos = self._get_player_foot_pos(host_id)
        if not pos:
            return
        had_mob = bool(self._mob_id and self._entity_exists(self._mob_id))
        if had_mob:
            mob_id = self._mob_id
            self._mob_id = None
            try:
                self.DestroyEntity(mob_id)
            except Exception:
                pass
        print("Verity monster transform aff=%d anger=%d had_mob=%s" % (aff, anger, had_mob))
        self._begin_monster_horror()
        import math as _math
        angle = random.random() * 2.0 * _math.pi
        dist = MONSTER_SPAWN_DISTANCE
        nx = pos[0] + dist * _math.cos(angle)
        nz = pos[2] + dist * _math.sin(angle)
        dim = self._get_player_dimension(host_id)
        near_pos = self._ground_foot_pos(nx, nz, dim, pos[1])
        self._affection_monster_pending = True
        self._affection_monster_pending_since = self._tick
        self._allow_spawn_enter()
        try:
            new_id = self.CreateEngineEntityByTypeStr(
                MONSTER_ENTITY, near_pos, (0.0, 0.0), dim, False, True
            )
            print("Verity monster spawn request id=%s type=%s pos=%s" % (
                new_id, MONSTER_ENTITY, near_pos))
        except Exception as exc:
            print("Verity monster spawn error: %s" % exc)
            self._affection_monster_pending = False
            self._affection_monster_pending_since = 0
        finally:
            self._allow_spawn_exit()

    def _clear_stale_affection_monster_pending(self):
        if not self._affection_monster_pending:
            return
        since = int(getattr(self, "_affection_monster_pending_since", 0) or 0)
        if not since:
            return
        if self._monster_ids:
            return
        if self._tick - since < 200:
            return
        self._affection_monster_pending = False
        self._affection_monster_pending_since = 0

    # ------------------------------------------------------------------
    # Interact / wake
    # ------------------------------------------------------------------
    def _on_interact(self, args):
        entity_id = args.get("interactEntityId")
        player_id = args.get("playerId")
        if not entity_id:
            return
        type_str = self._get_entity_type(entity_id)
        if type_str == MOB_ENTITY and entity_id == self._mob_id:
            self._pickup_severity(player_id)
            return
        if self._woken:
            return
        if type_str != BOX_ENTITY:
            return
        if self._mob_id and self._entity_exists(self._mob_id):
            self._notify_limit(args.get("playerId"))
            return
        self._box_id = entity_id
        self._woken = True
        pos = self._get_pos(entity_id)
        self.BroadcastToAllClient("VerityWakeEvent", {"entityId": entity_id})
        self._schedule(BOX_OPEN_SECONDS, self._finish_wake, entity_id, pos, player_id)

    def _finish_wake(self, box_id, pos, player_id=None):
        if not pos:
            pos = (0.0, 64.0, 0.0)
        try:
            import verityIntro as vintro
            vintro.mark_intro_complete(self)
        except Exception:
            pass
        if self._entity_exists(box_id):
            try:
                self.DestroyEntity(box_id)
            except Exception:
                pass
        if self._box_id == box_id:
            self._box_id = None
        self._allow_spawn_enter()
        try:
            mob_id = self.CreateEngineEntityByTypeStr(
                MOB_ENTITY, pos, (0.0, 0.0), 0, False, True
            )
        finally:
            self._allow_spawn_exit()
        if mob_id:
            self._register_entity(mob_id, MOB_ENTITY)
            self._verity_started = True
            self._spawn_grace_until = self._tick + 40
            try:
                CF.CreateModAttr(mob_id).SetPersistent(True)
            except Exception:
                pass
            self._enforce_single_instance()
            host_id = self._get_host_id()
            if host_id:
                self._bind_mob_to_host(mob_id, host_id)
            self.BroadcastToAllClient(
                "VerityMobSpawnEvent",
                {"entityId": mob_id, "introFall": True},
            )
            self._begin_intro_fall_expression(mob_id, player_id, play_opening=True)

    def _play_opening_greeting(self, mob_id, player_id=None):
        if not mob_id or mob_id != self._mob_id or not self._entity_exists(mob_id):
            return
        self._intro_expression_lock_until = 0
        self._set_mood(MOOD_HAPPY)
        self._verity_appeared_tick = self._tick
        self._broadcast_line(
            dialogue.OPENING_GREET_LINE,
            dialogue.OPENING_GREET_ZH,
            dialogue.OPENING_GREET_SOUND,
            mob_id,
            show_chat=True,
            player_id=player_id,
        )

    # ------------------------------------------------------------------
    # Follow (pathfinding only — no SetFootPos stepping)
    # ------------------------------------------------------------------
    def _get_player_dimension(self, player_id):
        try:
            return CF.CreateDimension(player_id).GetEntityDimensionId()
        except Exception:
            return 0

    def _safe_ground_pos(self, player_id, near_pos):
        if not near_pos:
            return None
        dim = self._get_player_dimension(player_id)
        bx = int(near_pos[0])
        bz = int(near_pos[2])
        by = int(near_pos[1])
        try:
            top = CF.CreateBlockInfo(LEVEL_ID).GetTopBlockHeight((bx, bz), dim)
            if top is not None:
                by = int(top) + 1
        except Exception:
            pass
        return (float(bx) + 0.5, float(by), float(bz) + 0.5)

    def _teleport_near(self, entity_id, player_id, target_pos):
        if not target_pos:
            return
        dest = self._safe_ground_pos(player_id, (
            target_pos[0] + 0.8,
            target_pos[1],
            target_pos[2] + 0.8,
        ))
        if not dest:
            dest = (target_pos[0] + 0.8, target_pos[1], target_pos[2] + 0.8)
        try:
            CF.CreatePos(entity_id).SetFootPos(dest)
        except Exception:
            try:
                CF.CreatePos(entity_id).SetPos(dest)
            except Exception:
                pass
        self._follow_stuck_ticks = 0
        self._follow_last_pos = dest

    def _rescue_from_burial(self, mob_id, player_id, force_shut=False):
        """Teleport Verity out from sand/gravel; long burial uses shut face."""
        if not mob_id or mob_id != self._mob_id or not self._entity_exists(mob_id):
            return
        if not self._is_entity_buried(mob_id) and not force_shut:
            return
        player_pos = self._get_player_foot_pos(player_id)
        if not player_pos:
            return
        self._teleport_near(mob_id, player_id, player_pos)
        self._buried_since_tick = 0
        if force_shut:
            self._set_mood(MOOD_ABNORMAL_SHUT)

    def _follow_target_pos(self, entity_pos, host_pos):
        dx = host_pos[0] - entity_pos[0]
        dz = host_pos[2] - entity_pos[2]
        dist = math.sqrt(dx * dx + dz * dz)
        if dist <= FOLLOW_STOP_DISTANCE:
            return None
        if dist < 0.05:
            return (host_pos[0], host_pos[1], host_pos[2])
        ratio = max(0.0, (dist - FOLLOW_DISTANCE) / dist)
        tx = entity_pos[0] + dx * ratio
        tz = entity_pos[2] + dz * ratio
        return (tx, host_pos[1], tz)

    def _update_follow_stuck(self, entity_id, entity_pos, moving):
        if not moving or not entity_pos:
            self._follow_stuck_ticks = 0
            self._follow_last_pos = entity_pos
            return False
        last = self._follow_last_pos
        if last:
            dx = entity_pos[0] - last[0]
            dz = entity_pos[2] - last[2]
            moved = math.sqrt(dx * dx + dz * dz)
            if moved < STUCK_MOVE_THRESHOLD:
                self._follow_stuck_ticks += AI_TICK_INTERVAL
            else:
                self._follow_stuck_ticks = 0
        self._follow_last_pos = entity_pos
        return self._follow_stuck_ticks >= STUCK_TELEPORT_TICKS

    def _entity_is_airborne(self, entity_id, dim=0):
        pos = self._get_foot_pos(entity_id)
        if not pos:
            return False
        below_y = int(math.floor(pos[1])) - 1
        block = self._block_name_at(int(math.floor(pos[0])), below_y, int(math.floor(pos[2])), dim)
        if not block or block == "minecraft:air":
            return True
        try:
            block_comp = CF.CreateBlockInfo(LEVEL_ID)
            solid = block_comp.GetBlockBasicInfo(block)
            if solid and not solid.get("solid"):
                return True
        except Exception:
            pass
        return False

    def _assist_entity_fall(self, entity_id, dim=0):
        if not entity_id or not self._entity_is_airborne(entity_id, dim):
            return
        pos = self._get_foot_pos(entity_id)
        if not pos:
            return
        fall_step = 0.55
        try:
            CF.CreatePos(entity_id).SetFootPos((pos[0], pos[1] - fall_step, pos[2]))
        except Exception:
            pass

    def _follow_host(self, entity_id, player_id, host_pos):
        if not entity_id or not host_pos:
            return
        ctx = self._get_player_context(player_id)
        if ctx and not ctx.get("will_follow", True):
            return
        entity_pos = self._get_foot_pos(entity_id)
        if not entity_pos:
            return
        dim = self._get_player_dimension(player_id)
        if self._entity_is_airborne(entity_id, dim):
            self._assist_entity_fall(entity_id, dim)
            return
        dist = self._dist_xz(entity_pos, host_pos)
        if dist >= TELEPORT_DISTANCE:
            self._teleport_near(entity_id, player_id, host_pos)
            return
        if dist >= FOLLOW_TELEPORT_DISTANCE:
            self._teleport_near(entity_id, player_id, host_pos)
            return
        if dist <= FOLLOW_STOP_DISTANCE:
            self._follow_stuck_ticks = 0
            return
        if dist < FOLLOW_WALK_MIN_DISTANCE:
            self._follow_stuck_ticks = 0
            return
        target = self._follow_target_pos(entity_pos, host_pos)
        if not target:
            return
        stuck = self._update_follow_stuck(entity_id, entity_pos, True)
        if stuck:
            self._teleport_near(entity_id, player_id, host_pos)
            return
        self._prepare_follow_move(entity_id)
        try:
            speed = FOLLOW_MOVE_SPEED
            if dist > 24.0:
                speed = FOLLOW_MOVE_SPEED * 1.25
            CF.CreateMove(entity_id).SetMoveSetting(
                target,
                speed,
                200,
                None,
            )
        except Exception:
            pass

    def _keep_near_host(self, entity_id, player_id, host_pos):
        self._follow_host(entity_id, player_id, host_pos)

    def _is_hostile(self, type_str):
        if not type_str or "player" in type_str or "villager" in type_str:
            return False
        if type_str in (BOX_ENTITY, MOB_ENTITY):
            return False
        for hint in HOSTILE_HINTS:
            if hint in type_str:
                return True
        return False

    def _get_combat_target(self, mob_id):
        try:
            target_id = CF.CreateAction(mob_id).GetAttackTarget()
        except Exception:
            return None
        if not target_id or str(target_id) in ("-1", "None"):
            return None
        target_id = str(target_id)
        if not self._entity_exists(target_id):
            return None
        return target_id

    def _is_in_combat(self, mob_id):
        """Only player-triggered combat window — not ambient villager/monster AI targets."""
        return self._tick < self._combat_until

    def _prepare_follow_move(self, entity_id):
        if not entity_id:
            return
        if self._tick >= self._combat_until:
            try:
                CF.CreateAction(entity_id).ResetAttackTarget()
            except Exception:
                pass
        try:
            CF.CreateControlAi(entity_id).SetBlockControlAi(True)
        except Exception:
            pass

    def _mark_combat(self):
        self._combat_until = self._tick + int(COMBAT_HOLD_SECONDS * 20.0)

    def _update_companion_ai(self):
        host_id = self._get_host_id()
        if not host_id:
            return
        host_pos = self._get_player_foot_pos(host_id)
        if not host_pos:
            return

        if not self._mob_id or not self._entity_exists(self._mob_id):
            return

        if self._throw_state and self._throw_state.get("mob_id") == self._mob_id:
            return

        if self._tick < self._throw_landed_until:
            # Just landed from a throw — give the player time to walk over
            # before the follow AI is allowed to teleport it back.
            return

        if self._is_in_combat(self._mob_id):
            mob_pos = self._get_foot_pos(self._mob_id)
            if mob_pos and self._dist_xz(mob_pos, host_pos) >= COMBAT_TELEPORT_DISTANCE:
                self._teleport_near(self._mob_id, host_id, host_pos)
            return

        ctx = self._get_player_context(host_id)
        if ctx and not ctx.get("will_follow", True):
            return

        dim = self._get_player_dimension(host_id)
        if self._entity_is_airborne(self._mob_id, dim):
            self._assist_entity_fall(self._mob_id, dim)
            return

        self._prepare_follow_move(self._mob_id)
        self._keep_near_host(self._mob_id, host_id, host_pos)

    def _is_villager_type(self, type_str):
        ts = type_str or ""
        return "villager" in ts or "wandering_trader" in ts

    def _find_villagers_near(self, player_id, radius):
        return self._find_entities_near(
            player_id, int(radius or VILLAGER_HUNT_RADIUS), self._is_villager_type
        )

    def _update_villager_hunter_ai(self):
        """Disabled — Verity does not hunt villagers."""
        return

    def _update_villager_hunter_ai_legacy(self):
        """Proactively hunt villagers after player grants permission."""
        if not self._mob_id or not self._entity_exists(self._mob_id):
            return
        if self._throw_state:
            return
        host_id = self._get_host_id()
        if not host_id:
            return
        targets = self._find_villagers_near(host_id, VILLAGER_HUNT_RADIUS)
        if not targets:
            return
        ctx = self._get_player_context(host_id)
        if not ctx.get("villager_attack_allowed"):
            pending = ctx.get("pending_question") or {}
            if pending.get("type") == "confirm_attack_villager":
                return
            until = int(ctx.get("villager_ask_until") or 0)
            if self._tick < until:
                return
            ctx["villager_ask_until"] = self._tick + VILLAGER_ASK_COOLDOWN
            try:
                import verityConversation as conv
                conv.set_pending_question(
                    ctx,
                    "confirm_attack_villager",
                    u"\u8981\u6211\u6253\u6751\u6c11\u5417\uff1f",
                    {"type": "attack_villager", "radius": VILLAGER_HUNT_RADIUS},
                    self._tick,
                )
            except Exception:
                pass
            self._save_player_context(host_id, ctx)
            self._broadcast_line(
                u"Want me to hit villagers?",
                u"\u9644\u8fd1\u6709\u6751\u6c11\uff0c\u8981\u6211\u6253\u5417\uff1f\u8bf4\u300c\u597d\u300d\u6216\u300c\u53bb\u6253\u300d\u3002",
                "combat_attack_villager_00",
                self._mob_id,
                True,
                host_id,
            )
            return
        target_id = targets[0]
        cur = self._get_combat_target(self._mob_id)
        if cur != target_id:
            self._mob_attack_entity(target_id)

    def _get_game_hour(self):
        try:
            time_val = int(CF.CreateTime(LEVEL_ID).GetTime())
            day_tick = time_val % 24000
            return (day_tick // 1000 + 6) % 24
        except Exception:
            return 12

    def _gather_scene(self, player_id):
        pos = self._get_player_foot_pos(player_id)
        if not pos:
            return None
        dim = self._get_player_dimension(player_id)
        entity_types = []
        try:
            nearby = CF.CreateGame(player_id).GetEntitiesAround(player_id, VILLAGE_SCAN_RADIUS, {}) or []
        except Exception:
            nearby = []
        for eid in nearby:
            if eid in (player_id, self._mob_id):
                continue
            entity_types.append(self._get_entity_type(eid))
        try:
            import verityEnvironment as env
            return env.scan_scene(
                self._block_name_at,
                int(pos[0]), int(pos[1]), int(pos[2]),
                dim,
                game_hour=self._get_game_hour(),
                entity_types=entity_types,
            )
        except Exception as exc:
            print("Verity scene scan error: %s" % exc)
            return None

    def _update_proactive_chat(self):
        """Verity proactively chats using relationship/memory context.
        Villager-hunting related content is excluded (see _update_villager_hunter_ai)."""
        return self._update_proactive_chat_legacy()

    def _update_proactive_chat_legacy(self):
        if not self._mob_id or not self._entity_exists(self._mob_id):
            return
        if self._throw_state:
            return
        if self._is_in_combat(self._mob_id):
            return
        host_id = self._get_host_id()
        if not host_id:
            return
        try:
            import verityProactive as proactive
            import verityMemory as mem
            ctx = self._get_player_context(host_id)
            if not proactive.should_speak(ctx, self._tick):
                return
            scene = None
            scan_tick = int(ctx.get("next_scene_scan_tick") or 0)
            if self._tick >= scan_tick:
                scene = self._gather_scene(host_id)
                ctx["last_scene"] = scene
                ctx["next_scene_scan_tick"] = self._tick + 200
            else:
                scene = ctx.get("last_scene")
            line = proactive.pick_line(ctx, scene)
            proactive.schedule_next(ctx, self._tick)
            self._save_player_context(host_id, ctx)
            if not line:
                return
            _topic, en, zh, sound, action = line
            mem.record_exchange(ctx, None, zh)
            try:
                import verityConversation as conv
                conv.append_message(ctx, "severity", zh, self._tick)
                conv.note_ai_reply(ctx, zh, action, self._tick)
            except Exception:
                pass
            ctx["turn_tick"] = self._tick
            self._save_player_context(host_id, ctx)
            self._broadcast_line(en, zh, sound, self._mob_id, True, host_id)
        except Exception as exc:
            print("Verity proactive error: %s" % exc)

    # ------------------------------------------------------------------
    # AI actions (give items, commands, combat, build)
    # ------------------------------------------------------------------
    def _run_command_as_player(self, player_id, cmd):
        if not cmd or not player_id:
            return
        cmd_str = cmd.strip()
        if not cmd_str.startswith("/"):
            cmd_str = "/" + cmd_str
        try:
            CF.CreateCommand(LEVEL_ID).SetCommand(cmd_str, player_id)
        except Exception:
            pass

    def _execute_summon_mob(self, player_id, mob_id, count):
        if not player_id or not mob_id:
            return
        try:
            import verityVanillaMobs as vm
            mob_id = vm.normalize_summon_id(mob_id)
        except Exception:
            pass
        if not mob_id:
            return
        try:
            count = max(1, min(int(count or 1), 30))
        except Exception:
            count = 1
        foot = self._get_player_foot_pos(player_id)
        if not foot:
            return
        dim = self._get_player_dimension(player_id)
        try:
            rot = CF.CreateRot(player_id).GetRot()
            direction = serverApi.GetDirFromRot(rot)
        except Exception:
            direction = (0.0, 0.0, 1.0)
        self._allow_spawn_enter()
        try:
            for i in range(count):
                ring = 1.2 + (i // 5) * 1.0
                ox = (i % 5) * 1.0
                oz = (i // 5) * 1.0
                bx = foot[0] + direction[0] * ring + ox * 0.6
                bz = foot[2] + direction[2] * ring + oz * 0.6
                spawned = False
                for try_ox, try_oz in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (-1, -1)):
                    spawn_pos = self._ground_foot_pos(
                        bx + try_ox, bz + try_oz, dim, foot[1]
                    )
                    try:
                        eid = self.CreateEngineEntityByTypeStr(
                            mob_id, spawn_pos, (0.0, 0.0), dim, False, False
                        )
                        if eid and self._entity_exists(eid):
                            spawned = True
                            break
                    except Exception:
                        pass
                if spawned:
                    continue
                spawn_pos = self._ground_foot_pos(bx, bz, dim, foot[1])
                short = mob_id.replace("minecraft:", "")
                for cmd in (
                    "summon %s %.1f %.1f %.1f" % (short, spawn_pos[0], spawn_pos[1], spawn_pos[2]),
                    "summon %s ~1 ~ ~" % short,
                    "execute as @s at @s run summon %s ~1 ~ ~" % short,
                ):
                    self._run_command_as_player(player_id, cmd)
        finally:
            self._allow_spawn_exit()

    # ------------------------------------------------------------------
    # Music offer system
    # ------------------------------------------------------------------
    MUSIC_TRACKS = ("verity.voice.yinyueyi", "verity.voice.yiyueer")
    MUSIC_OFFER_LINES = [
        u"\u8981\u4e0d\u8981\u6765\u70b9\u97f3\u4e50\uff1f\u6211\u6709\u4e0d\u9519\u7684\u5929\u6cd5\u3002\uff08\u8bf4\u300c\u597d\u300d\u5f00\u59cb\u64ad\u653e\uff09",
        u"\u6211\u80fd\u64ad\u70b9\u97f3\u4e50\uff0c\u8981\u5417\uff1f\uff08\u8bf4\u300c\u597d\u300d\u5c31\u5f00\u59cb\uff09",
        u"\u6709\u70b9\u61c2\uff0c\u6211\u53ef\u4ee5\u64ad\u97f3\u4e50\u3002\u60f3\u542c\u5417\uff1f",
    ]
    MUSIC_START_LINES = [
        u"\u5f00\u59cb\u64ad\u653e\u4e86\u3002\u4f60\u53ef\u4ee5\u8bf4\u300c\u6362\u4e00\u9996\u300d\uff08\u6700\u591a\u4e24\u6b21\uff09\u6216\u8005\u300c\u505c\u6b62\u97f3\u4e50\u300d\u3002",
        u"\u64ad\u653e\u4e2d\u3002\u8bf4\u300c\u6362\u4e00\u9996\u300d\u53ef\u4ee5\u5207\u6b4c\uff0c\u300c\u505c\u6b62\u300d\u53ef\u4ee5\u5173\u6389\u3002",
    ]
    MUSIC_SWITCH_LINES = [
        u"\u597d\uff0c\u6362\u4e00\u9996\u3002",
        u"\u6362\u5c31\u6362\u5427\u3002",
    ]
    MUSIC_NO_SWITCH_LINES = [
        u"\u522b\u6362\u4e86\u597d\u5417\uff1f\u5c31\u6b23\u8d4f\u8fd9\u9996\u5427\u3002",
        u"\u5df2\u7ecf\u6362\u4e86\u4e24\u6b21\u4e86\u3002\u5c31\u542c\u8fd9\u9996\uff0c\u4f60\u4f1a\u559c\u6b22\u7684\u3002",
    ]
    MUSIC_STOP_LINES = [
        u"\u597d\uff0c\u5173\u6389\u4e86\u3002",
        u"\u6682\u505c\u64ad\u653e\u3002",
    ]
    MUSIC_ALREADY_PLAYING = u"\u5df2\u7ecf\u5728\u64ad\u653e\u4e86\u54e6\u3002\u8bf4\u300c\u6362\u4e00\u9996\u300d\u6216\u8005\u300c\u505c\u6b62\u300d\u3002"
    MUSIC_PLAY_KEYWORDS = (
        u"\u97f3\u4e50", u"\u64ad\u653e", u"\u6765\u70b9\u97f3\u4e50", u"\u64ad\u97f3\u4e50",
        u"music", u"play music", u"play song",
    )
    MUSIC_STOP_KEYWORDS = (
        u"\u505c\u6b62", u"\u505c\u6b62\u97f3\u4e50", u"\u505c\u64ad", u"\u5173\u97f3\u4e50",
        u"\u4e0d\u8981\u97f3\u4e50", u"\u4e0d\u542c\u4e86", u"\u5173\u4e86", u"\u6682\u505c",
        u"stop", u"stop music", u"pause",
    )
    MUSIC_SWITCH_KEYWORDS = (
        u"\u6362\u4e00\u9996", u"\u6362\u6b4c", u"\u6362\u4e2a", u"\u5207\u6b4c",
        u"switch", u"next song", u"change song",
    )
    MUSIC_YES_KEYWORDS = (
        u"好", u"好啊", u"好呀", u"好的", u"可以", u"要", u"行", u"行啊", u"嗯", u"对",
        u"是的", u"来点", u"开始播放", u"播放吧", u"来一首", u"yes", u"ok", u"sure",
    )
    MUSIC_NO_KEYWORDS = (
        u"不要", u"不用", u"算了", u"不听", u"不", u"no", u"nope",
    )
    VERITY_APPEARED_GRACE_TICKS = 1800  # ~90s after Verity fully appears before first offer
    MUSIC_OFFER_MIN_GAP = 9000          # ~7.5 min between offers (not too frequent)

    def _update_music_offer(self):
        """Proactively offer music after Verity has been around for a while."""
        if not self._mob_id or not self._entity_exists(self._mob_id):
            return
        if self._music_offer_pending or self._music_state:
            return
        if not self._verity_appeared_tick:
            return
        now = self._tick
        # Wait ~1-2 minutes after Verity appears before ever offering
        if now - self._verity_appeared_tick < self.VERITY_APPEARED_GRACE_TICKS:
            return
        # Don't offer again too soon after music last played/stopped
        if now - self._music_last_play_tick < self.MUSIC_OFFER_MIN_GAP:
            return
        if now - self._music_offer_tick < self.MUSIC_OFFER_MIN_GAP:
            return
        self._music_offer_tick = now
        self._music_offer_pending = True
        self._broadcast_chat(random.choice(self.MUSIC_OFFER_LINES))

    def _start_music(self, track, player_id=None, reset_switch_count=True):
        """Play music track and notify player."""
        self._music_state = track
        if reset_switch_count:
            self._music_switch_count = 0
        self._music_offer_pending = False
        self._music_last_play_tick = self._tick
        payload = {
            "sound": track,
            "x": 0.0, "y": 0.0, "z": 0.0,
            "loop": True,
            "queue": False,
            "interrupt": True,
            "bgm": True,
        }
        host_id = player_id or self._get_host_id()
        if host_id:
            self.NotifyToClient(host_id, "VerityPlaySoundEvent", payload)
        else:
            self.BroadcastToAllClient("VerityPlaySoundEvent", payload)
        self._broadcast_chat_delayed(random.choice(self.MUSIC_START_LINES))

    def _stop_music(self):
        self._music_state = None
        self._music_switch_count = 0
        self._music_last_play_tick = self._tick
        self._broadcast_chat_delayed(random.choice(self.MUSIC_STOP_LINES))
        # Client-side stop is handled by player stopping custom audio
        # or by natural track end — broadcast a stop event
        self.BroadcastToAllClient("VerityStopMusicEvent", {})

    def _try_handle_music_chat(self, message, player_id=None):
        """Return True if message was consumed by music system."""
        if not message:
            return False
        stripped = message.strip()
        # Offer pending — player answering yes/no. Use EXACT match only so
        # unrelated messages like "你好" (contains "好") don't get misread as "yes".
        if self._music_offer_pending:
            if stripped in self.MUSIC_YES_KEYWORDS:
                self._music_offer_pending = False
                track = random.choice(self.MUSIC_TRACKS)
                self._start_music(track, player_id)
                return True
            if stripped in self.MUSIC_NO_KEYWORDS:
                self._music_offer_pending = False
                self._music_last_play_tick = self._tick
                self._broadcast_chat_delayed(u"\u597d\u7684\uff0c\u4e0d\u64ad\u4e86\u3002")
                return True
            # Any other reply while an offer is pending: let it fall through to
            # normal chat, but stop waiting for an answer so it doesn't linger.
            self._music_offer_pending = False
        # Player actively asks for music (explicit keyword phrases only)
        wants_music = any(kw in message for kw in self.MUSIC_PLAY_KEYWORDS)
        if wants_music and not self._music_state:
            track = random.choice(self.MUSIC_TRACKS)
            self._start_music(track, player_id)
            return True
        if wants_music and self._music_state:
            self._broadcast_chat_delayed(self.MUSIC_ALREADY_PLAYING)
            return True
        # Switch song
        wants_switch = any(kw in message for kw in self.MUSIC_SWITCH_KEYWORDS)
        if wants_switch and self._music_state:
            if self._music_switch_count >= MUSIC_SWITCH_LIMIT:
                self._broadcast_chat_delayed(random.choice(self.MUSIC_NO_SWITCH_LINES))
            else:
                self._music_switch_count += 1
                current = self._music_state
                tracks = list(self.MUSIC_TRACKS)
                tracks.remove(current)
                new_track = tracks[0]
                self._start_music(new_track, player_id, reset_switch_count=False)
                # Overwrite start message with switch message
                self._broadcast_chat_delayed(random.choice(self.MUSIC_SWITCH_LINES))
            return True
        # Stop music
        wants_stop = any(kw in message for kw in self.MUSIC_STOP_KEYWORDS)
        if wants_stop and self._music_state:
            self._stop_music()
            return True
        return False

    def _execute_locate_structure(self, player_id, feature_id, label):
        pos = self._get_pos(player_id)
        if not pos:
            return None
        dim = self._get_player_dimension(player_id)
        name = label or u"\u7ed3\u6784"
        try:
            result = CF.CreateFeature(LEVEL_ID).LocateStructureFeature(
                int(feature_id),
                int(dim),
                (int(pos[0]), int(pos[1]), int(pos[2])),
                False,
            )
        except Exception as exc:
            print("Verity locate error: %s" % exc)
            result = None
        if not result:
            self._broadcast_chat(
                u"\u6ca1\u627e\u5230\u9644\u8fd1\u7684%s\u3002\u6362\u4e2a\u65b9\u5411\u518d\u8bd5\u8bd5\uff1f" % name
            )
            return None
        bx, bz = result
        self._broadcast_chat(
            u"\u627e\u5230%s\u4e86\uff0c\u5927\u7ea6\u5728\u533a\u5757 %d, %d \u9644\u8fd1\u3002"
            % (name, int(bx), int(bz))
        )
        return None

    def _execute_summon_mob_all(self, player_id, count_each):
        if not player_id:
            return None
        try:
            import verityBrain as brain
            import verityVanillaMobs as vm
        except Exception:
            return None
        mob_ids = vm.get_all_mob_ids(brain._get_mob_map())
        try:
            count_each = max(1, min(int(count_each or 1), 5))
        except Exception:
            count_each = 1
        total = 0
        for mob_id in mob_ids:
            if total >= 30:
                break
            batch = min(count_each, 30 - total)
            self._execute_summon_mob(player_id, mob_id, batch)
            total += batch
        self._broadcast_chat(
            u"\u5171\u53ec\u5524\u4e86 %d \u53ea\u751f\u7269\uff08\u4e0a\u965030\u53ea\u9632\u5361\u987f\uff09\u3002" % total
        )
        return None

    def _execute_give_item_bundle(self, player_id, items):
        if not player_id:
            return None
        for entry in (items or []):
            if not entry:
                continue
            if isinstance(entry, (list, tuple)) and len(entry) >= 2:
                item_name, count = entry[0], entry[1]
            elif isinstance(entry, dict):
                item_name = entry.get("item") or entry.get("itemName")
                count = entry.get("count", 1)
            else:
                continue
            self._give_item_to_player(player_id, item_name, count)
        return None

    _ARMOR_SETS = {
        "diamond": [
            "minecraft:diamond_helmet",
            "minecraft:diamond_chestplate",
            "minecraft:diamond_leggings",
            "minecraft:diamond_boots",
        ],
        "iron": [
            "minecraft:iron_helmet",
            "minecraft:iron_chestplate",
            "minecraft:iron_leggings",
            "minecraft:iron_boots",
        ],
    }

    def _execute_give_armor_set(self, player_id, tier):
        items = self._ARMOR_SETS.get(tier) or self._ARMOR_SETS["diamond"]
        for item_name in items:
            self._give_item_to_player(player_id, item_name, 1)

    def _give_item_to_player(self, player_id, item_name, count):
        if not player_id or not item_name:
            return False
        try:
            count = int(count)
        except Exception:
            count = 1
        if count < 1:
            count = 1
        item_dict = {"itemName": item_name, "count": count}
        try:
            return bool(CF.CreateItem(player_id).SpawnItemToPlayerInv(item_dict, player_id, -1))
        except Exception:
            return False

    def _player_display_key(self, player_id):
        if not player_id:
            return None
        try:
            name = CF.CreateName(player_id).GetName()
            if name:
                if not isinstance(name, unicode):
                    try:
                        name = unicode(name)
                    except Exception:
                        name = u""
                name = name.strip()
                if name:
                    return u"name:" + name
        except Exception:
            pass
        try:
            uid = serverApi.GetPlayerUid(player_id)
            if uid:
                return u"uid:%s" % uid
        except Exception:
            pass
        return u"pid:%s" % str(player_id)

    def _load_guide_book_given(self):
        try:
            raw = CF.CreateExtraData(LEVEL_ID).GetExtraData(GUIDE_BOOK_GIVEN_KEY)
            if isinstance(raw, dict):
                return raw
            if raw:
                data = json.loads(raw)
                if isinstance(data, dict):
                    return data
        except Exception:
            pass
        return {}

    def _save_guide_book_given(self, data):
        if not isinstance(data, dict):
            return
        try:
            CF.CreateExtraData(LEVEL_ID).SetExtraData(
                GUIDE_BOOK_GIVEN_KEY, json.dumps(data, ensure_ascii=True), True
            )
        except Exception:
            pass

    def _player_has_guide_book_item(self, player_id):
        if not player_id:
            return False
        try:
            item_comp = CF.CreateItem(player_id)
            enum_mod = serverApi.GetMinecraftEnum()
            pos_map = enum_mod.ItemPosType
            for pos_type in (pos_map.CARRIED, pos_map.OFFHAND, pos_map.INVENTORY):
                items = item_comp.GetPlayerAllItems(pos_type) or []
                for item in items:
                    if self._item_name(item) != GUIDE_BOOK_ITEM:
                        continue
                    if self._item_count(item) > 0:
                        return True
        except Exception:
            pass
        return False

    def _mark_guide_book_given(self, player_id):
        key = self._player_display_key(player_id)
        if not key:
            return
        data = self._load_guide_book_given()
        data[key] = 1
        self._save_guide_book_given(data)

    def _guide_book_already_given(self, player_id):
        key = self._player_display_key(player_id)
        if not key:
            return False
        data = self._load_guide_book_given()
        return bool(data.get(key))

    def _try_give_guide_book_once(self, player_id, retry=0):
        if not player_id or not self._entity_exists(player_id):
            return
        try:
            retry = int(retry or 0)
        except Exception:
            retry = 0
        if self._guide_book_already_given(player_id):
            return
        if self._player_has_guide_book_item(player_id):
            self._mark_guide_book_given(player_id)
            return
        if not self._player_has_inv_space(player_id):
            if retry < 5:
                self._schedule(3.0, self._try_give_guide_book_once, player_id, retry + 1)
            return
        if self._give_item_to_player(player_id, GUIDE_BOOK_ITEM, 1):
            self._mark_guide_book_given(player_id)
            self._notify_player(
                player_id,
                u"\u00a7e[Verity]\u00a7r \u6536\u5230\u4e00\u672c\u300aVerity \u6307\u5357\u300b\uff0c\u7ffb\u5f00\u5373\u53ef\u67e5\u770b\u73a9\u6cd5\u3002",
            )
            return
        if self._player_has_guide_book_item(player_id):
            self._mark_guide_book_given(player_id)
            return
        if retry < 5:
            self._schedule(3.0, self._try_give_guide_book_once, player_id, retry + 1)

    def _find_entities_near(self, center_id, radius, filter_fn):
        found = []
        try:
            nearby = CF.CreateGame(center_id).GetEntitiesAround(center_id, radius, {}) or []
        except Exception:
            nearby = []
        for eid in nearby:
            if eid == center_id or eid == self._mob_id:
                continue
            type_str = self._get_entity_type(eid)
            if filter_fn(type_str):
                found.append(eid)
        return found

    def _mob_attack_entity(self, target_id):
        if not self._mob_id or not target_id:
            return
        try:
            CF.CreateAction(self._mob_id).SetAttackTarget(target_id)
            self._mark_combat()
        except Exception:
            pass

    def _execute_kill_type(self, player_id, mob_hint, radius):
        hint = (mob_hint or "").lower()
        radius = int(radius or 20)

        def _match(type_str):
            return hint in (type_str or "")

        targets = self._find_entities_near(player_id, radius, _match)
        if not targets:
            self._run_command_as_player(
                player_id,
                "kill @e[r=%d,type=%s]" % (radius, hint),
            )
            return
        for target_id in targets[:6]:
            self._mob_attack_entity(target_id)

    def _execute_kill_hostile(self, player_id, radius):
        radius = int(radius or 20)
        targets = self._find_entities_near(player_id, radius, self._is_hostile)
        if not targets:
            return
        for target_id in targets[:8]:
            self._mob_attack_entity(target_id)

    def _execute_attack_villager(self, player_id, radius):
        radius = int(radius or 32)

        def _is_villager(type_str):
            return "villager" in (type_str or "")

        targets = self._find_entities_near(player_id, radius, _is_villager)
        if not targets:
            return
        ctx = self._get_player_context(player_id)
        ctx["villager_attack_allowed"] = True
        self._save_player_context(player_id, ctx)
        self._mob_attack_entity(targets[0])

    def _prompt_attack_villager(self, player_id, radius=32):
        ctx = self._get_player_context(player_id)
        try:
            import verityConversation as conv
            conv.set_pending_question(
                ctx,
                "confirm_attack_villager",
                u"\u8981\u6211\u6253\u6751\u6c11\u5417\uff1f",
                {"type": "attack_villager", "radius": int(radius or 32)},
                self._tick,
            )
            self._save_player_context(player_id, ctx)
        except Exception:
            pass
        return u"\u8981\u6211\u6253\u6751\u6c11\u5417\uff1f\u8bf4\u300c\u597d\u300d\u6216\u300c\u53bb\u6253\u300d\u3002"

    def _queue_build_shelter(self, player_id, material=None, style="shelter"):
        pos = self._get_player_foot_pos(player_id)
        if not pos:
            return
        style = (style or "shelter").lower()
        wall_block = material or "minecraft:oak_planks"
        floor_block = "minecraft:oak_planks"
        roof_block = wall_block
        if style in ("stone", "stone_house", "castle"):
            wall_block = material or "minecraft:cobblestone"
            floor_block = "minecraft:cobblestone"
            roof_block = "minecraft:cobblestone"
        elif style in ("brick", "brick_house"):
            wall_block = material or "minecraft:bricks"
            floor_block = "minecraft:bricks"
            roof_block = "minecraft:bricks"
        elif style in ("glass", "glass_house"):
            wall_block = material or "minecraft:glass"
            roof_block = "minecraft:oak_planks"
        elif style in ("tower", "watchtower"):
            return self._queue_build_tower(player_id, wall_block)
        elif style in ("mine", "mine_shaft", "mining"):
            return self._queue_build_mine_shaft(player_id)
        dim = self._get_player_dimension(player_id)
        bx = int(pos[0])
        by = int(pos[1])
        bz = int(pos[2])
        blocks = []
        for dx in range(-2, 3):
            for dz in range(-2, 3):
                blocks.append((bx + dx, by - 1, bz + dz, floor_block))
        for y in range(3):
            for dx in range(-2, 3):
                for dz in range(-2, 3):
                    if abs(dx) != 2 and abs(dz) != 2:
                        continue
                    if dz == 2 and dx == 0 and y < 2:
                        continue
                    blocks.append((bx + dx, by + y, bz + dz, wall_block))
        for dx in range(-2, 3):
            for dz in range(-2, 3):
                blocks.append((bx + dx, by + 3, bz + dz, roof_block))
        blocks.append((bx, by + 1, bz, "minecraft:torch"))
        blocks.append((bx + 1, by + 1, bz + 1, "minecraft:crafting_table"))
        blocks.append((bx - 1, by + 1, bz + 1, "minecraft:chest"))
        self._build_queue = blocks
        self._build_dimension = dim

    def _queue_build_tower(self, player_id, wall_block="minecraft:cobblestone"):
        pos = self._get_player_foot_pos(player_id)
        if not pos:
            return
        dim = self._get_player_dimension(player_id)
        bx = int(pos[0])
        by = int(pos[1])
        bz = int(pos[2])
        blocks = []
        for y in range(6):
            for dx in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    if abs(dx) == 1 and abs(dz) == 1:
                        blocks.append((bx + dx, by + y, bz + dz, wall_block))
            if y == 0:
                blocks.append((bx, by + y, bz, wall_block))
            if y == 5:
                blocks.append((bx, by + y + 1, bz, "minecraft:torch"))
        self._build_queue = blocks
        self._build_dimension = dim

    def _queue_build_mine_shaft(self, player_id):
        pos = self._get_player_foot_pos(player_id)
        if not pos:
            return
        dim = self._get_player_dimension(player_id)
        bx = int(pos[0]) + 3
        by = int(pos[1])
        bz = int(pos[2])
        blocks = []
        for y in range(8):
            for dx in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    if abs(dx) == 1 or abs(dz) == 1:
                        blocks.append((bx + dx, by - y, bz + dz, "minecraft:oak_planks"))
            if y % 3 == 2:
                blocks.append((bx + 1, by - y, bz, "minecraft:torch"))
        blocks.append((bx, by + 1, bz, "minecraft:ladder"))
        self._build_queue = blocks
        self._build_dimension = dim

    def _process_build_queue(self):
        if not self._build_queue:
            return
        placed = 0
        block_comp = CF.CreateBlockInfo(LEVEL_ID)
        while self._build_queue and placed < BUILD_BLOCKS_PER_TICK:
            x, y, z, block_name = self._build_queue.pop(0)
            block_dict = {"name": block_name}
            try:
                block_comp.SetBlockNew(
                    (x, y, z), block_dict, 0, self._build_dimension, True, False
                )
            except Exception:
                pass
            placed += 1

    def _execute_dialogue_action(self, player_id, action):
        if not action or not player_id:
            return None
        action_type = action.get("type")
        if action_type == "give_item":
            self._give_item_to_player(
                player_id,
                action.get("item"),
                action.get("count", 1),
            )
        elif action_type == "command":
            self._run_command_as_player(player_id, action.get("cmd"))
        elif action_type == "kill_type":
            self._execute_kill_type(
                player_id,
                action.get("mob"),
                action.get("radius", 24),
            )
        elif action_type == "kill_hostile":
            self._execute_kill_hostile(player_id, action.get("radius", 20))
        elif action_type == "attack_villager":
            self._execute_attack_villager(player_id, action.get("radius", 32))
        elif action_type == "prompt_attack_villager":
            return self._prompt_attack_villager(player_id, action.get("radius", 32))
        elif action_type == "build_shelter":
            self._queue_build_shelter(
                player_id,
                action.get("material"),
                action.get("style", "shelter"),
            )
        elif action_type == "summon_mob":
            self._execute_summon_mob(
                player_id,
                action.get("mob"),
                action.get("count", 1),
            )
        elif action_type == "give_armor_set":
            self._execute_give_armor_set(player_id, action.get("tier", "diamond"))
        elif action_type == "query_players":
            return self._execute_query_players(player_id)
        elif action_type == "locate_structure":
            return self._execute_locate_structure(
                player_id,
                action.get("feature"),
                action.get("label"),
            )
        elif action_type == "summon_mob_all":
            return self._execute_summon_mob_all(
                player_id,
                action.get("count_each", 1),
            )
        elif action_type == "give_item_bundle":
            return self._execute_give_item_bundle(
                player_id,
                action.get("items"),
            )
        elif action_type == "recall_memory":
            txt = action.get("text")
            if txt:
                self._broadcast_chat(txt)
            return None
        elif action_type == "report_severity_pos":
            return self._execute_report_severity_pos(player_id)
        elif action_type == "report_distance":
            return self._execute_report_distance(player_id)
        elif action_type == "teleport_severity_to_player":
            return self._execute_teleport_severity_to_player(player_id)
        elif action_type == "query_game_time":
            return self._execute_query_game_time(player_id)
        elif action_type == "enable_follow":
            ctx = self._get_player_context(player_id)
            ctx["will_follow"] = True
            self._save_player_context(player_id, ctx)
        return None

    def _broadcast_sys_line(self, slug, entity_id=None, player_id=None, **fmt):
        try:
            from Script_NeteaseModkD4aCjWE import veritySysVoiceRegistry as reg
        except ImportError:
            try:
                import veritySysVoiceRegistry as reg
            except ImportError:
                return
        formatted = reg.format_sys(slug, **fmt)
        if not formatted:
            return
        sid, en, zh = formatted
        sound = "verity.line." + sid
        target = entity_id or self._mob_id
        self._broadcast_line(en, zh, sound, target, True, player_id)

    def _execute_report_severity_pos(self, player_id):
        if self._throw_state:
            pos = self._throw_state.get("pos") or [0.0, 64.0, 0.0]
            self._broadcast_chat(
                u"\u6211\u8fd8\u5728\u98de\u5462\uff0c\u5927\u6982\u5728 (%.0f, %.0f, %.0f) \u9644\u8fd1\u3002"
                % (pos[0], pos[1], pos[2])
            )
            return None
        for pid in (serverApi.GetPlayerList() or []):
            if self._player_has_held_item(pid):
                self._broadcast_chat(u"\u5728\u4f60\u624b\u91cc\u5462\u3002")
                return None
        if not self._mob_id or not self._entity_exists(self._mob_id):
            self._broadcast_chat(u"\u6211\u73b0\u5728\u4e0d\u5728\u573a\u4e0a\uff0c\u53ef\u80fd\u8fd8\u6ca1\u653e\u51fa\u6765\u3002")
            return None
        pos = self._get_foot_pos(self._mob_id)
        if not pos:
            return None
        self._broadcast_chat(
            u"\u6211\u5728 (%.0f, %.0f, %.0f)\u3002"
            % (pos[0], pos[1], pos[2])
        )
        return None

    def _execute_report_distance(self, player_id):
        if not player_id:
            return None
        ppos = self._get_player_foot_pos(player_id)
        if not ppos:
            return None
        if self._throw_state:
            pos = self._throw_state.get("pos") or ppos
            dist = self._dist_xz(pos, ppos)
            self._broadcast_chat(u"\u5927\u6982\u79bb\u4f60 %.0f \u683c\u3002" % dist)
            return None
        for pid in (serverApi.GetPlayerList() or []):
            if self._player_holds_held_item(pid):
                self._broadcast_chat(u"\u5c31\u5728\u624b\u8fb9\u554a\u3002")
                return None
        if not self._mob_id or not self._entity_exists(self._mob_id):
            self._broadcast_chat(u"\u627e\u4e0d\u5230\u6211\uff0c\u592a\u8fdc\u4e86\u3002")
            return None
        mpos = self._get_foot_pos(self._mob_id)
        if not mpos:
            return None
        dist = self._dist_xz(mpos, ppos)
        self._broadcast_chat(u"\u79bb\u4f60\u5927\u6982 %.0f \u683c\u3002" % dist)
        return None

    def _execute_teleport_severity_to_player(self, player_id):
        if not player_id:
            return None
        if self._throw_state:
            self._broadcast_chat(u"\u6211\u8fd8\u5728\u98de\uff0c\u7a0d\u7b49\u843d\u5730\u518d\u8bf4\u3002")
            return None
        for pid in (serverApi.GetPlayerList() or []):
            if self._player_holds_held_item(pid):
                self._broadcast_chat(u"\u6211\u5c31\u5728\u4f60\u624b\u91cc\u554a\u3002")
                return None
        host_pos = self._get_player_foot_pos(player_id)
        if not host_pos or not self._mob_id or not self._entity_exists(self._mob_id):
            self._broadcast_chat(u"\u627e\u4e0d\u5230\u6211\uff0c\u5148\u628a\u6211\u653e\u51fa\u6765\u3002")
            return None
        self._teleport_near(self._mob_id, player_id, host_pos)
        self._broadcast_chat(u"\u6765\u4e86\u3002")
        return None

    def _execute_query_game_time(self, player_id):
        try:
            time_val = int(CF.CreateTime(LEVEL_ID).GetTime())
        except Exception:
            time_val = None
        if time_val is None:
            self._broadcast_chat(u"\u65f6\u95f4\u67e5\u8be2\u5931\u8d25\u4e86\u3002")
            return None
        day_tick = time_val % 24000
        hour = (day_tick // 1000 + 6) % 24
        if 6 <= hour < 12:
            period = u"\u65e9\u4e0a"
        elif 12 <= hour < 18:
            period = u"\u4e0b\u5348"
        elif 18 <= hour < 22:
            period = u"\u665a\u4e0a"
        else:
            period = u"\u591c\u91cc"
        self._broadcast_chat(u"\u73b0\u5728\u662f%s\uff0c\u5927\u6982 %d \u70b9\u3002" % (period, hour))
        return None

    def _execute_query_players(self, player_id):
        try:
            players = serverApi.GetPlayerList() or []
            count = len(players)
        except Exception:
            count = 1
        if count <= 1:
            zh = u"\u5f53\u524d\u5c31\u4f60\u4e00\u4e2a\u5728\u7ebf\u3002\u5b64\u72ec\u5417\uff1f"
            en = "Just you online. Lonely?"
        else:
            zh = u"\u5f53\u524d\u670d\u52a1\u5668\u6709 %d \u4e2a\u73a9\u5bb6\u5728\u7ebf\u3002" % count
            en = "There are %d players online." % count
        return {"zh": zh, "en": en}

    # ------------------------------------------------------------------
    # Damage / chat
    # ------------------------------------------------------------------
    def _on_player_hurt(self, args):
        self._try_defend_owner(args.get("id"), args.get("attacker"), args.get("cause"))

    def _on_actually_hurt(self, args):
        entity_id = args.get("entityId")
        host_id = self._get_host_id()
        if not host_id or str(entity_id) != str(host_id):
            return
        src_id = args.get("srcId")
        if not src_id or str(src_id) in ("-1", "None"):
            return
        if str(src_id) == str(host_id):
            return
        self._try_defend_owner(host_id, src_id, args.get("cause"))

    def _try_defend_owner(self, victim_id, attacker_id, cause=None):
        host_id = self._get_host_id()
        if not host_id or not victim_id or str(victim_id) != str(host_id):
            return
        if not attacker_id or str(attacker_id) in ("-1", "None"):
            return
        if str(attacker_id) == str(host_id):
            return
        if str(attacker_id) == str(self._mob_id):
            return
        type_str = self._get_entity_type(attacker_id)
        if "player" in (type_str or ""):
            return
        if not self._is_hostile(type_str):
            return
        if not self._mob_id or not self._entity_exists(self._mob_id):
            return
        self._mob_attack_entity(attacker_id)
        if self._tick - self._defend_voice_tick > DEFEND_OWNER_VOICE_COOLDOWN:
            self._defend_voice_tick = self._tick
            try:
                import verityBrain as brain
                line = brain.reply_from_slug("pro_defend_00", None)
                if line:
                    _topic, en, zh, sound, _act = line
                    self._broadcast_line(en, zh, sound, self._mob_id, True, host_id)
            except Exception:
                pass

    def _on_damage(self, args):
        entity_id = args.get("entityId")
        if entity_id in (self._box_id, self._mob_id):
            args["damage"] = 0
            args["knock"] = False
            args["ignite"] = False
            if entity_id == self._mob_id:
                self._mark_combat()
                # Suffocation complaint (sand / gravel buried by player)
                cause = args.get("cause") or ""
                now = self._tick
                if cause == "suffocation":
                    last_suff = self._complaint_cooldown.get("suff", 0)
                    if now - last_suff > COMPLAINT_COOLDOWN_TICKS:
                        self._complaint_cooldown["suff"] = now
                        self._broadcast_chat(random.choice(BURIED_COMPLAINTS))
                        self._set_mood(MOOD_ANNOYED)
                        host_id = self._get_host_id()
                        if host_id:
                            self._bump_host_emotion(host_id, affection_delta=-10, anger_delta=18)
                    # Auto-rescue: don't just shout forever — dig Verity out
                    # by teleporting it next to the player shortly after.
                    last_rescue = self._complaint_cooldown.get("suff_rescue", 0)
                    if now - last_rescue > BURIED_RESCUE_COOLDOWN_TICKS:
                        self._complaint_cooldown["suff_rescue"] = now
                        host_id = self._get_host_id()
                        if host_id:
                            self._schedule(1.0, self._rescue_from_burial, self._mob_id, host_id, False)
                # Fire / lava complaint — only when triggered by a player action
                if cause in ("fire", "lava", "fire_tick", "on_fire"):
                    src_id = args.get("srcId")
                    src_type = self._get_entity_type(src_id) if src_id else ""
                    if src_id and "player" in src_type:
                        last_fire = self._complaint_cooldown.get("fire", 0)
                        if now - last_fire > COMPLAINT_COOLDOWN_TICKS:
                            self._complaint_cooldown["fire"] = now
                            import random as _r2
                            self._broadcast_chat(_r2.choice(FIRE_COMPLAINTS))
                            self._set_mood(MOOD_ANGRY)
                            self._bump_host_emotion(src_id, affection_delta=-8, anger_delta=16)
            return

        src_id = args.get("srcId")
        if src_id == self._mob_id:
            self._mark_combat()
        if not src_id or src_id != self._mob_id:
            return

    # ------------------------------------------------------------------
    # Persistent per-player conversation memory
    # ------------------------------------------------------------------
    def _context_player_id(self, player_id=None):
        """Single-player affection is always keyed to the host to avoid chat id mismatch."""
        host_id = self._get_host_id()
        if host_id is not None:
            return str(host_id)
        if player_id is not None:
            return str(player_id)
        return None

    def _context_key(self, player_id=None):
        if player_id:
            return "verity_chat_ctx_%s" % str(player_id)
        return "verity_chat_ctx"

    def _legacy_context_key(self, player_id=None):
        if player_id:
            return "severity_chat_ctx_%s" % str(player_id)
        return "severity_chat_ctx"

    def _get_player_context(self, player_id):
        owner_id = self._context_player_id(player_id)
        if not owner_id:
            return dialogue.new_context()
        cached = self._player_contexts.get(owner_id)
        if cached is not None:
            return cached
        ctx = None
        key = self._context_key(owner_id)
        legacy_key = self._legacy_context_key(owner_id)
        alt_ids = [owner_id]
        if player_id is not None and str(player_id) != owner_id:
            alt_ids.append(str(player_id))
        for pid in alt_ids:
            for try_key in (key, legacy_key, self._context_key(pid), self._legacy_context_key(pid)):
                for storage_id in (pid, LEVEL_ID):
                    try:
                        raw = CF.CreateExtraData(storage_id).GetExtraData(try_key)
                        if raw:
                            ctx = json.loads(raw)
                            break
                    except Exception:
                        pass
                if isinstance(ctx, dict):
                    break
            if isinstance(ctx, dict):
                break
        if not isinstance(ctx, dict):
            ctx = dialogue.new_context()
        ctx.setdefault("last_topic", None)
        ctx.setdefault("last_category", None)
        ctx.setdefault("last_action", None)
        ctx.setdefault("last_player_text", None)
        ctx.setdefault("player_name", None)
        ctx.setdefault("history", [])
        ctx.setdefault("mood", "neutral")
        ctx.setdefault("affection", 50)
        ctx.setdefault("last_intent", None)
        ctx.setdefault("always_use_name", False)
        ctx.setdefault("turn_count", 0)
        ctx.setdefault("relationship", None)
        ctx.setdefault("anger", 0)
        ctx.setdefault("trust", 50)
        ctx.setdefault("will_follow", True)
        ctx.setdefault("flirt_level", 0)
        ctx.setdefault("forgiven_count", 0)
        ctx.setdefault("utterances", [])
        ctx.setdefault("player_facts", {})
        ctx.setdefault("next_proactive_tick", 0)
        ctx.setdefault("next_scene_scan_tick", 0)
        ctx.setdefault("last_scene", None)
        self._player_contexts[owner_id] = ctx
        return ctx

    def _save_player_context(self, player_id, ctx):
        owner_id = self._context_player_id(player_id)
        if not owner_id or ctx is None:
            return
        self._player_contexts[owner_id] = ctx
        try:
            payload = json.dumps(ctx, ensure_ascii=True)
        except Exception:
            slim = {}
            for k, v in ctx.items():
                if k.startswith("_"):
                    continue
                try:
                    json.dumps(v, ensure_ascii=True)
                    slim[k] = v
                except Exception:
                    pass
            payload = json.dumps(slim, ensure_ascii=True)
            ctx.update(slim)
        key = self._context_key(owner_id)
        for storage_id in (owner_id, LEVEL_ID):
            try:
                CF.CreateExtraData(storage_id).SetExtraData(key, payload)
            except Exception:
                pass

    def _bump_chat_reply_seq(self):
        self._chat_reply_seq += 1
        return self._chat_reply_seq

    def _reply_if_current(self, seq, en_text, zh_text, sound_name, entity_id, player_id, action):
        if seq != self._chat_reply_seq:
            return
        self._reply_to_player(en_text, zh_text, sound_name, entity_id, player_id, action)

    def _reply_to_player(self, en_text, zh_text, sound_name, entity_id, player_id=None, action=None):
        if player_id and action:
            try:
                import veritySoul as soul
                ctx = self._get_player_context(player_id)
                if soul.should_refuse_action(ctx, action.get("type")):
                    refused = soul.get_refuse_reply(ctx, ctx.get("last_player_text") or "")
                    if refused:
                        _topic, en_text, zh_text, sound_name, action = refused
                    else:
                        action = None
            except Exception:
                pass
        if player_id and action:
            dyn = self._execute_dialogue_action(player_id, action)
            if dyn:
                zh_text = dyn.get("zh") or zh_text
                en_text = dyn.get("en") or en_text
        self._broadcast_line(en_text, zh_text, sound_name, entity_id, True, player_id)

    def _handle_player_message(self, message, player_id=None):
        self._sync_tracked_ids()
        # Apology check — revert monster form instantly, or calm an angry/annoyed mood
        msg_lower = (message or u"").lower()
        is_apology = any(kw in message or kw in msg_lower for kw in APOLOGY_KEYWORDS)
        if is_apology:
            if not player_id:
                player_id = self._get_host_id()
            # Apology always genuinely repairs affection/anger — not just cosmetic.
            try:
                import veritySoul as soul
                ctx = self._get_player_context(player_id)
                soul.snapshot_affection(ctx)
                ctx["anger"] = max(0, int(ctx.get("anger") or 0) - 20)
                ctx["affection"] = min(100, soul.affection_value(ctx) + 10)
                ctx["trust"] = min(100, int(ctx.get("trust") or 50) + 6)
                soul._sync_follow_flag(ctx)
                self._save_player_context(player_id, ctx)
            except Exception as exc:
                print("Verity apology repair error: %s" % exc)
            if self._monster_ids or self._monster_horror_active:
                self._revert_monster_to_verity(player_id)
                return
            if self._mob_id and self._entity_exists(self._mob_id):
                self._sync_mob_mood_from_context(player_id)
                if self._mob_mood != MOOD_HAPPY and int((self._get_player_context(player_id) or {}).get("anger") or 0) < 18:
                    self._set_mood(MOOD_HAPPY)
                self._broadcast_chat_delayed(random.choice(MOOD_CALMED_LINES))
                return
        if not player_id:
            player_id = self._get_host_id()
        if self._mob_id and self._entity_exists(self._mob_id):
            if self._try_handle_music_chat(message, player_id):
                return
        reply_seq = self._bump_chat_reply_seq()
        action, body = dialogue.parse_chat(message, self._require_prefix)
        speak_entity = self._mob_id if (self._mob_id and self._entity_exists(self._mob_id)) else None
        if action == "prefix_off":
            self._save_prefix_setting(False)
            self._schedule(
                CHAT_REPLY_DELAY,
                self._reply_if_current,
                reply_seq,
                None,
                dialogue.PREFIX_OFF_ZH,
                None,
                speak_entity,
                player_id,
                None,
            )
            return
        if action == "prefix_on":
            self._save_prefix_setting(True)
            self._schedule(
                CHAT_REPLY_DELAY,
                self._reply_if_current,
                reply_seq,
                None,
                dialogue.PREFIX_ON_ZH,
                None,
                speak_entity,
                player_id,
                None,
            )
            return
        if action == "skip" or not body:
            return
        ctx = self._get_player_context(player_id)
        ctx["turn_tick"] = self._tick
        try:
            import veritySoul as soul
            soul.snapshot_affection(ctx)
        except Exception:
            pass
        _topic, en, zh, sound, ai_action = dialogue.get_reply_with_action(body, ctx)
        self._save_player_context(player_id, ctx)
        self._sync_mob_mood_from_context(player_id)
        try:
            import veritySoul as soul
            ctx_after = self._get_player_context(player_id)
            aff = soul.affection_value(ctx_after)
            anger = int(ctx_after.get("anger") or 0)
            if anger >= 50 and self._mob_id and self._entity_exists(self._mob_id):
                self._set_mood(MOOD_ANGRY)
            if anger >= 15 or aff <= 40:
                print("Verity chat emotion aff=%d anger=%d msg=%s" % (
                    aff, anger, (body or "")[:40].encode("utf-8")))
        except Exception:
            pass
        self._check_affection_monster_trigger()
        self._schedule(
            CHAT_REPLY_DELAY,
            self._reply_if_current,
            reply_seq,
            en,
            zh,
            sound,
            speak_entity,
            player_id,
            ai_action,
        )

    def _normalize_message(self, raw_msg):
        if isinstance(raw_msg, bytes):
            try:
                raw_msg = raw_msg.decode("utf-8")
            except Exception:
                try:
                    raw_msg = raw_msg.decode("gbk")
                except Exception:
                    raw_msg = u""
        if not isinstance(raw_msg, unicode):
            try:
                raw_msg = unicode(raw_msg)
            except Exception:
                raw_msg = u""
        return raw_msg.strip()

    def _on_chat(self, args):
        username = self._normalize_message(args.get("username", ""))
        if username == CHAT_SENDER:
            return
        player_id = (args.get("playerId") or args.get("player")
                     or args.get("entityId") or args.get("id"))
        message = self._normalize_message(args.get("message", ""))
        if not message:
            return
        if not player_id:
            player_id = self._get_host_id()
        if player_id:
            self._handle_player_message(message, player_id)

    def _normalize_command(self, command):
        cmd = self._normalize_message(command)
        if cmd.startswith("/"):
            cmd = cmd[1:]
        return cmd.strip()

    def _command_targets_verity(self, command):
        """True when kill/remove explicitly targets Verity — not broad kill @e."""
        if not command:
            return False
        cmd = self._normalize_command(command).lower()
        if not cmd:
            return False
        parts = cmd.split()
        verb = parts[0]
        if verb not in ("kill", "remove"):
            return False
        target = " ".join(parts[1:]) if len(parts) > 1 else ""
        target_compact = target.replace(" ", "")
        mob_short = MOB_ENTITY.split(":")[-1]
        monster_short = MONSTER_ENTITY.split(":")[-1]
        if "type=" in target_compact or "[type=" in target_compact:
            if mob_short in target_compact or monster_short in target_compact:
                return True
            if "verity:" in target_compact and ("verity:mob" in target_compact or "verity:monster" in target_compact):
                return True
            return False
        if mob_short in target_compact or monster_short in target_compact:
            return True
        if "verity:mob" in target_compact or "verity:monster" in target_compact:
            return True
        return False

    def _is_broad_entity_kill(self, command):
        """kill/remove @e without a type filter — would hit Verity too."""
        if not command:
            return False
        cmd = self._normalize_command(command).lower()
        parts = cmd.split(None, 1)
        if not parts or parts[0] not in ("kill", "remove"):
            return False
        target = parts[1].strip() if len(parts) > 1 else "@e"
        if not target.startswith("@e"):
            return False
        target_compact = target.replace(" ", "")
        if "verity:mob" in target_compact or "verity:monster" in target_compact:
            return False
        if "type=" in target_compact:
            return False
        return True

    def _rewrite_kill_exclude_verity(self, command):
        """Rewrite kill @e[...] so Verity mob is excluded; other entities still die."""
        raw = self._normalize_message(command).strip()
        use_slash = raw.startswith("/")
        cmd = self._normalize_command(command)
        parts = cmd.split(None, 1)
        if not parts or parts[0].lower() not in ("kill", "remove"):
            return None
        verb = parts[0]
        target = parts[1].strip() if len(parts) > 1 else "@e"
        exclude = VERITY_KILL_EXCLUDE
        if target == "@e":
            new_target = "@e[%s]" % exclude
        elif target.startswith("@e[") and target.endswith("]"):
            inner = target[3:-1].strip()
            inner_compact = inner.replace(" ", "")
            if "type=" in inner_compact:
                return None
            new_target = "@e[%s,%s]" % (inner, exclude) if inner else "@e[%s]" % exclude
        else:
            return None
        out = verb + " " + new_target
        if use_slash:
            out = "/" + out
        return out

    def _handle_kill_command(self, command, player_id=None):
        """Return 'block' only when the command explicitly targets Verity."""
        if self._command_targets_verity(command):
            host_id = player_id or self._get_host_id()
            if self._tick - self._kill_taunt_tick > 40:
                self._kill_taunt_tick = self._tick
                self._broadcast_sys_line("sys_kill_immune_00", player_id=host_id)
            return "block"
        return None

    def _on_command_event(self, args):
        command = self._normalize_message(args.get("command", ""))
        if not command:
            return
        player_id = args.get("entityId") or self._get_host_id()
        if self._handle_kill_command(command, player_id):
            args["cancel"] = True

    def _on_global_command(self, args):
        command = self._normalize_message(args.get("command", ""))
        if not command:
            return
        player_id = args.get("entityId") or self._get_host_id()
        if self._handle_kill_command(command, player_id):
            args["cancel"] = True
            return
        if command.startswith("/") or command.startswith(u"tellraw"):
            return
        print("Verity GlobalCommandServerEvent command=%s" % command.encode("utf-8"))
        self._handle_player_message(command, player_id)

    def _append_affection_hint(self, zh_text, player_id):
        if not player_id or not zh_text:
            return zh_text
        try:
            import veritySoul as soul
            ctx = self._get_player_context(player_id)
            hint = soul.pop_affection_hint(ctx)
            if hint:
                self._save_player_context(player_id, ctx)
                return zh_text + hint
        except Exception:
            pass
        return zh_text

    def _broadcast_line(self, en_text, zh_text, sound_name, entity_id, show_chat=True, player_id=None):
        if show_chat and zh_text:
            if player_id:
                zh_text = self._append_affection_hint(zh_text, player_id)
            self._broadcast_chat(zh_text)
        if not sound_name:
            return
        pos = (0.0, 0.0, 0.0)
        if entity_id:
            try:
                pos = CF.CreatePos(entity_id).GetPos() or pos
            except Exception:
                pass
        payload = {
            "sound": sound_name,
            "x": float(pos[0]),
            "y": float(pos[1]),
            "z": float(pos[2]),
            "loop": False,
            "volume": 1.0,
            "interrupt": True,
        }
        if zh_text:
            payload["zh"] = zh_text
        if entity_id:
            payload["entityId"] = entity_id
        try:
            if player_id:
                self.NotifyToClient(player_id, "VerityPlaySoundEvent", payload)
            else:
                self.BroadcastToAllClient("VerityPlaySoundEvent", payload)
        except Exception as exc:
            print("Verity sound notify error: %s" % exc)
        print("Verity play sound -> %s (player=%s)" % (sound_name, player_id))
