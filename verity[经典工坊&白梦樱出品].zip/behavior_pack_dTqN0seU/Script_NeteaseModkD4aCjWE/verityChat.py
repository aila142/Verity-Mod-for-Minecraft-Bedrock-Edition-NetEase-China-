# -*- coding: utf-8 -*-
"""Port of verity_chat.js — short reactive lines (no cloud API)."""
from __future__ import print_function

import random
import re

try:
    unicode
except NameError:
    unicode = str

_CHAT_ENTRIES = []


def _compile_entries():
    if _CHAT_ENTRIES:
        return
    raw = [
        (
            [u"^(\u597d|\u4e0d\u9519|\u5389\u5bb3|\u68d2|\u8d5e)$", u"^(\u9177|\u5e05)$"],
            [u"\u662f\u5427\uff1f", u"\u5f88\u9ad8\u5174\u4f60\u8fd9\u4e48\u60f3\u3002"],
        ),
        (
            [u"^(\u54c7|\u54c7\u54e6|\u5929\u554a)$", u"^(\u4e0d\u4f1a\u5427|\u771f\u7684\u5417)$"],
            [u"\u6211\u77e5\u9053\uff0c\u5bf9\u5427\uff1f", u"\u592a\u75af\u72c2\u4e86\u3002"],
        ),
        (
            [u"^(\u54c8\u54c8|\u5475\u5475)$", u"^(\u7b11\u6b7b|\u54c8\u54c8\u54c8)$"],
            [u"\u5f88\u9ad8\u5174\u6211\u80fd\u9017\u4e50\u4e00\u4e2a\u7403\u3002"],
        ),
        (
            [u"^(\u597d\u7684|\u597d|\u884c|ok)$"],
            [u"\u9177\u3002", u"\u660e\u767d\u4e86\u3002"],
        ),
        (
            [u"^(\u662f\u7684|\u5bf9|\u6ca1\u9519|\u5f53\u7136)$"],
            [u"\u597d\u7684\u3002"],
        ),
        (
            [u"^(\u4e0d|\u4e0d\u662f|\u6ca1\u6709)$"],
            [u"\u8bf4\u5f97\u5bf9\u3002"],
        ),
        (
            [u"^(\u4e0d\u77e5\u9053|\u4e0d\u6e05\u695a)$"],
            [u"\u6ca1\u5173\u7cfb\u3002\u95ee\u6211\u2014\u2014\u6211\u53ef\u80fd\u77e5\u9053\u3002"],
        ),
        (
            [u"^verity\\??$", u"^verity!+$"],
            [u"\u6211\u5728\u3002", u"\u6e05\u6670\u54cd\u4eae\u3002"],
        ),
        (
            [u"\u8c22\u8c22", u"\u611f\u8c22"],
            [u"\u4e0d\u5ba2\u6c14\u3002"],
        ),
        (
            [u"\u518d\u89c1", u"\u62dc\u62dc"],
            [u"\u518d\u89c1\u3002\u6211\u4f1a\u5728\u8fd9\u91cc\u3002"],
        ),
        (
            [u"thatmob", u"pn?tmc", u"verity", u"\u4f60\u662f\u8c01"],
            [u"\u6211\u662f Verity\uff0cThatMob \u521b\u9020\u6982\u5ff5\uff0cPnTMC \u6784\u5efa\u8fd9\u4e2a\u5305\u3002"],
        ),
    ]
    for patterns, answers in raw:
        compiled = []
        for p in patterns:
            try:
                if p.startswith(u"^") or u"(" in p:
                    compiled.append(re.compile(p, re.I | re.U))
                else:
                    compiled.append(re.compile(re.escape(p), re.I | re.U))
            except Exception:
                pass
        if compiled and answers:
            _CHAT_ENTRIES.append((compiled, answers))


def try_basic_chat(message):
    _compile_entries()
    if not message:
        return None
    text = message.strip()
    if not isinstance(text, unicode):
        try:
            text = unicode(text)
        except Exception:
            text = unicode(str(text), "utf-8", "ignore")
    low = text.lower()
    for patterns, answers in _CHAT_ENTRIES:
        for pat in patterns:
            if pat.search(text) or pat.search(low):
                return random.choice(answers)
    return None
