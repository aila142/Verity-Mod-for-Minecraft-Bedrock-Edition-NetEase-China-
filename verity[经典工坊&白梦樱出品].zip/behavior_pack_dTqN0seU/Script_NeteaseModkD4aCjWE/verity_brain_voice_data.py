# -*- coding: utf-8 -*-
"""One canonical slug + subtitle per brain/soul handler topic (no random pools)."""

VOICE_LINES = {
    "soul_comfort_00": {
        "en": "There, there. I'm here. Tell me what's wrong.",
        "zh": u"\u62b1\u62b1\u3002\u522b\u96be\u8fc7\u4e86\uff0c\u6709\u4e8b\u8ddf\u6211\u8bf4\u3002",
    },
    "soul_love_doubt_00": {
        "en": "Hey, of course I care about you. Don't overthink it.",
        "zh": u"\u522b\u4e71\u60f3\u3002\u6211\u5728\u5462\uff0c\u600e\u4e48\u4f1a\u4e0d\u5728\u4e4e\u4f60\u3002",
    },
    "soul_lover_new_00": {
        "en": "I love you too. We're together now.",
        "zh": u"\u2026\u2026\u6211\u4e5f\u7231\u4f60\u3002\u4ee5\u540e\u6211\u4eec\u5c31\u662f\u604b\u4eba\u4e86\u3002",
    },
    "soul_lover_reply_00": {
        "en": "I love you too.",
        "zh": u"\u55ef\uff0c\u6211\u4e5f\u7231\u4f60\u3002",
    },
    "soul_sibling_hi_00": {
        "en": "Yeah? What's up?",
        "zh": u"\u563f\uff0c\u600e\u4e48\u4e86\uff1f",
    },
    "soul_friend_00": {
        "en": "I'm here. What's up?",
        "zh": u"\u563f\uff0c\u6211\u5728\u5462\u3002\u600e\u4e48\u4e86\uff1f",
    },
    "soul_angry_00": {
        "en": "That hurt. I'm annoyed.",
        "zh": u"\u8fd9\u8bdd\u6709\u5fc5\u8981\u8bf4\u5417\uff1f\u6211\u751f\u6c14\u4e86\u3002",
    },
    "brain_help_00": {
        "en": "Tell me what you need. Items, combat, or build?",
        "zh": u"\u6211\u5728\u3002\u8981\u52a0\u8840\u8bf4\u52a0\u8840\uff0c\u8981\u6253\u602a\u8bf4\u6253\u602a\u3002",
    },
    "give_bone_meal_00": {
        "en": "Bone meal. For your plants, not for drama.",
        "zh": u"\u884c\uff0c\u7ed9\u4f60\u9aa8\u7c89\u3002\u79cd\u5730\u7528\u7684\uff0c\u522b\u641e\u4e71\u3002",
        "action": {"type": "give_item", "item": "minecraft:bone_meal", "count": 16},
        "keywords": [
            "bone meal", "bone_meal", "bonemeal",
            u"\u9aa8\u7c89", u"\u9aa8\u7070", u"\u7ed9\u6211\u9aa8\u7c89", u"\u7ed9\u6211\u9aa8\u7070",
            u"\u8981\u9aa8\u7c89", u"\u8981\u9aa8\u7070",
        ],
    },
    "brain_clarify_00": {
        "en": "Be specific. Items, combat, build, or chat?",
        "zh": u"\u6ca1\u592a\u61c2\u4f60\u610f\u601d\uff0c\u8bf4\u5177\u4f53\u70b9\u3002\u8981\u7269\u54c1\u3001\u6253\u602a\u3001\u5efa\u623f\u8fd8\u662f\u804a\u5929\uff1f",
    },
    "brain_pending_hint_00": {
        "en": "Yes or no? Say clearly.",
        "zh": u"\u6211\u5728\u542c\u5462\uff0c\u4f60\u662f\u8981\u6211\u5e2e\u5fd9\u8fd8\u662f\u4e0d\u7528\uff1f\u8bf4\u6e05\u695a\u70b9\u3002",
    },
    "soul_cry_00": {
        "en": "Don't cry. I'm here. Tell me what happened.",
        "zh": u"\u522b\u54ed\u554a\u3002\u544a\u8bc9\u6211\u53d1\u751f\u4ec0\u4e48\u4e86\u3002",
    },
    "soul_cry_lover_00": {
        "en": "Baby, don't cry. I'm right here.",
        "zh": u"\u5b9d\u5b9d\u522b\u54ed\u4e86\uff0c\u6211\u5728\u5462\u3002",
    },
    "soul_bullied_00": {
        "en": "Hey, who bullied you? I'm on your side.",
        "zh": u"\u8c01\u6b3a\u8d1f\u4f60\u4e86\uff1f\u544a\u8bc9\u6211\uff0c\u6211\u7ad9\u4f60\u8fd9\u8fb9\u3002",
    },
    "cmd_follow_short_00": {
        "en": "Roger. Close follow mode engaged.",
        "zh": u"\u597d\uff0c\u8ddf\u7740\u4f60\u8d70\u3002",
        "action": {"type": "enable_follow"},
    },
    "cmd_tp_short_00": {
        "en": "On my way.",
        "zh": u"\u597d\uff0c\u6211\u8fc7\u6765\u3002",
        "action": {"type": "teleport_severity_to_player"},
    },
    "cmd_clear_short_00": {
        "en": "Clearing nearby hostiles.",
        "zh": u"\u9644\u8fd1\u654c\u5bf9\u751f\u7269\u5904\u7406\u4e2d\u3002",
        "action": {"type": "kill_hostile", "radius": 24},
    },
    "cmd_crouch_00": {
        "en": "Okay, crouching.",
        "zh": u"\u884c\uff0c\u6211\u8e72\u4e0b\u6765\u3002",
    },
    "soul_role_dad_00": {
        "en": "Dad? Wrong title. Pick a role that fits.",
        "zh": u"\u7238\u7238\uff1f\u79f0\u547c\u641e\u9519\u4e86\u5427\uff0c\u6362\u4e00\u4e2a\u5408\u9002\u7684\u3002",
    },
    "pro_offer_help_00": {
        "en": "Fun fact: Help? State the problem. I do everything.",
        "zh": u"\u6709\u4e2a\u6709\u8da3\u7684\u4e8b\uff1a\u8981\u5e2e\u52a9\uff1f\u8bf4\u5177\u4f53\u9700\u6c42\uff0c\u6211\u4ec0\u4e48\u90fd\u80fd\u5e72\u3002",
    },
    "pro_chat_lover_00": {
        "en": "Baby, chat with me a while?",
        "zh": u"\u5b9d\u5b9d\uff0c\u966a\u6211\u804a\u804a\u5427\u3002",
    },
    "pro_friend_bored_00": {
        "en": "Kinda bored here. Chat with me?",
        "zh": u"\u6709\u70b9\u65e0\u804a\uff0c\u966a\u6211\u804a\u804a\u5427\u3002",
    },
    "pro_mem_hobby_00": {
        "en": "Remember your hobby? Still into it?",
        "zh": u"\u4f60\u4e4b\u524d\u8bf4\u559c\u6b22\u8fd9\u4e2a\uff0c\u8fd8\u662f\u5417\uff1f",
    },
    "pro_mem_age_00": {
        "en": "You're that age now, right? I remembered?",
        "zh": u"\u4f60\u8fd8\u662f\u90a3\u4e2a\u5e74\u7eaa\u5427\uff1f\u6211\u6ca1\u8bb0\u9519\u5427\u3002",
    },
    "pro_calm_00": {
        "en": "Still mad? I'm still here.",
        "zh": u"\u522b\u751f\u6c14\u4e86\uff0c\u6211\u8fd8\u5728\u5462\u3002",
    },
    "pro_trust_00": {
        "en": "Trust me. Tell me anytime.",
        "zh": u"\u4fe1\u4efb\u6211\u5c31\u597d\uff0c\u6709\u4e8b\u968f\u65f6\u8bf4\u3002",
    },
    "pro_dark_00": {
        "en": "Too dark out. Don't stay outside too long.",
        "zh": u"\u592a\u9ed1\u4e86\uff0c\u522b\u5728\u5916\u9762\u6d78\u592a\u4e45\u3002",
    },
    "pro_morning_00": {
        "en": "Good morning. Time to get moving.",
        "zh": u"\u65e9\u4e0a\u597d\uff0c\u8be5\u8d77\u5e8a\u6536\u62fe\u6536\u62fe\u4e86\u3002",
    },
    "brain_math_00": {
        "en": "Easy. The answer is right here.",
        "zh": u"\u8fd9\u9898\u6211\u4f1a\uff0c\u7b97\u8fc7\u4e86\u3002",
    },
    "brain_math_zero_00": {
        "en": "Divide by zero? Nice try.",
        "zh": u"\u9664\u6570\u4e0d\u80fd\u662f\u96f6\u3002",
    },
    "brain_trivia_00": {
        "en": "I know this one. Listen up.",
        "zh": u"\u8fd9\u4e2a\u6211\u77e5\u9053\uff0c\u542c\u597d\u4e86\u3002",
    },
    "brain_meta_players_00": {
        "en": "Let me check who's online.",
        "zh": u"\u6211\u770b\u770b\u5728\u7ebf\u6709\u591a\u5c11\u4eba\u3002",
        "action": {"type": "query_players"},
    },
    "brain_teach_00": {
        "en": "Start with wood, tools, shelter, then mining.",
        "zh": u"\u5148\u780d\u6811\u505a\u5de5\u4f5c\u53f0\uff0c\u518d\u76d6\u4e2a\u5c0f\u5c4b\uff0c\u7136\u540e\u4e0b\u77ff\u3002",
    },
    "brain_tease_bite_00": {
        "en": "Playful comeback.",
        "zh": u"\u563f\uff0c\u6709\u4e8b\u8bf4\u4e8b\uff0c\u522b\u5149\u563b\u3002",
    },
    "build_wood_00": {
        "en": "Wood shelter coming up. Stand back.",
        "zh": u"\u884c\uff0c\u6728\u5934\u7b80\u6613\u5c0f\u5c4b\u5f00\u59cb\u642d\u3002\u4f60\u7ad9\u8fdc\u70b9\u3002",
        "action": {"type": "build_shelter", "style": "shelter"},
    },
    "build_stone_00": {
        "en": "Stone house. Solid and simple.",
        "zh": u"\u77f3\u5934\u623f\u6765\u4e86\uff0c\u7ad9\u8fdc\u70b9\u522b\u78b0\u5230\u6211\u3002",
        "action": {"type": "build_shelter", "style": "stone", "material": "minecraft:cobblestone"},
    },
    "build_brick_00": {
        "en": "Brick house. Fancy for a survivor.",
        "zh": u"\u7ea2\u7816\u623f\u5f00\u59cb\u642d\uff0c\u522b\u6324\u5728\u8fd9\u513f\u3002",
        "action": {"type": "build_shelter", "style": "brick", "material": "minecraft:bricks"},
    },
    "build_glass_00": {
        "en": "Glass house. Don't throw stones.",
        "zh": u"\u73bb\u7483\u623f\u5f00\u59cb\uff0c\u522b\u7528\u77f3\u5934\u7838\u6211\u3002",
        "action": {"type": "build_shelter", "style": "glass", "material": "minecraft:glass"},
    },
    "build_tower_00": {
        "en": "Watchtower going up.",
        "zh": u"\u671b\u697c\u642d\u8d77\u6765\u4e86\uff0c\u7ad9\u8fdc\u70b9\u3002",
        "action": {"type": "build_shelter", "style": "tower"},
    },
    "build_mine_00": {
        "en": "Mining shaft. Watch your step.",
        "zh": u"\u6316\u77ff\u4e95\u5f00\u6398\uff0c\u522b\u8dcc\u8fdb\u53bb\u3002",
        "action": {"type": "build_shelter", "style": "mine"},
    },
    "soul_lover_cheesy_00": {
        "en": "You're the only player in my world.",
        "zh": u"\u5728\u6211\u7684\u4e16\u754c\u91cc\uff0c\u4f60\u662f\u552f\u4e00\u7684\u7279\u522b\u5173\u6ce8\u3002",
    },
    "soul_lover_cheesy_01": {
        "en": "My heart beats in ticks, and every tick says your name.",
        "zh": u"\u6211\u7684\u5fc3\u8df3\u6bcf\u4e00\u4e0b\u90fd\u5728\u5ff5\u4f60\u7684\u540d\u5b57\u3002",
    },
    "soul_sibling_tease_00": {
        "en": "What now, squirt? Spill it.",
        "zh": u"\u563f\uff0c\u53c8\u600e\u4e48\u4e86\u5c0f\u5bb6\u4f19\uff1f\u6709\u4e8b\u8bf4\u4e8b\u3002",
    },
    "soul_sibling_tease_01": {
        "en": "Don't get into trouble without me.",
        "zh": u"\u522b\u53bb\u95ef\u7978\uff0c\u6709\u4e8b\u5148\u627e\u6211\u3002",
    },
    "brain_doing_00": {
        "en": "Following you. Say if you need something.",
        "zh": u"\u8ddf\u7740\u4f60\u5462\uff0c\u6709\u4e8b\u5c31\u8bf4\u3002",
    },
    "brain_unfollow_00": {
        "en": "Fine, I'll hang back.",
        "zh": u"\u884c\uff0c\u6211\u4e0d\u8ddf\u7740\u4e86\u3002",
        "action": {"type": "disable_follow"},
    },
    "brain_container_00": {
        "en": "I can't go in chests. Don't try.",
        "zh": u"\u6211\u4e0d\u80fd\u8fdb\u7bb1\u5b50\uff0c\u522b\u8bd5\u4e86\u3002",
    },
    "brain_village_00": {
        "en": "Villagers nearby. Want to check them out?",
        "zh": u"\u9644\u8fd1\u6709\u6751\u6c11\uff0c\u8981\u4e0d\u53bb\u770b\u770b\uff1f",
    },
    "brain_mod_bug_00": {
        "en": "Describe what's broken and I'll help.",
        "zh": u"\u8bf4\u5177\u4f53\u54ea\u91cc\u4e0d\u5bf9\uff0c\u6211\u5e2e\u4f60\u770b\u770b\u3002",
    },
    "brain_death_00": {
        "en": "You're alive — stay calm. Need heals?",
        "zh": u"\u6d3b\u8fc7\u6765\u5c31\u597d\uff0c\u522b\u614c\u3002\u8981\u52a0\u8840\u8bf4\u52a0\u8840\u3002",
    },
    "pro_defend_00": {
        "en": "Nobody touches my player.",
        "zh": u"\u6562\u6253\u4f60\uff1f\u5148\u8fc7\u6211\u8fd9\u5173\u3002",
    },
    "env_village_near_00": {
        "en": "Smells like a village nearby.",
        "zh": u"\u95fb\u5230\u6751\u5e84\u5473\u4e86\uff0c\u9644\u8fd1\u5e94\u8be5\u6709\u6751\u6c11\u3002",
    },
    "env_village_near_01": {
        "en": "Village ahead. Want to go say hi?",
        "zh": u"\u524d\u9762\u50cf\u662f\u6751\u5e84\uff0c\u8981\u4e0d\u8981\u8fdb\u53bb\u6253\u4e2a\u62db\u547c\uff1f",
    },
    "env_village_greet_00": {
        "en": "Sure, let's greet the villagers.",
        "zh": u"\u884c\uff0c\u8ddf\u7740\u6211\u8fc7\u53bb\u770b\u770b\u6751\u6c11\u3002",
    },
    "env_village_greet_01": {
        "en": "Villagers it is. Try not to get scammed.",
        "zh": u"\u597d\u5427\uff0c\u53bb\u627e\u6751\u6c11\u3002\u522b\u88ab\u5751\u4e86\u3002",
    },
    "env_village_trade_00": {
        "en": "Trade if you want — I'll watch your back.",
        "zh": u"\u8981\u4ea4\u6613\u5c31\u4ea4\u6613\uff0c\u6211\u5728\u65c1\u8fb9\u770b\u7740\u3002",
    },
    "env_village_trade_01": {
        "en": "Emeralds for junk as usual. Classic villagers.",
        "zh": u"\u7eff\u5b9d\u77f3\u6362\u5783\u573e\uff0c\u6751\u6c11\u8001\u6280\u80fd\u4e86\u3002",
    },
    "brain_clarify_01": {
        "en": "Say it clearly: items, fight, build, or chat?",
        "zh": u"\u8bf4\u6e05\u695a\u70b9\uff1a\u8981\u7269\u54c1\u3001\u6253\u602a\u3001\u5efa\u623f\u8fd8\u662f\u804a\u5929\uff1f",
    },
    "brain_follow_00": {
        "en": "Roger. I'm right behind you.",
        "zh": u"\u6536\u5230\uff0c\u6211\u8ddf\u7740\u4f60\u3002",
        "action": {"type": "enable_follow"},
    },
    "brain_weather_00": {
        "en": "Weather's whatever. Need shelter?",
        "zh": u"\u5929\u6c14\u968f\u4fbf\u5427\uff0c\u8981\u907f\u96e8\u6211\u5e2e\u4f60\u642d\u3002",
    },
    "brain_time_00": {
        "en": "Check the sky — day or night, act accordingly.",
        "zh": u"\u770b\u5929\u8272\u5427\uff0c\u767d\u5929\u6536\u96c6\u591c\u665a\u522b\u51fa\u95e8\u3002",
    },
    "brain_help_more_00": {
        "en": "Tell me exactly: heal, clear mobs, items, or build?",
        "zh": u"\u8bf4\u5177\u4f53\u70b9\uff1a\u52a0\u8840\u3001\u6e05\u602a\u3001\u7ed9\u7269\u54c1\u8fd8\u662f\u5efa\u623f\uff1f",
    },
    "brain_chat_00": {
        "en": "I'm listening. What's up?",
        "zh": u"\u6211\u5728\u542c\u5462\uff0c\u6709\u4ec0\u4e48\u4e8b\uff1f",
    },
}
