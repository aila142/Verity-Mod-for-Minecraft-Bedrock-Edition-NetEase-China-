# -*- coding: utf-8 -*-
"""
Verity intent engine.

Loads a large keyword -> reply/action corpus (verity_dialogue_data.py, falling
back to verity_dialogue.json) and matches player chat messages against it.

Also implements lightweight persistent-per-player conversation memory so
follow-up messages ("再来" / "more" / "same again") reuse the previous
topic/action instead of the AI "forgetting" what was just discussed.
"""
from __future__ import print_function

import json
import random
import re

try:
    unicode
except NameError:  # pragma: no cover - py3 local testing shim only
    unicode = str  # noqa: A001

_SOUND_PREFIX = "verity.line."
_ENTRIES = None
_FALLBACKS = None
_AVAILABLE_SLUGS = None
_AVAILABLE_LOADED = False
_LOADED = False

_MIN_SCORE = 3
_MIN_ACTION_SCORE = 4
_CONTEXT_BONUS = 3
_HISTORY_LIMIT = 8

_GENERIC_ITEM_KW = frozenset([
    u"\u7ed9\u6211", u"\u7ed9\u4f60", u"\u8981", u"\u6765\u4e2a", u"\u6765\u70b9",
    u"give", u"give me", u"need", u"want",
])

_FOLLOWUP_KEYWORDS = (
    u"again", u"more", u"another", u"one more", u"same again", u"repeat",
    u"do it again", u"give me another",
    u"\u518d\u6765", u"\u518d\u7ed9\u6211", u"\u518d\u8981", u"\u8fd8\u8981", u"\u518d\u4e00\u4e2a",
    u"\u518d\u6765\u4e00\u4e2a", u"\u591a\u7ed9\u70b9", u"\u4e00\u6837\u7684",
    u"\u540c\u6837\u7684", u"\u518d\u6765\u4e00\u6b21", u"\u518d\u5f04\u4e00\u4e2a",
    u"\u4e0a\u4e00\u4e2a", u"\u8fd8\u80fd", u"\u6162\u4e86", u"\u518d\u6765\u70b9",
    u"\u518d\u6765\u4e00\u9897", u"\u518d\u6765\u4e00\u9897",
)
_CONTINUATION_HINTS = (
    u"\u518d", u"\u8fd8", u"\u53c8", u"\u591a", u"\u6765\u70b9", u"\u6765\u4e00",
    u"\u4e00\u7ec4", u"\u4e00\u9897", u"\u4e00\u4e2a", u"\u4e00\u628a", u"\u4e00\u5757",
    u"\u5341", u"\u767e", u"\u7ec4", u"\u9897", u"\u4e2a", u"\u628a", u"\u5757",
)


def _script_dir():
    try:
        path = __file__
    except NameError:
        return ""
    if "/" in path:
        return path.rsplit("/", 1)[0]
    if "\\" in path:
        return path.rsplit("\\", 1)[0]
    return ""


def _dialogue_json_path():
    base = _script_dir()
    if not base:
        return "verity_dialogue.json"
    if base.endswith("/") or base.endswith("\\"):
        return base + "verity_dialogue.json"
    if "/" in base:
        return base + "/verity_dialogue.json"
    return base + "\\verity_dialogue.json"


def _open_text(path):
    try:
        import io
        return io.open(path, "r", encoding="utf-8")
    except TypeError:
        import codecs
        return codecs.open(path, "r", "utf-8")


def _apply_corpus(entries, fallbacks, source_label):
    global _ENTRIES, _FALLBACKS
    _load_available_sounds()
    filtered_entries = []
    for entry in (entries or []):
        # Action lines (give/build/summon) must stay even when OGG is missing.
        if entry.get("action") or _entry_has_voice(entry):
            filtered_entries.append(entry)
    filtered_fallbacks = list(fallbacks or [])
    _ENTRIES = filtered_entries
    _FALLBACKS = filtered_fallbacks
    print("Verity intent engine loaded %d voiced entries (%d fallbacks) from %s" % (
        len(_ENTRIES), len(_FALLBACKS), source_label))


def _merge_brain_voice():
    global _ENTRIES
    bvd = None
    try:
        import verity_brain_voice_data as bvd
    except ImportError:
        try:
            from Script_NeteaseModkD4aCjWE import verity_brain_voice_data as bvd
        except ImportError:
            bvd = None
    if bvd is None:
        return
    voice_lines = getattr(bvd, "VOICE_LINES", None) or {}
    if _ENTRIES is None:
        _ENTRIES = []
    for slug, entry in voice_lines.items():
        keywords = entry.get("keywords")
        if not keywords:
            continue
        corpus_entry = {
            "id": slug,
            "en": entry.get("en") or "",
            "zh": entry.get("zh") or u"",
            "keywords": list(keywords),
        }
        action = entry.get("action")
        if action:
            corpus_entry["action"] = dict(action)
        replaced = False
        for i, existing in enumerate(_ENTRIES):
            if existing.get("id") == slug:
                _ENTRIES[i] = corpus_entry
                replaced = True
                break
        if not replaced:
            _ENTRIES.append(corpus_entry)


def _try_brain_voice_shortcut(text, context, message):
    """High-priority match for brain voice keyword entries (score >= 8)."""
    best_score = 0
    best = []
    for entry in _ENTRIES:
        kws = entry.get("keywords") or []
        if not kws:
            continue
        score = _score_text(text, kws)
        if score <= 0:
            continue
        score += _context_bonus(entry, context)
        if score > best_score:
            best_score = score
            best = [entry]
        elif score == best_score:
            best.append(entry)
    if not best or best_score < 8:
        return None
    best = _prefer_voiced(best)
    action_candidates = [e for e in best if e.get("action")]
    if action_candidates:
        pick = random.choice(action_candidates)
    else:
        pick = random.choice(best)
    topic = pick.get("id") or u"reply"
    en = pick.get("en") or u""
    zh = pick.get("zh") or u""
    sound = _sound_for_entry(pick)
    action = pick.get("action")
    qty = _parse_quantity(text)
    if action and qty is not None:
        action = _apply_quantity(action, qty)
    return _finalize(topic, en, zh, sound, action, context, message)


def _load_corpus():
    global _LOADED
    if _LOADED:
        return
    _LOADED = True

    # Prefer embedded Python data (always ships with the script pack; no
    # dependency on JSON resource copying at build/export time).
    data = None
    try:
        import verity_dialogue_data as data
    except ImportError:
        try:
            from Script_NeteaseModkD4aCjWE import verity_dialogue_data as data
        except ImportError:
            data = None
    if data is not None:
        try:
            _apply_corpus(data.ENTRIES, data.FALLBACKS, "verity_dialogue_data.py")
            _merge_brain_voice()
            return
        except Exception as exc:
            print("Verity intent engine data module error: %s" % exc)

    path = _dialogue_json_path()
    try:
        with _open_text(path) as handle:
            doc = json.load(handle)
        _apply_corpus(doc.get("entries"), doc.get("fallbacks"), "verity_dialogue.json")
        return
    except Exception as exc:
        print("Verity intent engine load error: %s" % exc)

    print("Verity intent engine: no dialogue corpus found")
    _apply_corpus([], [], "none")
    _merge_brain_voice()


def corpus_available():
    _load_corpus()
    return bool(_ENTRIES)


def entry_count():
    _load_corpus()
    return len(_ENTRIES or [])


def _to_unicode(message):
    if isinstance(message, unicode):
        return message
    if isinstance(message, bytes):
        try:
            return message.decode("utf-8")
        except Exception:
            try:
                return message.decode("gbk")
            except Exception:
                return message.decode("utf-8", "ignore")
    try:
        return unicode(message)
    except Exception:
        return u""


def _is_ascii_word(kw_u):
    try:
        kw_u.encode("ascii")
        return kw_u.isalpha()
    except (UnicodeEncodeError, AttributeError):
        return False


def _is_cjk_char(ch):
    if not ch:
        return False
    try:
        code = ord(ch)
        return 0x4E00 <= code <= 0x9FFF
    except Exception:
        return False


def _keyword_in_text(kw_u, text):
    if not kw_u:
        return False
    if kw_u not in text:
        kw_words = kw_u.split()
        if len(kw_words) > 1 and all(w in text for w in kw_words):
            return True
        return False
    # Single CJK char must not match inside a longer word (e.g. 骨 in 骨灰).
    if len(kw_u) == 1 and _is_cjk_char(kw_u):
        if text == kw_u:
            return True
        idx = 0
        while idx < len(text):
            pos = text.find(kw_u, idx)
            if pos < 0:
                break
            before = text[pos - 1] if pos > 0 else u""
            after = text[pos + 1] if pos + 1 < len(text) else u""
            left_ok = (pos == 0) or not _is_cjk_char(before)
            right_ok = (pos + 1 >= len(text)) or not _is_cjk_char(after)
            if left_ok and right_ok:
                return True
            idx = pos + 1
        return False
    # Short ASCII keywords must match as whole words  prevents "yo" in "you".
    if len(kw_u) <= 3 and _is_ascii_word(kw_u):
        pattern = r"(?:^|[\s,.!?;:\u3002\uff01\uff1f])" + re.escape(kw_u) + r"(?:$|[\s,.!?;:\u3002\uff01\uff1f])"
        if re.search(pattern, text):
            return True
        if text == kw_u:
            return True
        return False
    return True


def _score_text(text, keywords):
    score = 0
    if not keywords:
        return 0
    specific = 0
    for kw in keywords:
        kw_u = _to_unicode(kw).lower()
        if not kw_u:
            continue
        if not _keyword_in_text(kw_u, text):
            continue
        if kw_u in _GENERIC_ITEM_KW:
            score += 2
        else:
            specific += 1
            score += len(kw_u) + 2
    if score > 0 and specific == 0:
        return 0
    return score


def _pick_best_entry(text, context, action_only=False):
    """Return best corpus entry for text, or None."""
    best_score = 0
    best = []
    for entry in _ENTRIES:
        if action_only and not entry.get("action"):
            continue
        kws = entry.get("keywords") or []
        score = _score_text(text, kws)
        if score <= 0:
            continue
        score += _context_bonus(entry, context)
        if score > best_score:
            best_score = score
            best = [entry]
        elif score == best_score:
            best.append(entry)
    min_score = _MIN_ACTION_SCORE if action_only else _MIN_SCORE
    if not best or best_score < min_score:
        return None, 0
    best = _prefer_voiced(best)
    if action_only:
        action_candidates = [e for e in best if e.get("action")]
        if not action_candidates:
            return None, 0
        pick = random.choice(action_candidates)
    else:
        action_candidates = [e for e in best if e.get("action")]
        if action_candidates and best_score >= _MIN_ACTION_SCORE:
            pick = random.choice(action_candidates)
        else:
            pick = random.choice(best)
    return pick, best_score


def match_action_reply(message, context=None):
    """Match guide-book item/combat/build commands; never returns fallbacks."""
    _load_corpus()
    text = _to_unicode(message).lower().strip()
    if not text or not _ENTRIES:
        return None
    if context is not None and _is_context_continuation(text, context):
        cont = _continue_last_action(text, context, message)
        if cont and cont[4]:
            return cont
    pick, _score = _pick_best_entry(text, context, action_only=True)
    if not pick:
        return None
    topic = pick.get("id") or u"reply"
    en = pick.get("en") or u""
    zh = pick.get("zh") or u""
    sound = _sound_for_entry(pick)
    action = pick.get("action")
    qty = _parse_quantity(text)
    if action and qty is not None:
        action = _apply_quantity(action, qty)
    return _finalize(topic, en, zh, sound, action, context, message)


def _load_available_sounds():
    global _AVAILABLE_SLUGS, _AVAILABLE_LOADED
    if _AVAILABLE_LOADED:
        return
    _AVAILABLE_LOADED = True
    mod = None
    try:
        import verity_available_sounds as mod
    except ImportError:
        try:
            from Script_NeteaseModkD4aCjWE import verity_available_sounds as mod
        except ImportError:
            mod = None
    if mod is not None:
        try:
            _AVAILABLE_SLUGS = set(getattr(mod, "SOUND_SLUGS", None) or [])
            print("Verity intent engine: %d voiced lines available" % len(_AVAILABLE_SLUGS))
            return
        except Exception as exc:
            print("Verity available sounds load error: %s" % exc)
    _AVAILABLE_SLUGS = set()


def _slug_is_available(entry_id):
    if not _AVAILABLE_SLUGS:
        return True
    for slug in _AVAILABLE_SLUGS:
        if slug == entry_id:
            return True
    return False


def _entry_has_voice(entry):
    _load_available_sounds()
    entry_id = entry.get("id") or ""
    return _slug_is_available(entry_id)


def _prefer_voiced(candidates):
    if not candidates:
        return candidates
    with_voice = [e for e in candidates if _entry_has_voice(e)]
    return with_voice if with_voice else candidates


def _entry_sound(entry):
    entry_id = entry.get("id") or "unknown"
    return _SOUND_PREFIX + entry_id


def _sound_for_entry(entry):
    if _entry_has_voice(entry):
        return _entry_sound(entry)
    return None


def _entry_category(entry):
    entry_id = entry.get("id") or ""
    return entry_id.split("_")[0] if entry_id else ""


def _is_followup_message(text):
    for kw in _FOLLOWUP_KEYWORDS:
        if kw in text:
            return True
    return False


def new_context():
    return {
        "last_topic": None,
        "last_category": None,
        "last_action": None,
        "last_player_text": None,
        "player_name": None,
        "history": [],
        "mood": "neutral",
        "affection": 50,
        "last_intent": None,
        "always_use_name": False,
        "turn_count": 0,
        "relationship": None,
        "anger": 0,
        "trust": 50,
        "will_follow": True,
        "flirt_level": 0,
        "forgiven_count": 0,
    }


_NAME_QUERY_KEYWORDS = (
    u"\u6211\u53eb\u4ec0\u4e48", u"\u6211\u53eb\u5565", u"\u6211\u7684\u540d\u5b57\u662f\u4ec0\u4e48",
    u"\u6211\u7684\u540d\u5b57\u53eb\u4ec0\u4e48", u"\u6211\u7684\u540d\u5b57", u"\u6211\u53eb\u4ec0\u4e48\u540d\u5b57",
    u"\u4f60\u77e5\u9053\u6211\u53eb\u4ec0\u4e48", u"\u4f60\u77e5\u9053\u6211\u7684\u540d\u5b57",
    u"\u4f60\u8bb0\u5f97\u6211\u53eb\u4ec0\u4e48", u"\u4f60\u8bb0\u5f97\u6211\u7684\u540d\u5b57",
    u"\u8bf4\u51fa\u6765\u6211\u53eb\u4ec0\u4e48", u"\u8bf4\u51fa\u6765\u6211\u7684\u540d\u5b57",
    u"\u8bf4\u6211\u53eb\u4ec0\u4e48", u"\u8bf4\u6211\u7684\u540d\u5b57",
    u"\u53eb\u6211\u4ec0\u4e48", u"\u53eb\u6211\u540d\u5b57", u"\u53eb\u6211\u5565",
    u"\u53eb\u4ec0\u4e48", u"\u53eb\u5565\u540d\u5b57", u"\u77e5\u9053\u6211\u7684\u540d\u5b57",
    u"\u558a\u6211\u4ec0\u4e48", u"\u558a\u6211\u540d\u5b57", u"\u558a\u6211\u5565",
    u"\u73b0\u5728\u558a\u6211\u4ec0\u4e48", u"\u73b0\u5728\u53eb\u6211\u4ec0\u4e48",
    u"\u6240\u4ee5\u73b0\u5728\u558a\u6211\u4ec0\u4e48", u"\u6240\u4ee5\u73b0\u5728\u53eb\u6211\u4ec0\u4e48",
    "what's my name", "whats my name", "what is my name",
    "do you know my name", "do you remember my name", "say my name",
)

_NAME_SET_RES = (
    re.compile(
        u"(?:\u6211\u53eb|\u6211\u7684\u540d\u5b57\u662f|\u6211\u540d\u5b57\u53eb|\u53eb\u6211|"
        u"\u5c31\u53eb\u6211|\u53ef\u4ee5\u53eb\u6211|\u4f60\u53ef\u4ee5\u53eb\u6211|\u4f60\u53ef\u4ee5\u552f\u6211)"
        u"\\s*([^\\s,\uff0c\u3002\uff01!?\uff1f~\uff5e\uff08\uff09()]{1,16})"
    ),
    re.compile(r"(?:my name is|call me|i am|i'm)\s+([A-Za-z][A-Za-z0-9_]{0,15})"),
)
_NAME_SUFFIXES = (
    u"\u5c31\u884c\u4e86", u"\u5c31\u597d", u"\u5c31\u53ef\u4ee5", u"\u5c31\u884c",
    u"\u597d\u4e86", u"\u5427", u"\u5456", u"\u5457", u"\u554a", u"\u5462",
    u"\u4e86", u"\u597d",
)
_NAME_REJECT = frozenset([
    u"\u4ec0\u4e48", u"\u8c01", u"\u5565", u"\u540d\u5b57", u"\u542c\u5230", u"\u542c\u89c1",
    u"\u4ec0\u4e48\u540d\u5b57", u"\u540d\u5b57\u662f\u4ec0\u4e48",
    u"\u5427", u"\u5457", u"\u5456", u"\u554a", u"\u5457", u"\u5462", u"\u597d",
    u"\u4e86", u"\u5c31\u884c", u"\u5c31\u597d", u"\u884c\u5417", u"\u597d\u5417",
    u"\u4f60", u"\u6211", u"\u5427\u554a", u"\u554a\u5427", u"\u90a3",
    "who", "what", "name", "you", "there", "ok", "okay", "yes", "no",
])


def _looks_like_particle(name):
    """True when the extracted 'name' is really just a Chinese sentence particle."""
    if not name:
        return True
    if len(name) == 1:
        return True
    # 2-char names ending with a very common particle usually aren't names.
    tail = name[-1]
    if tail in u"\u5427\u5457\u5456\u554a\u5462\u4e86\u554a\u554a" and len(name) <= 2:
        return True
    return False

_CN_DIGIT = {
    u"\u96f6": 0, u"\u4e00": 1, u"\u4e8c": 2, u"\u4e09": 3, u"\u56db": 4, u"\u4e94": 5,
    u"\u516d": 6, u"\u4e03": 7, u"\u516b": 8, u"\u4e5d": 9, u"\u4e24": 2, u"\u5341": 10,
}


def _strip_name_suffix(name):
    changed = True
    while changed and name:
        changed = False
        for suffix in _NAME_SUFFIXES:
            if name.endswith(suffix) and len(name) > len(suffix):
                name = name[:-len(suffix)].strip()
                changed = True
                break
    return name.strip()


def _extract_name(text):
    for pat in _NAME_SET_RES:
        m = pat.search(text)
        if not m:
            continue
        name = _strip_name_suffix(m.group(1).strip())
        if not name:
            continue
        if name.lower() in _NAME_REJECT:
            continue
        if _looks_like_particle(name):
            continue
        if len(name) > 16:
            continue
        return name
    return None


def _is_name_query(text):
    if u"\u6211\u53eb\u4ec0\u4e48\u540d\u5b57" in text:
        return True
    if u"\u8bf4\u51fa\u6765" in text and (u"\u540d\u5b57" in text or u"\u6211\u53eb" in text):
        return True
    stripped = text.strip().strip(u"!?,")
    if stripped in (
        u"\u53eb\u6211", u"\u558a\u6211", u"\u53eb\u6211\u554a", u"\u558a\u6211\u554a",
        u"\u53eb\u6211\u540d\u5b57", u"\u558a\u6211\u540d\u5b57",
        u"\u53eb\u6211\u7684\u540d\u5b57", u"\u558a\u6211\u7684\u540d\u5b57",
    ):
        return True
    if (u"\u73b0\u5728" in text or u"\u6240\u4ee5" in text or u"\u90a3" in text) \
            and (u"\u558a\u6211" in text or u"\u53eb\u6211" in text) \
            and u"\u4ec0\u4e48" in text:
        return True
    for kw in _NAME_QUERY_KEYWORDS:
        if kw in text:
            return True
    return False


def _parse_cn_number(token):
    if not token:
        return None
    if token.isdigit():
        return int(token)
    total = 0
    current = 0
    for ch in token:
        if ch in _CN_DIGIT:
            val = _CN_DIGIT[ch]
            if val == 10:
                current = max(1, current) * 10
            else:
                current += val
        else:
            return None
    total += current
    return total if total > 0 else None


def _parse_quantity(text):
    if u"\u4e00\u7ec4" in text or u"1\u7ec4" in text or u"\u6574\u7ec4" in text:
        return 64
    m = re.search(r"(\d+)\s*(?:\u4e2a|\u9897|\u679a|\u628a|\u5757|\u7ec4|\u672c|\u6761|\u53ea|\u4ef6)", text)
    if m:
        return int(m.group(1))
    m = re.search(
        u"([\u96f6\u4e00\u4e8c\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u4e24\u5341\u767e]+)"
        u"\s*(?:\u4e2a|\u9897|\u679a|\u628a|\u5757|\u7ec4|\u672c|\u6761|\u53ea|\u4ef6)",
        text,
    )
    if m:
        val = _parse_cn_number(m.group(1))
        if val:
            return val
    if u"\u5341\u9897" in text or u"\u5341\u4e2a" in text:
        return 10
    if u"\u4e00\u9897" in text or u"\u4e00\u628a" in text or u"\u4e00\u5757" in text:
        return 1
    if u"\u4e00\u4e2a" in text:
        if any(k in text for k in (u"\u5bb6", u"\u623f", u"\u623f\u5b50", u"\u4eba", u"house", u"home")):
            return None
        if len(text) <= 10:
            return 1
    if u"\u5341" in text and (u"\u9897" in text or u"\u4e2a" in text):
        return 10
    return None


def _clone_action(action):
    if not action:
        return None
    cloned = dict(action)
    return cloned


def _apply_quantity(action, quantity):
    if not action or quantity is None:
        return action
    cloned = _clone_action(action)
    if cloned.get("type") == "give_item":
        cloned["count"] = max(1, min(int(quantity), 64))
    return cloned


def _is_context_continuation(text, context):
    if not context or not context.get("last_action"):
        return False
    if _is_followup_message(text):
        return True
    qty = _parse_quantity(text)
    if qty is not None and len(text) <= 16:
        return True
    if len(text) <= 8:
        for hint in (u"\u4e00\u7ec4", u"\u518d", u"\u8fd8", u"\u53c8", u"\u591a", u"\u6765\u70b9"):
            if hint in text:
                return True
    return False


def _continue_last_action(text, context, message):
    last_action = context.get("last_action")
    if not last_action:
        return None
    qty = _parse_quantity(text)
    action = _apply_quantity(last_action, qty) if qty else _clone_action(last_action)
    pool = _pool_by_prefix("followup_")
    if pool:
        pick = random.choice(pool)
        topic = pick.get("id") or u"followup"
        en = pick.get("en") or u""
        zh = pick.get("zh") or u""
        sound = _sound_for_entry(pick)
    else:
        topic = (context.get("last_topic") or u"followup") + u"_repeat"
        en = u"Again? Fine, same as before, coming right up."
        zh = u"\u53c8\u8981\u4e00\u6b21\uff1f\u884c\uff0c\u548c\u4e0a\u4e00\u6b21\u4e00\u6837\u3002"
        sound = None
    return _finalize(topic, en, zh, sound, action, context, message)


def _recall_name_reply(name, context, message):
    # Use fixed corpus lines so subtitle and OGG always match.
    # (Runtime TTS cannot speak arbitrary player names.)
    pool = _pool_by_prefix("chat_know_name_")
    if pool:
        pick = random.choice(pool)
        topic = pick.get("id") or u"name_recall"
        en = pick.get("en") or u""
        zh = pick.get("zh") or u""
        sound = _sound_for_entry(pick)
        return _finalize(topic, en, zh, sound, None, context, message)
    en = u"I remember your name."
    zh = u"\u5f53\u7136\u8bb0\u5f97\u4f60\u53eb\u4ec0\u4e48\u3002"
    return _finalize(u"name_recall", en, zh, None, None, context, message)


def _social_shortcut(text, context, message):
    """High-priority routes for common social phrases that fall through scoring."""
    if any(k in text for k in (
        u"\u6211\u559c\u6b22\u4f60", u"\u6211\u7231\u4f60", u"i like you", u"i love you", u"love you",
    )):
        if u"\u5417" not in text and u"?" not in text and u"\uff1f" not in text and "do you" not in text:
            result = _reply_from_pool("chat_compliment_", u"chat_compliment", context, message)
            if result:
                return result
    if any(k in text for k in (
        u"\u6b3a\u8d1f\u6211", u"\u6253\u6211", u"\u6709\u4eba\u6253", u"\u6551\u6211", u"\u6551\u6551",
        u"help me", u"save me", u"bullied", u"hurt me",
    )):
        result = _reply_from_pool("chat_help_", u"chat_help", context, message)
        if result:
            return result
    if text in (u"\u545c\u545c", u"\u545c\u545c\u545c", u"\u545c\u545c\u545c\u545c") or text.startswith(u"\u545c\u545c"):
        result = _reply_from_pool("chat_help_", u"chat_help", context, message)
        if result:
            return result
    return None


def _pool_by_prefix(prefix):
    pool = [e for e in _ENTRIES if (e.get("id") or "").startswith(prefix)]
    pool = pool + [e for e in _FALLBACKS if (e.get("id") or "").startswith(prefix)]
    return _prefer_voiced(pool)


def _reply_from_pool(prefix, fallback_topic, context, message):
    pool = _pool_by_prefix(prefix)
    if not pool:
        return None
    pick = random.choice(pool)
    topic = pick.get("id") or fallback_topic
    en = pick.get("en") or u""
    zh = pick.get("zh") or u""
    sound = _sound_for_entry(pick)
    return _finalize(topic, en, zh, sound, pick.get("action"), context, message)


def _context_bonus(entry, context):
    if not context:
        return 0
    bonus = 0
    last_category = context.get("last_category")
    cat = _entry_category(entry)
    if last_category and cat == last_category:
        bonus += _CONTEXT_BONUS
    last_text = (context.get("last_player_text") or u"").lower()
    if last_text:
        for kw in (entry.get("keywords") or []):
            kw_u = _to_unicode(kw).lower()
            if kw_u and kw_u in last_text:
                bonus += 2
                break
    return bonus


def _record_history(context, role, text):
    if context is None:
        return
    history = context.setdefault("history", [])
    history.append([role, text])
    if len(history) > _HISTORY_LIMIT:
        del history[0:len(history) - _HISTORY_LIMIT]


def _finalize(topic, en, zh, sound, action, context, player_text):
    if context is not None:
        context["last_topic"] = topic
        context["last_category"] = topic.split("_")[0] if topic else None
        context["last_player_text"] = _to_unicode(player_text)
        if action:
            context["last_action"] = _clone_action(action)
        _record_history(context, "player", player_text)
        _record_history(context, "verity", en)
    return topic, en, zh, sound, action


def get_reply_with_action(message, context=None):
    """
    Return (topic_id, english, chinese, sound_key, action_dict_or_none).
    Returns None when corpus is unavailable (caller should use legacy dialogue).

    `context` is an optional mutable dict (see new_context()) used for
    lightweight conversation memory: short follow-up replies ("再来",
    "more", "same again") reuse the previous topic/action rather than
    matching a random fallback line.
    """
    _load_corpus()
    text = _to_unicode(message).lower().strip()

    if not _ENTRIES:
        return None

    if not text:
        topic, en, zh, sound, action = _pick_fallback()
        return _finalize(topic, en, zh, sound, action, context, message)

    if context is not None and _is_name_query(text):
        name = context.get("player_name")
        if name:
            return _recall_name_reply(name, context, message)
        result = _reply_from_pool("chat_dont_know_name_", u"chat_dont_know_name", context, message)
        if result:
            return result

    if context is not None:
        name = _extract_name(text)
        if name:
            context["player_name"] = name
            result = _reply_from_pool("chat_remember_name_", u"chat_remember_name", context, message)
            if result:
                return result

    shortcut = _social_shortcut(text, context, message)
    if shortcut:
        return shortcut

    brain_shortcut = _try_brain_voice_shortcut(text, context, message)
    if brain_shortcut:
        return brain_shortcut

    if context is not None and _is_context_continuation(text, context):
        cont = _continue_last_action(text, context, message)
        if cont:
            return cont

    pick, best_score = _pick_best_entry(text, context, action_only=False)
    if pick and best_score >= _MIN_SCORE:
        topic = pick.get("id") or u"reply"
        en = pick.get("en") or u""
        zh = pick.get("zh") or u""
        sound = _sound_for_entry(pick)
        action = pick.get("action")
        qty = _parse_quantity(text)
        if action and qty is not None:
            action = _apply_quantity(action, qty)
        return _finalize(topic, en, zh, sound, action, context, message)

    topic, en, zh, sound, action = _pick_fallback()
    return _finalize(topic, en, zh, sound, action, context, message)


def _pick_fallback():
    _load_corpus()
    if _FALLBACKS:
        pool = _prefer_voiced(_FALLBACKS)
        pick = random.choice(pool)
        return (
            pick.get("id") or u"fallback",
            pick.get("en") or u"",
            pick.get("zh") or u"",
            _sound_for_entry(pick),
            None,
        )
    return u"fallback", u"Noted.", u"\u6536\u5230\u3002", None, None


def iter_voice_jobs():
    """Yield (slug, english_text) for TTS generation."""
    _load_corpus()
    seen = set()
    for entry in _ENTRIES:
        entry_id = entry.get("id")
        if not entry_id or entry_id in seen:
            continue
        seen.add(entry_id)
        en = entry.get("en") or ""
        if en:
            yield entry_id, en
    for entry in _FALLBACKS:
        entry_id = entry.get("id")
        if not entry_id or entry_id in seen:
            continue
        seen.add(entry_id)
        en = entry.get("en") or ""
        if en:
            yield entry_id, en
