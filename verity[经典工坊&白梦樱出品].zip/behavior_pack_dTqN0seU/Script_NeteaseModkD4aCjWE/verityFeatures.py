# -*- coding: utf-8 -*-
"""Locate structures, batch summon, batch give items."""
from __future__ import print_function

import random
import re

try:
    unicode
except NameError:
    unicode = str

MAX_SUMMON = 30

STRUCTURE_ENTRIES = (
    ((u"\u6751\u5e84", u"\u6751", u"\u6751\u6c11", "village"), 7),
    ((u"\u672b\u5730\u57ce", u"\u672b\u5730\u8239", "end city"), 1),
    ((u"\u5730\u72f1\u8981\u585e", "fortress"), 2),
    ((u"\u77ff\u9053", u"\u5e9f\u77ff", "mineshaft"), 3),
    ((u"\u6d77\u5e95\u795e\u6bbf", u"\u6d77\u5e95\u9057\u8ff9", "monument"), 4),
    ((u"\u8981\u585e", u"\u672b\u5730\u8981\u585e", u"\u5730\u7262", "stronghold"), 5),
    ((u"\u795e\u6bbf", u"\u6c99\u6f20\u795e\u6bbf", u"\u4e1b\u6797\u795e\u6bbf", "temple"), 6),
    ((u"\u6797\u5730\u5e9c\u9093", "woodland mansion"), 8),
    ((u"\u6c89\u8239", "shipwreck"), 9),
    ((u"\u57cb\u85cf\u5b9d\u85cf", "buried treasure"), 10),
    ((u"\u6d77\u5e95\u9057\u8ff9", "ruins"), 11),
    ((u"\u524a\u593a\u8005\u524d\u54e8\u7ad9", u"\u524d\u54e8\u7ad9", "pillager outpost"), 12),
    ((u"\u5815\u843d\u7684\u4f20\u9001\u95e8", u"\u4f20\u9001\u95e8\u9057\u8ff9", "ruined portal"), 13),
    ((u"\u731b\u517d\u8981\u585e", "bastion"), 14),
    ((u"\u6df1\u6697\u4e4b\u57df", u"\u76d1\u5b88\u8005", "ancient city"), 15),
    ((u"\u9057\u8ff9", "trail ruins"), 16),
    ((u"\u8bd5\u70bc", u"\u8bd5\u70bc\u5ba4", "trial chambers"), 17),
)

STRUCTURE_HINTS = []
for keywords, feature_id in STRUCTURE_ENTRIES:
    for kw in keywords:
        STRUCTURE_HINTS.append((kw, feature_id))

# Extra summonable mobs (merged into brain via get_extra_mobs)
EXTRA_MOBS = {
    u"\u7f8a\u9a7b\u5546\u4eba": "minecraft:wandering_trader",
    u"\u6d41\u6d6a\u5546\u4eba": "minecraft:wandering_trader",
    u"\u7f8a\u9a7b\u9a7f": "minecraft:trader_llama",
    u"\u7f8a\u9a7b\u5546\u4eba\u7684\u7f8a\u9a7b\u9a7f": "minecraft:trader_llama",
    u"\u5c4f\u98ce\u602a\u517d": "minecraft:iron_golem",
    u"\u94c1\u5076\u50cf": "minecraft:iron_golem",
    u"\u96ea\u8304\u5b50": "minecraft:snow_golem",
    u"\u96ea\u5076\u50cf": "minecraft:snow_golem",
    u"\u96ea\u4eba": "minecraft:snow_golem",
    u"\u7f8a\u9a7b\u5546\u4eba": "minecraft:wandering_trader",
    u"\u6d77\u9f99": "minecraft:guardian",
    u"\u5b88\u536b\u8005": "minecraft:guardian",
    u"\u53f2\u83b1\u59c6": "minecraft:shulker",
    u"\u5e7b\u7075": "minecraft:illusioner",
    u"\u5524\u9b54\u8005": "minecraft:evoker",
    u"\u52ab\u63f4\u517d": "minecraft:ravager",
    u"\u52ab\u63f4\u8005": "minecraft:pillager",
    u"\u536b\u9053\u5175": "minecraft:vindicator",
    u"\u5c4b\u5996": "minecraft:phantom",
    u"\u6d78\u6ca5\u8005": "minecraft:drowned",
    u"\u5c38\u58f3": "minecraft:husk",
    u"\u6d41\u7554": "minecraft:stray",
    u"\u7070\u7070\u4eba": "minecraft:ghast",
    u"\u8759\u8839": "minecraft:bat",
    u"\u9ca4\u9c7c": "minecraft:dolphin",
    u"\u6d77\u9f9f": "minecraft:turtle",
    u"\u6d77\u661f": "minecraft:starfish",
    u"\u706b\u7130\u602a": "minecraft:blaze",
    u"\u9ed1\u6697\u7070\u7070\u4eba": "minecraft:ghast",
    u"\u8721\u6c64\u602a\u517d": "minecraft:warden",
    u"\u6d88\u5931\u68f0": "minecraft:wither",
    u"\u672b\u5f71\u9f99": "minecraft:ender_dragon",
    u"\u8717\u725b": "minecraft:snail",
    "bee": "minecraft:bee",
    "axolotl": "minecraft:axolotl",
    "frog": "minecraft:frog",
    "tadpole": "minecraft:tadpole",
    "allay": "minecraft:allay",
    "camel": "minecraft:camel",
}

GIFT_BUNDLE = (
    ("minecraft:diamond", 8),
    ("minecraft:iron_ingot", 32),
    ("minecraft:gold_ingot", 16),
    ("minecraft:emerald", 16),
    ("minecraft:bread", 32),
    ("minecraft:cooked_beef", 32),
    ("minecraft:golden_apple", 4),
    ("minecraft:ender_pearl", 8),
    ("minecraft:obsidian", 16),
    ("minecraft:torch", 64),
    ("minecraft:arrow", 64),
    ("minecraft:bow", 1),
    ("minecraft:diamond_sword", 1),
    ("minecraft:diamond_pickaxe", 1),
    ("minecraft:diamond_axe", 1),
    ("minecraft:diamond_helmet", 1),
    ("minecraft:diamond_chestplate", 1),
    ("minecraft:diamond_leggings", 1),
    ("minecraft:diamond_boots", 1),
    ("minecraft:shield", 1),
    ("minecraft:elytra", 1),
    ("minecraft:totem_of_undying", 1),
    ("minecraft:experience_bottle", 16),
    ("minecraft:enchanted_golden_apple", 2),
)


def get_extra_mobs():
    return dict(EXTRA_MOBS)


def _match_any(text, keywords):
    for kw in keywords:
        if kw in text:
            return True
    return False


def parse_structure(text):
    low = text.lower()
    for kw, feature_id in STRUCTURE_HINTS:
        if kw in text or kw in low:
            return feature_id, kw
    return None, None


def try_locate_list(text, context, message):
    if u"\u5b9a\u4f4d" not in text and "locate" not in text.lower():
        return None
    if parse_structure(text)[0] is not None:
        return None
    # Bare "\u5b9a\u4f4d" / "locate" prompts the structure type list.
    stripped = text.strip().strip(u"\uff01\uff1f!?\u3002\uff0c,")
    bare = stripped in (
        u"\u5b9a\u4f4d", u"\u5b9a\u4f4d\u7ed3\u6784", "locate", "locate structure",
    )
    if not bare and not _match_any(text, (
        u"\u7ed3\u6784", u"\u8981\u585e", u"\u9057\u8ff9", u"\u5b9a\u4f4d\u7ed3\u6784",
        u"\u5b9a\u4f4d ", "locate structure",
    )):
        # Still treat short "\u5b9a\u4f4dxxx" without known structure as list prompt
        if u"\u5b9a\u4f4d" in text or text.lower().startswith("locate"):
            pass
        else:
            return None
    zh = u"\u60f3\u627e\u54ea\u79cd\uff1f\u6751\u5e84\u3001\u8981\u585e\u3001\u6d77\u5e95\u795e\u6bbf\u3001\u672b\u5730\u57ce\u3001\u6c89\u8239\u3001\u6797\u5730\u5e9c\u90c5\u2026\u2026\u8bf4\u300c\u5b9a\u4f4d\u6751\u5e84\u300d\u8fd9\u6837\u7684\u5c31\u884c\u3002"
    return _voiced("chat_help_", "feat_locate_list", u"Which structure?", zh, None)


def _is_scene_report_query(text):
    """Player explicitly asks what is nearby  not terrain/build suitability."""
    return _match_any(text, (
        u"\u9644\u8fd1\u6709\u4ec0\u4e48", u"\u5468\u56f4\u6709\u4ec0\u4e48", u"\u8fd9\u9644\u8fd1\u6709\u4ec0\u4e48",
        u"\u8fd9\u513f\u6709\u4ec0\u4e48", u"\u8fd9\u91cc\u6709\u4ec0\u4e48", u"\u9644\u8fd1\u6709\u5565",
        u"\u5468\u56f4\u6709\u5565", u"\u770b\u770b\u6709\u4ec0\u4e48", u"\u6709\u4ec0\u4e48\u4e1c\u897f",
        u"\u5468\u56f4\u6709\u4ec0\u4e48\u4e1c\u897f", u"\u9644\u8fd1\u6709\u4ec0\u4e48\u4e1c\u897f",
        "what is nearby", "what's nearby", "anything nearby",
    ))


def _is_scene_question(text):
    if _match_any(text, (
        u"\u770b\u770b\u5468\u56f4", u"\u770b\u5468\u56f4", u"\u5468\u56f4\u600e\u4e48\u6837",
        u"\u9644\u8fd1\u600e\u4e48\u6837", u"\u770b\u770b\u9644\u8fd1", u"\u5468\u56f4\u6709\u4ec0\u4e48",
        u"\u9644\u8fd1\u6709\u4ec0\u4e48", u"\u5730\u5f62", u"\u5730\u52bf", u"\u73af\u5883",
        u"\u8fd9\u513f\u600e\u4e48\u6837", u"\u8fd9\u91cc\u600e\u4e48\u6837",
        u"\u9002\u5408\u5efa", u"\u9002\u5408\u76d6", u"\u80fd\u5efa", u"\u80fd\u76d6", u"\u53ef\u4ee5\u5efa",
        u"\u770b\u770b\u5730\u5f62", u"\u770b\u5730\u5f62", u"\u5468\u56f4\u5730\u5f62", u"\u9644\u8fd1\u5730\u5f62",
        u"\u5730\u5f62\u600e\u4e48\u6837", u"\u73af\u5883\u600e\u4e48\u6837", u"\u8fd9\u9644\u8fd1",
        u"\u8fd9\u513f\u9002\u4e0d\u9002\u5408", u"\u9002\u4e0d\u9002\u5408\u5efa", u"\u5efa\u623f\u5417", u"\u76d6\u623f\u5417",
        "terrain", "good for building", "look around",
    )):
        return True
    return False


def try_scene_query(text, context, message):
    if not _is_scene_question(text):
        return None
    if _is_scene_report_query(text):
        action = {"type": "report_scene"}
        return _voiced("chat_help_", "feat_scene_report", u"Looking around.", u"\u6211\u770b\u770b\u9644\u8fd1\u6709\u4ec0\u4e48\u2026\u2026", action)
    scene = context.get("last_scene")
    if scene and not _is_scene_report_query(text):
        try:
            import verityEnvironment as env
            line = env.pick_scene_line(context, scene)
            if line:
                return line
        except Exception:
            pass
    action = {"type": "report_scene"}
    return _voiced("brain_build_", "feat_scene_q", u"Survey.", u"\u6211\u770b\u770b\u8fd9\u9644\u8fd1\u9002\u4e0d\u9002\u5408\u5efa\u623f\u5b50\u2026\u2026", action)


def try_locate(text, context, message):
    if not _match_any(text, (
        u"\u5b9a\u4f4d", u"\u627e", u"\u5728\u54ea", u"\u5728\u54ea\u91cc", u"\u600e\u4e48\u53bb",
        u"\u9057\u8ff9", u"\u7ed3\u6784", u"\u8981\u585e",
        "locate", "find", "where is",
    )):
        return None
    feature_id, kw = parse_structure(text)
    if feature_id is None:
        return None
    action = {"type": "locate_structure", "feature": feature_id, "label": kw}
    return _voiced("chat_help_", "feat_locate", u"Locating.", u"\u597d\uff0c\u6211\u6765\u5e2e\u4f60\u627e\u3002", action)


def try_summon_all(text, context, message):
    if not _match_any(text, (u"\u6240\u6709\u751f\u7269", u"\u5168\u90e8\u751f\u7269", u"\u6240\u6709\u602a", u"\u5168\u90e8\u602a")):
        return None
    if u"\u53ec\u5524" not in text and u"\u751f\u6210" not in text and "summon" not in text.lower():
        return None
    count = _parse_count(text, 3)
    count = max(1, min(count, 5))
    action = {"type": "summon_mob_all", "count_each": count}
    return _voiced("brain_summon_", "feat_summon_all", u"Summoning.", u"\u884c\uff0c\u7ed9\u4f60\u53ec\u5524\u4e00\u6279\u751f\u7269\u3002", action)


def try_give_bundle(text, context, message):
    if not _match_any(text, (
        u"\u6240\u6709\u7269\u54c1", u"\u5168\u90e8\u7269\u54c1", u"\u6240\u6709\u4e1c\u897f",
        u"\u5168\u90e8\u4e1c\u897f", u"\u5927\u793c\u5305", u"\u8d60\u9001\u5927\u793c",
    )):
        return None
    if not _match_any(text, (u"\u7ed9", u"\u8981", u"\u60f3\u8981", u"\u8d60", u"\u6063\u60e0", "give")):
        return None
    action = {"type": "give_item_bundle", "items": list(GIFT_BUNDLE)}
    return _voiced("chat_give_item_", "feat_give_bundle", u"Gift bundle.", u"\u597d\uff0c\u5927\u793c\u5305\u6765\u4e86\u3002", action)


def try_where_are_you(text, context, message):
    if not _match_any(text, (
        u"\u4f60\u5728\u54ea", u"\u4f60\u5728\u54ea\u91cc", u"\u4f60\u5728\u4ec0\u4e48\u5730\u65b9",
        u"\u4f60\u73b0\u5728\u5728\u54ea", u"\u4f60\u5728\u54ea\u5462", u"severity\u5728\u54ea",
        u"\u6837\u672c\u5728\u54ea", u"\u4f60\u7684\u4f4d\u7f6e", u"\u73b0\u5728\u5728\u54ea",
        u"\u5728\u54ea\u5462", u"\u4f60\u5728\u5730\u56fe\u54ea",
    )):
        return None
    if parse_structure(text)[0] is not None and _match_any(text, (
        u"\u627e", u"\u5b9a\u4f4d", u"\u600e\u4e48\u53bb",
    )):
        return None
    if _match_any(text, (u"\u60f3\u4f60", u"\u597d\u60f3\u4f60", u"\u5728\u60f3\u4f60")):
        return None
    action = {"type": "report_severity_pos"}
    return _voiced("brain_meta_players_", "feat_where", u"Checking.", u"\u6211\u770b\u770b\u6211\u5728\u54ea\u2026\u2026", action)


def try_distance(text, context, message):
    if not _match_any(text, (
        u"\u591a\u8fdc", u"\u8ddd\u79bb", u"\u79bb\u6211\u591a\u8fdc", u"\u79bb\u6211\u6709\u591a\u8fdc",
        u"\u8ddd\u6211\u591a\u8fdc", u"\u6709\u591a\u8fdc", u"how far",
    )):
        return None
    action = {"type": "report_distance"}
    return _voiced("brain_meta_players_", "feat_distance", u"Checking.", u"\u6211\u770b\u770b\u6709\u591a\u8fdc\u2026\u2026", action)


def try_teleport_here(text, context, message):
    stripped = text.strip().strip(u"\uff01\uff1f!?。，,")
    if stripped in (u"\u4f20\u9001", u"\u77ac\u79fb", u"\u8fc7\u6765", u"\u8fc7\u6765\u5427"):
        action = {"type": "teleport_severity_to_player"}
        return _voiced("chat_follow_", "cmd_tp_short", u"On my way.", u"\u597d\uff0c\u6211\u8fc7\u6765\u3002", action)
    if not _match_any(text, (
        u"\u4f20\u9001\u5230\u6211\u8fd9", u"\u77ac\u79fb\u8fc7\u6765", u"\u7acb\u523b\u8fc7\u6765",
        u"\u9a6c\u4e0a\u8fc7\u6765", u"\u5230\u6211\u8fd9\u6765", u"\u6765\u6211\u8fd9\u513f",
        u"\u5230\u6211\u8eab\u8fb9\u6765", u"\u628a\u4f60\u4f20\u9001\u8fc7\u6765",
        u"\u6765\u6211\u8fd9\u91cc", u"\u4f20\u9001\u6211", u"\u53eb\u4f60\u8fc7\u6765",
        "teleport to me", "tp to me", "come here",
    )):
        return None
    action = {"type": "teleport_severity_to_player"}
    return _voiced("chat_follow_", "feat_tp_here", u"On my way.", u"\u597d\uff0c\u6211\u8fc7\u6765\u3002", action)


def try_game_time(text, context, message):
    if not _match_any(text, (
        u"\u51e0\u70b9\u4e86", u"\u51e0\u70b9\u949f", u"\u73b0\u5728\u51e0\u70b9",
        u"\u5f53\u524d\u65f6\u95f4", u"\u73b0\u5728\u65f6\u95f4", u"\u6e38\u620f\u65f6\u95f4",
        u"\u5929\u9ed1\u5417", u"\u5929\u4eae\u5417", u"\u665a\u4e0a\u5417", u"\u65e9\u4e0a\u5417",
        u"\u73b0\u5728\u662f\u767d\u5929\u8fd8\u662f\u665a\u4e0a",
        u"\u73b0\u5728\u662f\u665a\u4e0a\u8fd8\u662f\u767d\u5929", u"\u51e0\u70b9\u949f\u4e86",
        u"\u51e0\u70b9\u949f\u4e86", u"\u591a\u665a\u4e86", u"\u591a\u65e9\u4e86",
        "what time", "game time", "current time",
    )):
        return None
    if _match_any(text, (
        u"\u559c\u6b22", u"\u7231", u"\u8ba4\u8bc6", u"\u8ba4\u8bc6\u4f60", u"\u7ed3\u5a5a",
        u"\u5728\u60f3", u"\u60f3\u4f60", u"\u5173\u7cfb", u"\u611f\u60c5",
    )):
        return None
    action = {"type": "query_game_time"}
    return _voiced("brain_meta_players_", "feat_time", u"Checking time.", u"\u6211\u770b\u770b\u73b0\u5728\u51e0\u70b9\u2026\u2026", action)


def try_weather_query(text, context, message):
    if not _match_any(text, (
        u"\u5929\u6c14", u"\u4e0b\u96e8\u5417", u"\u5728\u4e0b\u96e8", u"\u4e0b\u96e8\u4e86\u5417",
        u"\u6674\u5929\u5417", u"\u6253\u96f7\u5417", u"\u5929\u6c14\u600e\u4e48\u6837",
        u"\u4eca\u5929\u5929\u6c14", u"\u5929\u6c14\u5982\u4f55", u"\u73b0\u5728\u5929\u6c14",
        "weather", "raining",
    )):
        return None
    scene = context.get("last_scene") or {}
    if scene.get("thunder"):
        zh = u"\u5728\u6253\u96f7\uff0c\u522b\u5728\u5916\u9762\u6d78\u6dcb\u3002"
    elif scene.get("raining"):
        zh = u"\u5728\u4e0b\u96e8\uff0c\u5148\u953b\u4e00\u4f1a\u5427\u3002"
    else:
        hour = scene.get("hour")
        if hour is None:
            zh = u"\u5929\u6c14\u4e0d\u9519\uff0c\u6ca1\u4e0b\u96e8\u3002"
        elif hour >= 22 or hour < 5:
            zh = u"\u591c\u91cc\u5929\u4e0d\u9519\uff0c\u6ca1\u4e0b\u96e8\uff0c\u5c31\u662f\u9ed1\u4e86\u70b9\u3002"
        else:
            zh = u"\u5929\u6c14\u4e0d\u9519\uff0c\u9002\u5408\u6d3b\u52a8\u3002"
    return _voiced_keep("chat_help_", "feat_weather", u"Weather.", zh, None)


def try_feature_reply(text, context, message):
    for fn in (
        try_locate,
        try_locate_list,
        try_game_time,
        try_scene_query,
        try_weather_query,
        try_where_are_you,
        try_distance,
        try_teleport_here,
        try_summon_all,
        try_give_bundle,
    ):
        result = fn(text, context, message)
        if result is not None:
            return result
    return None


def _parse_count(text, default):
    m = re.search(r"(\d+)", text)
    if m:
        try:
            return int(m.group(1))
        except Exception:
            pass
    if u"\u5341" in text:
        return 10
    if u"\u4e94" in text:
        return 5
    if u"\u4e09" in text or u"\u51e0" in text:
        return 3
    return default


def _voiced(prefix, topic, en, zh, action):
    try:
        import verityBrain as brain
        return brain._pack(topic, en, zh, prefix, action)
    except Exception:
        pass
    return topic, en, zh, None, action


def _voiced_keep(prefix, topic, en, zh, action):
    try:
        import verityBrain as brain
        return brain._pack_keep(topic, en, zh, prefix, action)
    except Exception:
        pass
    return topic, en, zh, None, action
