# -*- coding: utf-8 -*-
"""Verity story voice lines mapped to NetEase sound events."""
from __future__ import print_function

try:
    unicode
except NameError:
    unicode = str

VERITY_VOICE = {
    "yes_south": {
        "sound": "verity.voice.yes_south",
        "zh": u"\u662f\u7684\uff0c\u5728\u5357\u8fb9\u3002",
    },
    "something_passed": {
        "sound": "verity.voice.something_passed",
        "zh": u"\u521a\u521a\u6709\u4e1c\u897f\u7ecf\u8fc7\u3002",
    },
    "no2": {
        "sound": "verity.voice.no2",
        "zh": u"\u4e0d\u3002",
    },
    "you_are_mine": {
        "sound": "verity.voice.you_are_mine",
        "zh": u"\u4f60\u662f\u6211\u7684\u3002",
    },
    "im_smiling_now": {
        "sound": "verity.voice.im_smiling_now",
        "zh": u"\u73b0\u5728\u5728\u7b11\u4e86\u3002",
    },
    "opening": {
        "sound": "verity.voice.opening",
        "zh": u"\u4f60\u597d\uff0c\u6211\u662f Verity\u3002",
    },
    "somethingiscomingin3days": {
        "sound": "verity.voice.somethingiscomingin3days",
        "zh": u"\u4e09\u5929\u540e\u2026\u2026",
    },
    "mobbbbb": {
        "sound": "verity.voice.mobbbbb",
        "zh": u"\u602a\u7269\u6765\u4e86\u3002",
    },
}


def get_verity_voice(slug):
    return VERITY_VOICE.get(slug)
