# -*- coding: utf-8 -*-
"""Core knowledge entries from verity_knowledge_data.js (subset)."""
from __future__ import print_function

import random
import re

try:
    unicode
except NameError:
    unicode = str

_QUESTION_LEAD = re.compile(
    u"^(?:\u4ec0\u4e48|\u8c01|\u54ea|\u4e3a\u4f55|\u4e3a\u4ec0\u4e48|\u600e\u4e48|\u5982\u4f55|\u54ea\u4e2a|\u80fd|\u53ef\u4ee5|\u4f1a|\u5e94\u8be5|\u662f|\u505a|\u5c06|\u544a\u8bc9|\u89e3\u91ca|\u5b9a\u4e49|\u63cf\u8ff0|\u4ecb\u7ecd)",
    re.I | re.U,
)

# keywords, optional pattern strings, answers
_ENTRIES = [
    (
        [u"\u8c01", u"\u521b\u9020", u"\u5236\u4f5c", u"\u4f60"],
        [u"\u8c01\u521b\u9020\u4e86\u4f60", u"\u8c01\u5236\u4f5c\u4e86\u4f60"],
        [
            u"ThatMob \u521b\u9020\u4e86\u6211\u2014\u2014\u8fd9\u4e2a\u7403\u3001\u58f0\u97f3\u3001\u6574\u4e2a Verity \u6982\u5ff5\u3002PnTMC \u6784\u5efa\u4e86\u4f60\u6b63\u5728\u7528\u7684\u9644\u52a0\u5305\u3002",
        ],
    ),
    (
        [u"\u8c01", u"\u5236\u4f5c", u"\u9644\u52a0\u5305", u"PnTMC"],
        [u"\u8c01\u5236\u4f5c\u4e86\u8fd9\u4e2a"],
        [
            u"PnTMC \u5236\u4f5c\u4e86\u8fd9\u4e2a\u9644\u52a0\u5305\u3002ThatMob \u542f\u53d1\u4e86 Verity\u3002",
        ],
    ),
    (
        [u"ThatMob"],
        [u"ThatMob\u662f\u8c01"],
        [u"ThatMob \u662f\u62e5\u670950\u4e07+\u8ba2\u9605\u8005\u7684\u521b\u4f5c\u8005\uff0c\u4ed6\u521b\u9020\u4e86 Verity\u3002"],
    ),
    (
        [u"PnTMC"],
        [u"PnTMC\u662f\u8c01"],
        [u"PnTMC \u6784\u5efa\u4e86\u8fd9\u4e2a\u57fa\u5ca9\u7248\u5305\u3002"],
    ),
    (
        [u"\u4eba\u5de5\u667a\u80fd", u"AI", u"\u667a\u80fd"],
        [u"\u4ec0\u4e48\u662f\u4eba\u5de5\u667a\u80fd"],
        [
            u"\u4eba\u5de5\u667a\u80fd\u662f\u4ece\u6570\u636e\u4e2d\u5b66\u4e60\u6a21\u5f0f\u5e76\u505a\u51fa\u9884\u6d4b\u6216\u51b3\u7b56\u7684\u8f6f\u4ef6\u3002\u6211\u662f\u7528\u89c4\u5219\u548c\u77e5\u8bc6\u5e93\u6784\u5efa\u7684\u3002",
        ],
    ),
    (
        [u"\u94bb\u77f3", u"diamond"],
        [u"\u94bb\u77f3\u5728\u54ea", u"\u600e\u4e48\u83b7\u5f97\u94bb\u77f3"],
        [
            u"\u94bb\u77f3\u5728 Y=-59 \u9644\u8fd1\u6700\u591a\u3002\u7528\u94c1\u9550\u6216\u66f4\u597d\u7684\u9550\u6316\u3002",
        ],
    ),
    (
        [u"\u6751\u6c11", u"villager"],
        [u"\u6751\u6c11"],
        [
            u"\u6751\u6c11\u662f\u4ea4\u6613\u548c\u751f\u7269\u751f\u6210\u7684\u6838\u5fc3\u3002\u4fdd\u62a4\u4ed6\u4eec\u548c\u5de5\u4f5c\u53f0\u3002",
        ],
    ),
    (
        [u"\u672b\u5730", u"end"],
        [u"\u672b\u5730\u95e8", u"\u600e\u4e48\u53bb\u672b\u5730"],
        [
            u"\u5728\u4e3b\u4e16\u754c\u627e\u8981\u585e\uff0c\u653e\u5165\u773c\u775b\u548c\u672b\u5730\u4f20\u9001\u95e8\u6846\u6fc0\u6d3b\u3002",
        ],
    ),
    (
        [u"\u4e0b\u754c", u"nether"],
        [u"\u4e0b\u754c\u95e8"],
        [
            u"\u7528\u9ed1\u66dc\u77f3\u642d 4\u00d75 \u6846\uff0c\u7528\u706b\u6253\u70b9\u3002",
        ],
    ),
    (
        [u"Verity", u"\u4f60\u662f\u8c01"],
        [u"\u4f60\u662f\u8c01", u"\u4f60\u662f\u4ec0\u4e48"],
        [
            u"\u6211\u662f Verity\uff0c\u4f60\u7684\u79c1\u4eba\u52a9\u624b\u670b\u53cb\u3002\u4f60\u53ef\u4ee5\u95ee\u6211\u4efb\u4f55\u4e8b\u3002",
        ],
    ),
]


def _tokenize(text):
    return re.findall(u"[\\w\\u4e00-\\u9fff]+", text.lower())


def _score_entry(message, keywords, patterns):
    n = message.lower()
    tokens = set(_tokenize(n))
    for pat in patterns:
        if not pat:
            continue
        if pat in message or pat in n:
            return 100
        try:
            if re.search(pat, message, re.I | re.U):
                return 100
        except Exception:
            pass
    score = 0
    for kw in keywords:
        kl = kw.lower()
        if kl in tokens:
            score += 4
        elif kl in n:
            score += 2
    return score


def try_knowledge_answer(message):
    if not message:
        return None
    text = message.strip()
    if not isinstance(text, unicode):
        try:
            text = unicode(text)
        except Exception:
            text = unicode(str(text), "utf-8", "ignore")
    best = None
    best_score = 0
    for keywords, patterns, answers in _ENTRIES:
        sc = _score_entry(text, keywords, patterns)
        if sc > best_score:
            best_score = sc
            best = answers
    min_score = 5 if _QUESTION_LEAD.search(text) else 6
    if best and best_score >= min_score:
        return random.choice(best)
    return None
