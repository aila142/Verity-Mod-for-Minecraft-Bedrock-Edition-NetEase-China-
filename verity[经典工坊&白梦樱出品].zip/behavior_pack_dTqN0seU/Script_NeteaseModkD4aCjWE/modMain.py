# -*- coding: utf-8 -*-

from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi
import mod.client.extraClientApi as clientApi

MOD_NAME = "VerityMod"
SERVER_NAME = "server"
CLIENT_NAME = "client"


@Mod.Binding(name="Script_NeteaseModkD4aCjWE", version="1.0.0")
class Script_NeteaseModkD4aCjWE(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def Script_NeteaseModkD4aCjWEServerInit(self):
        print("Verity mod server init")
        serverApi.RegisterSystem(
            MOD_NAME, SERVER_NAME,
            "Script_NeteaseModkD4aCjWE.verityModServer.VerityModServerSystem"
        )

    @Mod.DestroyServer()
    def Script_NeteaseModkD4aCjWEServerDestroy(self):
        pass

    @Mod.InitClient()
    def Script_NeteaseModkD4aCjWEClientInit(self):
        print("Verity mod client init")
        clientApi.RegisterSystem(
            MOD_NAME, CLIENT_NAME,
            "Script_NeteaseModkD4aCjWE.verityModClient.VerityModClientSystem"
        )

    @Mod.DestroyClient()
    def Script_NeteaseModkD4aCjWEClientDestroy(self):
        pass
