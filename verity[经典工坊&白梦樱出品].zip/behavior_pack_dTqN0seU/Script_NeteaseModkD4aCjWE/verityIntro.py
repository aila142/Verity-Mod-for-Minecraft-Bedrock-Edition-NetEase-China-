# -*- coding: utf-8 -*-
"""Verity new-game intro: welcome message and intro-complete flag."""
from __future__ import print_function

try:
    unicode
except NameError:
    unicode = str

WELCOME_MESSAGE = (
    u"\u00a7o\u00a77\u611f\u8c22\u60a8\u6e38\u73a9 \u00a7eVerity \u00a77\uff0c"
    u"\u7075\u611f\u6765\u81ea ThatMob \u7684 Verity\n\n"
    u"\u00a77\u00a7o\u627e\u5230\u7eb8\u7bb1\u5e76\u4e0e\u4e4b\u4ea4\u4e92\u4ee5\u5524\u9192 Verity\u3002"
)

INTRO_COMPLETE_KEY = "verity_intro_complete_v1"


def send_welcome(server, player_id):
    if not player_id:
        return
    try:
        server._notify_player(player_id, WELCOME_MESSAGE)
    except Exception:
        pass


def is_intro_complete(server):
    try:
        import mod.server.extraServerApi as serverApi
        CF = serverApi.GetEngineCompFactory()
        LEVEL_ID = serverApi.GetLevelId()
        return bool(CF.CreateExtraData(LEVEL_ID).GetExtraData(INTRO_COMPLETE_KEY))
    except Exception:
        return False


def mark_intro_complete(server):
    try:
        import mod.server.extraServerApi as serverApi
        CF = serverApi.GetEngineCompFactory()
        LEVEL_ID = serverApi.GetLevelId()
        CF.CreateExtraData(LEVEL_ID).SetExtraData(INTRO_COMPLETE_KEY, 1, True)
    except Exception:
        pass
