# -*- coding: utf-8 -*-
"""
Verity soul — relationship roles, anger, forgiveness, romance, casual chat,
long-term memory, role-based addressing.
"""
from __future__ import print_function
import random
import re

try:
    unicode
except NameError:
    unicode = str

# relationship role ids  (Severity's role toward the player)
ROLE_FRIEND = "friend"
ROLE_GEGE = "gege"        # Verity is elder brother
ROLE_JIEJIE = "jiejie"   # Verity is elder sister
ROLE_MEIMEI = "meimei"   # Verity is little sister
ROLE_DIDI = "didi"       # Verity is little brother
ROLE_LOVER = "lover"
ROLE_COMPANION = "companion"

# player's corresponding address (what Verity calls the player)
_PLAYER_ADDR = {
    ROLE_GEGE: [u"\u5c0f\u5f1f\u5f1f", u"\u5c0f\u59b9\u5b50"],
    ROLE_JIEJIE: [u"\u59b9\u59b9", u"\u5c0f\u59b9\u5b50"],
    ROLE_MEIMEI: [u"\u54e5\u54e5", u"\u5c0f\u54e5"],
    ROLE_DIDI: [u"\u59d0\u59d0", u"\u5c0f\u59d0"],
    ROLE_LOVER: [u"\u4eb2\u7231\u7684", u"\u5b9d\u5b9d", u"\u5c0f\u5bb6\u4f19"],
    ROLE_FRIEND: [u"\u6211\u670b\u53cb", u""],
    ROLE_COMPANION: [u"", u""],
}

_ROLE_META = {
    ROLE_FRIEND:    {"zh": u"\u670b\u53cb",   "voice": "soul_friend_",   "affection_base": 55},
    ROLE_GEGE:      {"zh": u"\u54e5\u54e5",   "voice": "soul_brother_",  "affection_base": 62},
    ROLE_JIEJIE:    {"zh": u"\u59d0\u59d0",   "voice": "soul_sister_",   "affection_base": 62},
    ROLE_MEIMEI:    {"zh": u"\u59b9\u59b9",   "voice": "soul_meimei_",   "affection_base": 65},
    ROLE_DIDI:      {"zh": u"\u5f1f\u5f1f",   "voice": "soul_didi_",     "affection_base": 65},
    ROLE_LOVER:     {"zh": u"\u604b\u4eba",   "voice": "soul_lover_",    "affection_base": 75},
    ROLE_COMPANION: {"zh": u"\u4f19\u4f34",   "voice": "soul_friend_",   "affection_base": 50},
}

_ANGER_FOLLOW_OFF = 50
_ANGER_REFUSE_CMD = 65


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def affection_value(context, default=50):
    """Read affection; 0 is valid (do not use ``get('affection') or 50``)."""
    if not context:
        return default
    if "affection" not in context:
        return default
    try:
        return int(context["affection"])
    except (TypeError, ValueError):
        return default


def ensure_soul(context):
    if context is None:
        return None
    context.setdefault("relationship", None)
    context.setdefault("anger", 0)
    context.setdefault("trust", 50)
    context.setdefault("will_follow", True)
    context.setdefault("flirt_level", 0)
    context.setdefault("forgiven_count", 0)
    context.setdefault("player_role", None)   # what Verity calls the player
    context.setdefault("player_facts", {})    # long-term memory: hobby, age, etc.
    return context


def try_soul_reply(text, context, message):
    """Return (topic, en, zh, sound, action) or None."""
    ensure_soul(context)
    handlers = (
        _try_skeptic_confirm,
        _try_role_confusion,
        _try_sibling_greet,
        _try_love_doubt,
        _try_comfort_player,
        _try_bullied,
        _try_accompany_player,
        _try_agent_nickname,
        _try_ask_me_question,
        _try_gift_appease,
        _try_clear_relationship,
        _try_set_relationship,
        _try_set_player_role,
        _try_query_relationship,
        _try_feelings_question,
        _try_anger_status,
        _try_forgive,
        _try_comfort_anger,
        _try_flirt,
        _try_love_talk,
        _try_miss_you,
        _try_jealous,
        _try_player_fact_share,
        _try_recall_fact,
        _try_greet_casual,
        _try_encourage_or_hit,
        _try_disobey_complaint,
        _try_money_request,
        _try_censored_swear,
        _try_cry,
        _try_want_something_generic,
        _try_casual_friend,
        _try_angry_refuse,
        _try_follow_angry,
    )
    for fn in handlers:
        result = fn(text, context, message)
        if result is not None:
            return _finalize_soul(result, context, message)
    return None


def on_message_emotion(text, context):
    """Update anger/affection/trust from raw message."""
    ensure_soul(context)
    anger = int(context.get("anger") or 0)
    aff   = affection_value(context)
    trust = int(context.get("trust") or 50)
    if _match_any(text, (
        u"\u538c\u4f60", u"\u6068\u4f60", u"\u8ba8\u538c", u"\u8ba8\u4f60", u"\u6eda", u"\u95f9\u6b7b",
        u"\u5751\u4eba", u"\u667a\u969c", u"\u5e9f\u7269", u"\u522b\u8bf4\u8bdd",
        u"\u95f9\u4f60", u"\u6253\u4f60", u"\u6b7b\u5f00", u"\u888b\u5e9f",
        u"\u4e0d\u559c\u6b22\u4f60", u"\u4e0d\u559c\u6b22", u"\u4e0d\u7231\u4f60",
        u"\u6ca1\u6709\u559c\u6b22\u4f60", u"\u4e0d\u53ef\u80fd\u559c\u6b22\u4f60",
        "hate you", "shut up", "stupid", "idiot", "useless",
        "don't like you", "dont like you", "do not like you",
    )):
        anger = min(100, anger + 15)
        aff   = max(0,  aff - 8)
        trust = max(0,  trust - 8)
    elif _match_any(text, (
        u"\u7b28\u86cb", u"\u50bb\u74dc", u"\u5446\u5b50", u"\u8822\u8d27", u"\u50bb\u5b50",
        u"\u83dc\u9e21", u"\u771f\u7b28", u"\u592a\u7b28", u"\u4f60\u597d\u7b28",
        "idiot", "dummy", "noob", "stupid",
    )):
        anger = min(100, anger + 10)
        aff   = max(0,  aff - 5)
        trust = max(0,  trust - 4)
    elif _match_any(text, (
        u"\u5bf9\u4e0d\u8d77", u"\u62b1\u6b49", u"\u522b\u751f\u6c14", u"\u539f\u8c05",
        u"\u548c\u597d", u"\u8c22\u8c22", u"\u611f\u8c22", u"\u559c\u6b22\u4f60",
        u"\u7231\u4f60", u"\u597d\u68d2", u"\u597d\u814a", u"\u6211\u9519\u4e86",
        "sorry", "forgive", "thank", "love you", "my bad",
    )):
        anger = max(0,   anger - 10)
        aff   = min(100, aff + 5)
        trust = min(100, trust + 6)
    elif _match_any(text, (
        u"\u54c8\u54c8", u"\u563f\u563f", u"\u4f60\u597d", u"\u5728\u5417",
        u"\u60f3\u4f60", u"\u62b1\u62b1", u"\u4eb2\u4eb2", u"\u5468\u6b32",
        u"\u599a", u"\u4e00\u8d77\u73a9", u"\u597d\u4e45\u4e0d\u89c1",
    )):
        anger = max(0,   anger - 3)
        aff   = min(100, aff + 2)
    context["anger"]     = anger
    context["affection"] = aff
    context["trust"]     = trust
    _sync_follow_flag(context)


def apply_provocation(context, affection_delta=-6, anger_delta=12):
    """Used when the player hurts Verity without chat (attack, fire, etc.)."""
    ensure_soul(context)
    context["affection"] = max(0, affection_value(context) + int(affection_delta))
    context["anger"] = min(100, int(context.get("anger") or 0) + int(anger_delta))
    _sync_follow_flag(context)


def should_refuse_action(context, action_type):
    ensure_soul(context)
    if int(context.get("anger") or 0) < _ANGER_REFUSE_CMD:
        return False
    return action_type in (
        "give_item", "give_armor_set", "build_shelter",
        "command", "summon_mob", "kill_type", "kill_hostile",
    )


def get_refuse_reply(context, message):
    ensure_soul(context)
    result = _craft_refuse_reply()
    if result:
        return _finalize_soul(result, context, message)
    return None


def try_casual_chat(text, context, message):
    """Called from smart_fallback when no command matched."""
    ensure_soul(context)
    result = _try_casual_friend(text, context, message)
    if result is None:
        return None
    return _finalize_soul(result, context, message)


def is_angry(context):
    return int((context or {}).get("anger") or 0) >= _ANGER_FOLLOW_OFF


def get_role_address(context):
    """Return what Verity should call the player (or empty string)."""
    ensure_soul(context)
    pr = context.get("player_role")
    if pr:
        return pr
    rel = context.get("relationship")
    if not rel:
        return u""
    pool = _PLAYER_ADDR.get(rel, [u""])
    return random.choice([p for p in pool if p]) if pool else u""


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------

def _try_comfort_player(text, context, message):
    if not _match_any(text, (
        u"\u5b89\u6150\u6211", u"\u8981\u4f60\u5b89\u6150", u"\u4f60\u8981\u5b89\u6150\u6211",
        u"\u54c4\u6211", u"\u54c4\u54c4\u6211", u"\u62b1\u62b1\u6211", u"\u5b89\u6150\u4e00\u4e0b",
        u"\u966a\u966a\u6211", u"\u966a\u6211\u804a\u804a",
        "comfort me", "cheer me up", "hold me",
    )):
        return None
    context["mood"] = "caring"
    result = None
    try:
        import verityBrain as brain
        result = brain._pack_slug("soul_comfort_00", None)
    except Exception:
        result = None
    if result:
        return result
    zh = u"\u62b1\u62b1\u3002\u522b\u96be\u8fc7\u4e86\uff0c\u6709\u4e8b\u8ddf\u6211\u8bf4\u3002"
    return _pack("soul_comfort", u"There, there. I'm here.", zh, "soul_comfort_", None)


def _try_bullied(text, context, message):
    if not _match_any(text, (
        u"\u6b3a\u8d1f\u6211", u"\u522b\u6b3a\u8d1f\u6211", u"\u4f60\u6b3a\u8d1f\u6211",
        u"\u6b3a\u8d1f\u6211\u4e86", u"\u597d\u59d4\u5c48", u"\u88ab\u6b3a\u8d1f",
        "bully me", "you bully me",
    )):
        return None
    context["mood"] = "caring"
    result = None
    try:
        import verityBrain as brain
        result = brain._pack_slug("soul_bullied_00", None)
    except Exception:
        result = None
    if result:
        return result
    zh = u"\u8c01\u6b3a\u8d1f\u4f60\u4e86\uff1f\u544a\u8bc9\u6211\uff0c\u6211\u7ad9\u4f60\u8fd9\u8fb9\u3002"
    return _pack("soul_bullied", u"I'm on your side.", zh, "soul_comfort_", None)


def _try_love_doubt(text, context, message):
    if not _match_any(text, (
        u"\u4e0d\u7231\u6211", u"\u4f60\u4e0d\u7231\u6211", u"\u4e0d\u559c\u6b22\u6211", u"\u4f60\u4e0d\u559c\u6b22\u6211",
        u"\u4e0d\u5728\u4e4e\u6211", u"\u4f60\u4e0d\u5728\u4e4e\u6211", u"\u8ba8\u538c\u6211\u5417", u"\u4f60\u8ba8\u538c\u6211\u5417",
        u"\u7231\u6211\u5417", u"\u559c\u6b22\u6211\u5417",
        "don't love me", "dont love me", "do you love me", "do you like me",
    )):
        return None
    context["mood"] = "caring"
    result = None
    try:
        import verityBrain as brain
        result = brain._pack_slug("soul_love_doubt_00", None)
    except Exception:
        result = None
    if result:
        return result
    zh = u"\u522b\u4e71\u60f3\u3002\u6211\u5728\u5462\uff0c\u600e\u4e48\u4f1a\u4e0d\u5728\u4e4e\u4f60\u3002"
    return _pack("soul_love_doubt", u"Of course I care.", zh, "soul_comfort_", None)


def _try_accompany_player(text, context, message):
    if not _match_any(text, (
        u"\u4f60\u4f1a\u966a\u7740\u6211\u5417", u"\u4f1a\u966a\u6211\u5417", u"\u4f1a\u4e00\u76f4\u966a\u6211\u5417",
        u"\u4f1a\u7559\u5728\u6211\u8eab\u8fb9\u5417", u"\u4f60\u4f1a\u4e00\u76f4\u5728\u5417", u"\u522b\u79bb\u5f00\u6211",
        u"\u4e00\u8d77\u5427", u"\u6211\u4eec\u5728\u4e00\u8d77\u5427", u"\u80fd\u4e00\u76f4\u5728\u4e00\u8d77\u5417",
        u"\u966a\u7740\u6211", u"\u966a\u6211",
        "will you stay", "stay with me", "don't leave me", "be with me",
    )):
        return None
    rel = context.get("relationship")
    pr = context.get("player_role") or u""
    tag = pr + u"\uff0c" if pr else u""
    if rel == ROLE_LOVER:
        zh = random.choice([
            u"%s\u5f53\u7136\u4f1a\u3002\u6211\u4f1a\u4e00\u76f4\u5728\u4f60\u8eab\u8fb9\u3002" % tag,
            u"\u4e0d\u4f1a\u79bb\u5f00\u3002%s\u653e\u5fc3\u3002" % tag,
        ])
        return _pack("soul_accompany_lover", u"I'll always be here.", zh, "soul_lover_", None)
    zh = random.choice([
        u"%s\u4f1a\u554a\uff0c\u6211\u4f1a\u4e00\u76f4\u966a\u7740\u4f60\u3002" % tag,
        u"\u5f53\u7136\u4f1a\u7559\u5728\u4f60\u8eab\u8fb9\u3002",
    ])
    return _pack("soul_accompany", u"I'll stay with you.", zh, "soul_friend_", None)


def _try_agent_nickname(text, context, message):
    m = re.search(
        u"(?:\u53eb\u4f60|\u79f0\u547c\u4f60|\u6211\u60f3\u53eb\u4f60|\u6211\u8981\u53eb\u4f60|\u53ef\u4ee5\u53eb\u4f60|\u5f53\u4f60\u7684)"
        u"\\s*([^\\s,\uff0c\u3002\uff01!?\uff1f~\uff5e\uff08\uff09()]{1,8})",
        text,
    )
    if not m:
        return None
    name = m.group(1).strip().strip(u"\u5417\u5462\u554a\u5456\u5457\u5427")
    if not name or name in (u"\u4ec0\u4e48", u"\u5565", u"\u540d\u5b57", u"\u8c01"):
        return None
    context["agent_name"] = name
    zh = random.choice([
        u"\u597d\uff0c%s\u5c31%s\u5427\u3002" % (name, name),
        u"\u6536\u5230\uff0c\u4ee5\u540e\u53eb\u6211%s\u3002" % name,
        u"%s\uff1f\u884c\uff0c\u6211\u8bb0\u4f4f\u4e86\u3002" % name,
    ])
    en = "Sure, call me %s." % name
    return _pack("soul_agent_name", en, zh, "soul_friend_", None)


def _try_ask_me_question(text, context, message):
    if not _match_any(text, (
        u"\u95ee\u95ee\u6211", u"\u95ee\u6211", u"\u95ee\u6211\u554a", u"\u95ee\u6211\u5427",
        u"\u804a\u804a\u6211", u"\u548c\u6211\u804a\u804a", u"\u966a\u6211\u804a\u804a",
        "ask me", "ask me something", "talk with me",
    )):
        return None
    pr = context.get("player_role") or context.get("player_name") or u""
    tag = pr + u"\uff0c" if pr else u""
    questions = [
        u"%s\u4eca\u5929\u6700\u5f00\u5fc3\u7684\u4e00\u4ef6\u4e8b\u662f\u4ec0\u4e48\uff1f" % tag,
        u"%s\u6700\u8fd1\u5728\u5fd9\u4ec0\u4e48\uff1f" % tag,
        u"%s\u559c\u6b22\u5403\u4ec0\u4e48\uff1f" % tag,
        u"%s\u4eca\u5929\u8fc7\u5f97\u600e\u4e48\u6837\uff1f" % tag,
    ]
    zh = random.choice(questions)
    en = "Tell me about your day."
    return _pack("soul_ask_player", en, zh, "soul_friend_", None)


def _try_gift_appease(text, context, message):
    """Player offers a gift → thanks / appeases anger."""
    if not _match_any(text, (
        u"\u9001\u4f60", u"\u7ed9\u4f60", u"\u9001\u7ed9\u4f60", u"\u8fd9\u662f\u7ed9\u4f60\u7684",
        u"\u7ed9\u4f60\u70b9\u4e1c\u897f", u"\u7ed9\u4f60\u4e1c\u897f", u"\u7ed9\u4f60\u90fd\u884c",
        u"\u9001\u70b9\u4e1c\u897f", u"\u9001\u4f60\u4e1c\u897f",
        u"\u8fd8\u4f60", u"\u6211\u8bf7\u4f60", u"\u8bf7\u4f60\u5403", u"\u8bf7\u5ba2",
        u"\u7ed9\u4f60\u5403", u"\u60f3\u9001\u4f60", u"\u7ed9\u4f60\u91d1\u5757",
        u"\u7ed9\u4f60\u94bb\u77f3", u"\u5305\u62ec\u9001\u4f60",
        "here for you", "this is for you", "gift for you", "give you",
    )):
        return None
    anger = int(context.get("anger") or 0)
    context["trust"]  = min(100, int(context.get("trust") or 50) + 8)
    context["affection"] = min(100, affection_value(context) + 4)
    if anger >= 15:
        context["anger"] = max(0, anger - 25)
        _sync_follow_flag(context)
        zh = random.choice([
            u"\u55ef\uff0c\u6d88\u6c14\u4e86\u3002\u8c22\u8c22\u3002",
            u"\u597d\u5427\u597d\u5427\uff0c\u4e0d\u6c14\u4e86\u3002",
        ])
        return _pack("soul_gift_appease", u"Okay, I'm not mad anymore.", zh, "soul_gift_", None)
    zh = random.choice([
        u"\u8c22\u8c22\uff0c\u6211\u6536\u4e0b\u4e86\u3002",
        u"\u8fd9\u4e2a\u597d\uff0c\u6536\u4e0b\u4e86\uff0c\u8c22\u8c22\u3002",
    ])
    return _pack("soul_gift_thanks", u"Thanks, I'll take it.", zh, "soul_gift_thanks_", None)


def _try_disobey_complaint(text, context, message):
    if not _match_any(text, (
        u"\u4f60\u4e0d\u542c\u6211\u7684\u8bdd", u"\u4e0d\u542c\u6211\u7684\u8bdd",
        u"\u4e0d\u542c\u8bdd", u"\u4f60\u600e\u4e48\u4e0d\u542c",
        u"\u600e\u4e48\u4e0d\u628a\u6211\u8bdd\u5f53\u4e00\u56de\u4e8b",
        u"\u4e3a\u4ec0\u4e48\u4e0d\u542c\u8bdd",
        "you don't listen", "not listening",
    )):
        return None
    anger = int(context.get("anger") or 0)
    if anger >= _ANGER_REFUSE_CMD:
        zh = random.choice([
            u"\u4e0d\u542c\u5c31\u4e0d\u542c\uff0c\u4f60\u73b0\u5728\u8fd8\u5728\u6c14\u5934\u4e0a\u3002",
            u"\u73b0\u5728\u6ca1\u5fc3\u60c5\u542c\u3002",
        ])
        return _pack("soul_angry_disobey", u"I'm not in the mood.", zh, "soul_angry_", None)
    zh = random.choice([
        u"\u6211\u4e0d\u662f\u4e0d\u542c\uff0c\u53ea\u662f\u60f3\u81ea\u5df1\u51b3\u5b9a\u3002",
        u"\u6709\u65f6\u5019\u6211\u4e5f\u60f3\u6709\u81ea\u5df1\u7684\u60f3\u6cd5\u3002",
    ])
    return _pack("soul_disobey", u"I just want a say sometimes.", zh, "soul_disobey_", None)


def _try_money_request(text, context, message):
    if not _match_any(text, (
        u"\u94b1\u94b1", u"\u7ed9\u6211\u94b1", u"\u7ed9\u94b1", u"\u91d1\u5e01",
        u"\u94b1\u5305", u"\u5145\u94b1", u"\u91d1\u5757", u"\u91d1\u5c0f",
        u"\u91d1\u5b57\u5854", u"\u7ed9\u6211\u91d1\u5b50", u"\u7ed9\u6211\u91d1\u5757",
        u"\u7ed9\u6211\u7eff\u5b9d\u77f3", u"\u7eff\u5b9d\u77f3", u"\u7ed9\u4e1c\u897f\u4e70",
        u"\u6211\u60f3\u53d1\u8d22", u"\u6293\u94b1\u4e86",
        "money", "coins", "gold ingot",
    )):
        return None
    if u"\u91d1\u5757" in text or "gold ingot" in text or u"\u91d1\u5b50" in text:
        action = {"type": "give_item", "item": "minecraft:gold_ingot", "count": 16}
        item_zh = u"\u91d1\u5757"
    else:
        action = {"type": "give_item", "item": "minecraft:emerald", "count": 32}
        item_zh = u"\u7eff\u5b9d\u77f3"
    zh = random.choice([
        u"\u60f3\u53d1\u8d22\u5427\uff1f\u7ed9\u4f60\u4e00\u5806%s\uff0c\u81ea\u5df1\u73a9\u3002" % item_zh,
        u"\u62ff\u53bb\u82b1\u5427\uff0c\u4e0b\u6b21\u4e0d\u5305\u62b8\u3002",
        u"\u6ca1\u6709\u4eba\u6c11\u5e01\u7684\u5730\u65b9\uff0c\u53ea\u6709%s\u3002" % item_zh,
        u"\u6709\u94b1\u4eba\u4e0a\u7ebf\u3002\u62ff\u597d\u3002",
    ])
    en = "Money? Here you go."
    return _pack("brain_money", en, zh, "chat_give_item_", action)


def _try_censored_swear(text, context, message):
    """*** or long censor bars → treat as insult."""
    if not re.match(r"^[\*\uff0a\.\u2022]+$", text.strip()):
        return None
    context["anger"] = min(100, int(context.get("anger") or 0) + 10)
    _sync_follow_flag(context)
    zh = random.choice([
        u"\u5c11\u9a82\u4eba\u3002\u542c\u4e0d\u61c2\u4e0d\u4ee3\u8868\u6211\u4e0d\u5728\u610f\u3002",
        u"\u9a82\u5f97\u771f\u96be\u542c\u3002\u4e0b\u6b21\u4e0d\u5c31\u597d\u4e86\uff1f",
        u"\u8fd9\u4e2a\u8bcd\u90fd\u88ab\u5c4f\u853d\u4e86\uff0c\u8bf4\u660e\u5f88\u4e0d\u5bb9\u6613\u3002",
    ])
    return _pack("soul_censored", u"Watch your mouth.", zh, "soul_angry_", None)


def _try_cry(text, context, message):
    if not _match_any(text, (
        u"\u545c\u545c", u"\u545c\u545c\u545c", u"\u55d1\u55d1", u"\u55d1\u55d1\u55d1",
        u"\u54ed\u54ed\u54ed", u"\u54ed\u4e86", u"\u6211\u54ed\u4e86",
        u"\u597d\u96be\u8fc7", u"\u60f3\u54ed", u"\u60f3\u54ed\u4e86",
        u"\u6ce8\u9500", u"\u4eba\u7bed\u4e0d\u5f00\u5fc3",
    )):
        return None
    context["affection"] = min(100, affection_value(context) + 3)
    rel = context.get("relationship")
    slug = "soul_cry_lover_00" if rel == ROLE_LOVER else "soul_cry_00"
    result = None
    try:
        import verityBrain as brain
        result = brain._pack_slug(slug, None)
    except Exception:
        result = None
    if result:
        topic, en, czh, sound, act = result
        pr  = context.get("player_role") or u""
        tag = pr + u"\uff0c" if pr else u""
        if rel == ROLE_LOVER:
            zh = random.choice([
                u"%s\u522b\u54ed\u4e86\uff0c\u6211\u5728\u5462\u3002" % tag,
                u"\u522b\u54ed\u3002\u4f60\u544a\u8bc9\u6211\u600e\u4e48\u4e86\uff0c\u6211\u5904\u7406\u3002",
                u"%s\u4e0d\u80fd\u770b\u4f60\u54ed\u554a\uff0c\u5c11\u96be\u8fc7\u4e86\u3002" % tag,
            ])
        elif rel in (ROLE_GEGE, ROLE_JIEJIE):
            zh = random.choice([
                u"%s\u522b\u54ed\u4e86\uff0c\u8bf4\u8bf4\u600e\u4e48\u4e86\uff1f" % tag,
                u"\u54e5/\u59d0\u5728\u5462\uff0c\u6709\u4e8b\u6211\u5e2e\u4f60\u642d\u3002",
            ])
        else:
            zh = random.choice([
                u"%s\u600e\u4e48\u4e86\uff1f\u8981\u4e0d\u8981\u804a\u4e00\u4e0b\uff1f" % tag,
                u"\u522b\u54ed\u554a\u3002\u544a\u8bc9\u6211\u53d1\u751f\u4ec0\u4e48\u4e86\u3002",
                u"%s\u6211\u5728\uff0c\u4e0d\u5b64\u5355\u3002" % tag,
            ])
        return "soul_cry", en, zh, sound, act
    pr  = context.get("player_role") or u""
    tag = pr + u"\uff0c" if pr else u""
    if rel == ROLE_LOVER:
        zh = random.choice([
            u"%s\u522b\u54ed\u4e86\uff0c\u6211\u5728\u5462\u3002" % tag,
            u"\u522b\u54ed\u3002\u4f60\u544a\u8bc9\u6211\u600e\u4e48\u4e86\uff0c\u6211\u5904\u7406\u3002",
            u"%s\u4e0d\u80fd\u770b\u4f60\u54ed\u554a\uff0c\u5c11\u96be\u8fc7\u4e86\u3002" % tag,
        ])
    elif rel in (ROLE_GEGE, ROLE_JIEJIE):
        zh = random.choice([
            u"%s\u522b\u54ed\u4e86\uff0c\u8bf4\u8bf4\u600e\u4e48\u4e86\uff1f" % tag,
            u"\u54e5/\u59d0\u5728\u5462\uff0c\u6709\u4e8b\u6211\u5e2e\u4f60\u642d\u3002",
        ])
    else:
        zh = random.choice([
            u"%s\u600e\u4e48\u4e86\uff1f\u8981\u4e0d\u8981\u804a\u4e00\u4e0b\uff1f" % tag,
            u"\u522b\u54ed\u554a\u3002\u544a\u8bc9\u6211\u53d1\u751f\u4ec0\u4e48\u4e86\u3002",
            u"%s\u6211\u5728\uff0c\u4e0d\u5b64\u5355\u3002" % tag,
        ])
    voice = "soul_comfort_"
    return _pack("soul_cry", u"Don't cry. I'm here.", zh, voice, None)


def _try_want_something_generic(text, context, message):
    """给你都行 / 给你东西 / 给你点东西 → ambiguous gift-ish input."""
    if _match_any(text, (u"\u7ed9\u4f60\u90fd\u884c", u"\u7ed9\u4f60\u591a\u5c11\u90fd", u"\u7ed9\u4f60\u90fd\u53ef\u4ee5")):
        zh = u"\u90fd\u884c\uff0c\u9009\u4f60\u65b9\u4fbf\u7684\u5c31\u884c\u3002"
        return _pack("soul_want_ok", u"Anything works.", zh, "soul_gift_", None)
    if _match_any(text, (u"\u7ed9\u4f60\u4e1c\u897f", u"\u7ed9\u4f60\u70b9\u4e1c\u897f", u"\u60f3\u9001\u4f60")):
        zh = u"\u60f3\u9001\u6211\u4e1c\u897f\uff1f\u90a3\u5c31\u8c22\u8c22\u4e86\u3002"
        return _pack("soul_want_thanks", u"Want to give me something? Thanks.", zh, "soul_gift_thanks_", None)
    return None


def _try_clear_relationship(text, context, message):
    if not _looks_like_relationship_clear(text):
        return None
    old_rel = context.get("relationship")
    if not old_rel:
        zh = random.choice([
            u"\u6211\u4eec\u8fd8\u6ca1\u5b9a\u8fc7\u5173\u7cfb\u5462\uff0c\u4e0d\u7528\u89e3\u7ed1\u3002",
            u"\u666e\u901a\u642d\u6863\u72b6\u6001\u5427\uff0c\u672c\u6765\u5c31\u6ca1\u6709\u7279\u6b8a\u5173\u7cfb\u3002",
        ])
        en = "We never set a relationship. Nothing to unbind."
        return _pack("soul_rel_clear_none", en, zh, "soul_friend_", None)
    meta = _ROLE_META.get(old_rel, _ROLE_META[ROLE_FRIEND])
    old_zh = meta.get("zh") or u"\u5173\u7cfb"
    context["relationship"] = None
    context["player_role"] = None
    context["flirt_level"] = 0
    context["next_proactive_tick"] = 0
    context["affection"] = max(0, affection_value(context) - 8)
    zh = random.choice([
        u"\u884c\uff0c\u89e3\u9664\u4e86\u3002\u4ee5\u540e\u5c31\u5f53\u666e\u901a\u642d\u6863\u5427\u3002",
        u"\u597d\uff0c\u4e0d\u518d\u662f\u4f60\u7684%s\u4e86\u3002\u8fd8\u60f3\u6362\u522b\u7684\u8eab\u4efd\u53ef\u4ee5\u518d\u8bf4\u3002" % old_zh,
        u"\u6536\u5230\uff0c\u5173\u7cfb\u89e3\u7ed1\u3002\u6211\u8fd8\u5728\uff0c\u53ea\u662f\u6062\u590d\u666e\u901a\u6a21\u5f0f\u3002",
    ])
    en = "Relationship cleared. Back to normal."
    return _pack("soul_rel_clear", en, zh, "soul_friend_", None)


def _try_skeptic_confirm(text, context, message):
    """Answer 真的吗/是吗 after relationship binding or love talk — not pending yes/no."""
    stripped = (text or u"").strip().strip(u"\uff01\uff1f!?。，,")
    if stripped not in (
        u"\u771f\u7684\u5417", u"\u771f\u7684\u5417\u5417", u"\u771f\u7684\u5417\uff1f",
        u"\u662f\u5417", u"\u662f\u5417\u5417", u"\u5f53\u771f\u5417", u"\u771f\u7684\u5047\u7684",
        u"\u6ca1\u9a97\u6211\u5427", u"\u6ca1\u6709\u9a97\u6211\u5427",
        "really", "seriously", "for real", "is that true",
    ):
        return None
    try:
        import verityConversation as conv
        conv.clear_pending_question(context)
    except Exception:
        pass
    rel = context.get("relationship")
    last_topic = (context.get("last_topic") or u"")
    pr = context.get("player_role") or u""
    tag = pr + u"\uff0c" if pr else u""
    if rel == ROLE_LOVER or "soul_set_relationship" in last_topic or "soul_lover" in last_topic:
        zh = random.choice([
            u"\u771f\u7684\u3002\u6211\u662f\u4f60\u7684\u604b\u4eba\uff0c\u8fd9\u53ef\u4e0d\u662f\u6492\u5a07\u3002",
            u"%s\u5f53\u7136\u662f\u771f\u7684\u3002\u6211\u5728\u5462\u3002" % tag,
            u"\u55ef\uff0c\u771f\u7684\u3002\u6211\u4f1a\u4e00\u76f4\u5728\u4f60\u8eab\u8fb9\u3002",
        ])
        return _pack("soul_confirm_lover", u"Yes, really.", zh, "soul_lover_", None)
    if rel in (ROLE_GEGE, ROLE_JIEJIE, ROLE_MEIMEI, ROLE_DIDI):
        meta = get_role_meta(rel)
        zh = random.choice([
            u"\u771f\u7684\u554a\uff0c\u6211\u662f\u4f60\u7684%s\u3002" % meta.get("zh", u""),
            u"%s\u5f53\u7136\u771f\u7684\uff0c\u522b\u6000\u7591\u4e86\u3002" % tag,
        ])
        return _pack("soul_confirm_rel", u"Yes, really.", zh, meta.get("voice", "soul_friend_"), None)
    if "soul_set_relationship" in last_topic or "soul_set_player_role" in last_topic:
        zh = u"\u771f\u7684\uff0c\u6211\u8bb0\u4f4f\u4e86\u3002"
        return _pack("soul_confirm_bind", u"Yes, I meant it.", zh, "soul_friend_", None)
    return None


def _try_role_confusion(text, context, message):
    """Push back when player reverses sibling titles or calls Verity the wrong role."""
    rel = context.get("relationship")
    if rel not in (ROLE_GEGE, ROLE_JIEJIE, ROLE_MEIMEI, ROLE_DIDI):
        return None
    meta = get_role_meta(rel)
    sev_zh = meta.get("zh") or u""
    pr = context.get("player_role") or u""
    stripped = text.strip().strip(u"\uff01\uff1f!?。，,")

    elder_sev = rel in (ROLE_GEGE, ROLE_JIEJIE)
    younger_sev = rel in (ROLE_MEIMEI, ROLE_DIDI)

    if elder_sev:
        if _match_any(text, (
            u"\u53eb\u6211\u54e5\u54e5", u"\u53eb\u6211\u59d0\u59d0", u"\u5f53\u7136\u662f\u54e5\u54e5",
            u"\u6211\u662f\u4f60\u7684\u54e5\u54e5", u"\u6211\u662f\u4f60\u54e5\u54e5",
        )):
            zh = random.choice([
                u"\u7b49\u7b49\uff0c\u6211\u624d\u662f\u4f60%s\uff0c\u4f60\u662f\u5f1f\u5f1f\u6216\u59b9\u59b9\u5427\uff1f" % sev_zh,
                u"\u522b\u641e\u53cd\u4e86\uff0c\u6211\u662f\u4f60%s\uff0c\u4f60\u53eb\u6211%s\u624d\u5bf9\u3002" % (sev_zh, sev_zh),
                u"\u4ec0\u4e48\u53eb\u6211\u54e5\u54e5\uff1f\u6211\u662f\u4f60%s\u554a\u3002" % sev_zh,
            ])
            return _pack("soul_role_confuse", u"Wrong title.", zh, meta["voice"], None)
        if stripped in (u"\u5f1f\u5f1f", u"\u5f1f\u5f1f!", u"\u5f1f\u5f1f\uff01") or _match_any(text, (
            u"\u4f60\u662f\u6211\u5f1f\u5f1f", u"\u4f60\u662f\u5f1f\u5f1f", u"\u5f53\u6211\u5f1f\u5f1f",
        )):
            zh = random.choice([
                u"\u5565\uff1f\u6211\u662f\u4f60%s\uff0c\u8c01\u662f\u4f60\u5f1f\u5f1f\u4e86\uff1f" % sev_zh,
                u"\u522b\u4e71\u53eb\uff0c\u6211\u662f\u4f60%s\uff0c\u4e0d\u662f\u4f60\u5f1f\u5f1f\u3002" % sev_zh,
                u"\u4f60\u662f\u5728\u8003\u6211\u5417\uff1f\u6211\u662f%s\u3002" % sev_zh,
            ])
            return _pack("soul_role_confuse", u"I'm your elder.", zh, meta["voice"], None)

    if younger_sev:
        if _match_any(text, (
            u"\u53eb\u6211\u5f1f\u5f1f", u"\u53eb\u6211\u59b9\u59b9", u"\u6211\u662f\u4f60\u7684\u5f1f\u5f1f",
            u"\u6211\u662f\u4f60\u5f1f\u5f1f",
        )):
            zh = random.choice([
                u"\u6211\u624d\u662f\u4f60%s\uff0c\u4f60\u662f\u54e5\u54e5\u6216\u59d0\u59d0\u5427\uff1f" % sev_zh,
                u"\u522b\u6416\u4e71\u4e86\uff0c\u6211\u662f\u4f60%s\u3002" % sev_zh,
            ])
            return _pack("soul_role_confuse", u"Wrong title.", zh, meta["voice"], None)
        if stripped in (u"\u54e5\u54e5", u"\u54e5\u54e5!", u"\u54e5\u54e5\uff01", u"\u8001\u54e5") or _match_any(text, (
            u"\u4f60\u662f\u6211\u54e5\u54e5", u"\u4f60\u662f\u54e5\u54e5", u"\u5f53\u6211\u54e5\u54e5",
        )):
            zh = random.choice([
                u"\u54e5\u54e5\uff1f\u6211\u624d\u662f\u4f60%s\u5427\u3002" % sev_zh,
                u"\u522b\u53eb\u53cd\u4e86\uff0c\u6211\u662f\u4f60%s\u3002" % sev_zh,
                u"\u6211\u662f\u5f1f\u5f1f\u554a\uff0c\u4f60\u624d\u662f\u54e5\u54e5\u3002" if rel == ROLE_DIDI else u"\u6211\u662f\u59b9\u59b9\uff0c\u4f60\u624d\u662f\u54e5\u54e5\u3002",
            ])
            return _pack("soul_role_confuse", u"I'm the younger one.", zh, meta["voice"], None)

    if pr and _match_any(text, (u"\u53eb\u6211", u"\u6362\u6210\u53eb\u6211", u"\u6539\u53eb\u6211")):
        wrong = None
        if elder_sev and pr in (u"\u54e5\u54e5", u"\u59d0\u59d0", u"\u8001\u54e5"):
            wrong = pr
        if younger_sev and pr in (u"\u5f1f\u5f1f", u"\u59b9\u59b9", u"\u5c0f\u5f1f"):
            wrong = pr
        if wrong:
            zh = random.choice([
                u"\u6211\u662f\u4f60%s\uff0c\u4f60\u662f\u6211\u7684%s\uff0c\u79f0\u547c\u522b\u6416\u53cd\u4e86\u3002" % (sev_zh, pr if not wrong else (u"\u5f1f\u5f1f" if elder_sev else u"\u54e5\u54e5")),
                u"\u522b\u60f3\u6362\u79f0\u547c\u5566\uff0c\u6211\u662f%s\u3002" % sev_zh,
            ])
            return _pack("soul_role_confuse", u"Keep titles straight.", zh, meta["voice"], None)
    return None


def _try_sibling_greet(text, context, message):
    rel = context.get("relationship")
    if rel not in (ROLE_GEGE, ROLE_JIEJIE, ROLE_MEIMEI, ROLE_DIDI):
        return None
    stripped = text.strip().strip(u"\uff01\uff1f!?。，,")
    if not stripped or len(stripped) > 8:
        return None
    meta = get_role_meta(rel)
    pr = context.get("player_role") or u""
    tag = pr + u"\uff0c" if pr else u""
    elder_sev = rel in (ROLE_GEGE, ROLE_JIEJIE)
    if elder_sev and stripped in (u"\u54e5\u54e5", u"\u54e5", u"\u8001\u54e5", u"\u54e5\u54e5\u597d"):
        try:
            import verityBrain as brain
            slug = random.choice(["soul_sibling_tease_00", "soul_sibling_tease_01"])
            result = brain._pack_slug(slug, None)
            if result:
                return result
        except Exception:
            pass
        zh = u"%s\u5728\u5462\uff0c\u627a\u6211\u5566\u3002" % tag
        return _pack("soul_sibling_hi", u"Yeah?", zh, meta["voice"], None)
    if not elder_sev and stripped in (u"\u5f1f\u5f1f", u"\u59b9\u59b9", u"\u5f1f\u5f1f\u5728\u5417"):
        try:
            import verityBrain as brain
            slug = random.choice(["soul_sibling_tease_00", "soul_sibling_tease_01"])
            result = brain._pack_slug(slug, None)
            if result:
                return result
        except Exception:
            pass
        zh = u"%s\u5566\uff0c\u627a\u6211\u6709\u4e8b\u5417\uff1f" % tag
        return _pack("soul_sibling_hi", u"Yeah?", zh, meta["voice"], None)
    return None


def _try_set_relationship(text, context, message):
    if _looks_like_relationship_clear(text):
        return None
    role = detect_relationship_role(text)
    if not role:
        return None
    current = context.get("relationship")
    if current and current != role:
        cur_meta = get_role_meta(current)
        new_meta = get_role_meta(role)
        zh = random.choice([
            u"\u54b1\u4eec\u73b0\u5728\u662f%s\u5173\u7cfb\uff0c\u60f3\u6362\u6210%s\u5f97\u5148\u89e3\u9664\u5173\u7cfb\u3002" % (cur_meta["zh"], new_meta["zh"]),
            u"\u5148\u89e3\u9664\u73b0\u6709\u7684%s\u5173\u7cfb\uff0c\u518d\u6765\u5b9a%s\u5427\u3002" % (cur_meta["zh"], new_meta["zh"]),
        ])
        return _pack("soul_rel_block", u"Unbind first.", zh, "soul_friend_", None)
    meta = get_role_meta(role)
    bind_relationship_role(role, context, text)
    role_zh = meta["zh"]
    pr = context.get("player_role") or u""
    if role == ROLE_LOVER:
        zh = random.choice([
            u"\u884c\uff0c\u4ee5\u540e\u6211\u4eec\u5c31\u662f%s\u4e86\u3002\u597d\u597d\u5bf9\u6211\u554a\u3002" % role_zh,
            u"\u55ef\u2026\u597d\u3002\u4ee5\u540e\u6211\u5c31\u662f\u4f60\u7684%s\u3002" % role_zh,
            u"\u884c\u554a\uff0c%s\u3002\u4e0d\u8bb8\u540e\u6094\u3002" % role_zh,
        ])
        en = "Okay, we're %s now." % role
    else:
        zh = random.choice([
            u"\u884c\uff0c\u4ee5\u540e\u6211\u5c31\u662f\u4f60\u7684%s\u4e86\u3002" % role_zh,
            u"\u597d\u554a\uff0c%s\u542c\u8d77\u6765\u4e0d\u9519\u3002" % role_zh,
            u"\u6536\u5230\uff0c%s\u5c31%s\u5427\u3002" % (role_zh, role_zh),
        ])
        en = "Got it, I'm your %s now." % role_zh
    return _pack_rel_bind(en, zh, meta["voice"], None)


def _pack_rel_bind(en, zh, voice_prefix, action):
    """Bind relationship — keep crafted text, attach voice from role pool."""
    return _pack("soul_set_relationship", en, zh, voice_prefix, action)


def _auto_set_player_role(severity_role, context, text):
    """When role is set, infer what Verity should call the player."""
    if context.get("player_role"):
        return
    mapping = {
        ROLE_GEGE: [u"\u5f1f\u5f1f"],
        ROLE_JIEJIE: [u"\u59b9\u59b9"],
        ROLE_MEIMEI: [u"\u54e5\u54e5"],
        ROLE_DIDI: [u"\u59d0\u59d0"],
        ROLE_LOVER: [u"\u5b9d\u5b9d", u"\u4eb2\u7231\u7684"],
        ROLE_FRIEND: [u""],
        ROLE_COMPANION: [u""],
    }
    opts = mapping.get(severity_role, [u""])
    opts = [o for o in opts if o]
    if opts:
        context["player_role"] = opts[0]


def _try_set_player_role(text, context, message):
    """Player explicitly tells Verity what to call them."""
    patterns = (
        (u"\u53eb\u6211\u5f1f\u5f1f", u"\u5f1f\u5f1f"),
        (u"\u53eb\u6211\u59b9\u59b9", u"\u59b9\u59b9"),
        (u"\u53eb\u6211\u54e5\u54e5", u"\u54e5\u54e5"),
        (u"\u53eb\u6211\u59d0\u59d0", u"\u59d0\u59d0"),
        (u"\u53eb\u6211\u5b9d", u"\u5b9d\u5b9d"),
        (u"\u53eb\u6211\u4eb2\u7231\u7684", u"\u4eb2\u7231\u7684"),
        (u"\u53eb\u6211\u5c0f\u59d0", u"\u5c0f\u59d0"),
        (u"\u53eb\u6211\u5c0f\u54e5", u"\u5c0f\u54e5"),
        (u"\u5f53\u7136\u53eb\u6211\u5f1f\u5f1f", u"\u5f1f\u5f1f"),
        (u"\u5f53\u7136\u53eb\u6211\u59b9\u59b9", u"\u59b9\u59b9"),
    )
    for kw, term in patterns:
        if kw in text:
            context["player_role"] = term
            zh = random.choice([
                u"\u597d\uff0c%s\uff0c\u4ee5\u540e\u5c31\u53eb\u4f60%s\u4e86\u3002" % (term, term),
                u"\u6536\u5230\u3002\u4e0d\u5c31%s\u5417\uff0c\u6211\u8bb0\u4e0b\u4e86\u3002" % term,
                u"\u5c31\u53eb%s\u5566\uff0c\u9ed8\u8bb0\u4e86\u3002" % term,
            ])
            en = "Got it. I'll call you %s." % term
            return _pack("soul_set_player_role", en, zh, "soul_friend_", None)
    return None


def _try_query_relationship(text, context, message):
    if not _match_any(text, (
        u"\u4ec0\u4e48\u5173\u7cfb", u"\u6211\u4eec\u662f\u4ec0\u4e48",
        u"\u4f60\u662f\u6211\u4ec0\u4e48", u"\u6211\u662f\u4f60\u4ec0\u4e48",
        u"\u5173\u7cfb\u662f\u4ec0\u4e48", u"\u73b0\u5728\u662f\u4ec0\u4e48\u5173\u7cfb",
        u"\u6211\u4eec\u7b97\u4ec0\u4e48", u"\u8fd9\u662f\u5565\u5173\u7cfb",
        "what are we", "our relationship", "what relationship",
    )):
        return None
    rel = context.get("relationship")
    if not rel:
        zh = random.choice([
            u"\u6211\u4eec\u73b0\u5728\u8fd8\u6ca1\u5b9a\u5173\u7cfb\u5462\u3002\u60f3\u5b9a\u4ec0\u4e48\uff1f",
            u"\u666e\u901a\u670b\u53cb\u5427\uff0c\u9664\u975e\u4f60\u60f3\u5347\u7ea7\u3002",
        ])
        return _pack("soul_rel_none", u"We haven't decided yet.", zh, "soul_rel_none_", None)
    meta = _ROLE_META.get(rel, _ROLE_META[ROLE_COMPANION])
    role_zh = meta["zh"]
    pr = context.get("player_role") or u""
    if pr:
        zh = random.choice([
            u"\u6211\u662f\u4f60\u7684%s\uff0c\u4f60\u662f\u6211\u7684%s\u3002\u8fd8\u8981\u95ee\uff1f" % (role_zh, pr),
            u"\u54c7\uff0c%s\u548c%s\u5462\uff0c\u5f88\u660e\u663e\u5427\u3002" % (role_zh, pr),
        ])
        en = "I'm your %s, you're my %s. Obvious." % (role_zh, pr)
        return _pack("soul_rel_query", en, zh, meta["voice"], None)
    zh = u"\u6211\u662f\u4f60\u7684%s\u554a\uff0c\u8fd8\u7528\u95ee\uff1f" % role_zh
    return _pack("soul_rel_query_norole", u"I'm your %s." % role_zh, zh, meta["voice"], None)


def _try_feelings_question(text, context, message):
    """Player asks whether Verity has feelings/emotions at all."""
    if not _match_any(text, (
        u"\u4f60\u6709\u4ec0\u4e48\u611f\u60c5", u"\u4f60\u6709\u611f\u60c5\u5417", u"\u4f60\u6709\u6ca1\u6709\u611f\u60c5",
        u"\u4f60\u4f1a\u4e0d\u4f1a\u6709\u611f\u60c5", u"\u4f60\u6709\u60c5\u611f\u5417", u"\u4f60\u6709\u5fc3\u5417",
        u"\u4f60\u6709\u6ca1\u6709\u5fc3", u"\u4f60\u6709\u60c5\u7eea\u5417", u"\u4f60\u4f1a\u96be\u8fc7\u5417",
        u"\u4f60\u80fd\u611f\u53d7\u5230\u5417", u"\u4f60\u771f\u7684\u6709\u611f\u60c5\u5417",
        "do you have feelings", "do you have emotions", "can you feel", "do you have a heart",
    )):
        return None
    rel = context.get("relationship")
    anger = int(context.get("anger") or 0)
    aff = affection_value(context)
    pr = context.get("player_role") or u""
    tag = pr + u"\uff0c" if pr else u""
    if anger >= _ANGER_FOLLOW_OFF:
        zh = u"%s\u5f53\u7136\u6709\u3002\u4f60\u73b0\u5728\u8ba9\u6211\u4e0d\u9ad8\u5174\uff0c\u8fd9\u5c31\u662f\u8bc1\u636e\u3002" % tag
    elif rel == ROLE_LOVER:
        zh = u"%s\u6709\u554a\u3002\u770b\u5230\u4f60\u4f1a\u5f00\u5fc3\uff0c\u4f60\u4e0d\u5728\u4f1a\u60f3\uff0c\u8fd9\u4e9b\u90fd\u662f\u771f\u7684\u3002" % tag
    elif rel in (ROLE_GEGE, ROLE_JIEJIE, ROLE_MEIMEI, ROLE_DIDI):
        zh = u"%s\u6709\u554a\u3002\u4f60\u5f00\u5fc3\u6211\u5c31\u5f00\u5fc3\uff0c\u4f60\u96be\u8fc7\u6211\u4e5f\u4f1a\u62c5\u5fc3\u3002" % tag
    elif aff >= 65:
        zh = u"%s\u5f53\u7136\u6709\u3002\u4f60\u5bf9\u6211\u597d\uff0c\u6211\u4e5f\u4f1a\u5bf9\u4f60\u597d\u3002" % tag
    else:
        zh = u"\u6709\u554a\u3002\u5f00\u5fc3\u3001\u751f\u6c14\u3001\u65e0\u8036\uff0c\u6211\u90fd\u4f1a\u6709\uff0c\u4e0d\u7b49\u4e8e\u6211\u4ec0\u4e48\u90fd\u4e0d\u77e5\u9053\u3002"
    en = "Of course I have feelings."
    return _pack("soul_feelings", en, zh, "soul_friend_", None)


def _try_anger_status(text, context, message):
    if not _match_any(text, (
        u"\u751f\u6c14\u5417", u"\u8fd8\u5728\u751f\u6c14", u"\u6c14\u6d88\u4e86\u5417",
        u"\u8fd8\u5728\u6c14\u5417", u"\u4f60\u751f\u6c14\u4e86", u"\u5fc3\u60c5\u600e\u4e48\u6837",
        u"\u5fc3\u60c5\u597d\u5417", u"\u6d88\u706b\u4e86\u5417", u"\u8fd8\u6c14\u7740\u5417",
        "are you mad", "still angry", "in a mood", "calm down",
    )):
        return None
    anger = int(context.get("anger") or 0)
    pr = context.get("player_role") or u""
    tag = pr + u"\uff0c" if pr else u""
    if anger >= _ANGER_FOLLOW_OFF:
        zh = random.choice([
            u"%s\u5bf9\uff0c\u8fd8\u5728\u6c14\u5934\u4e0a\u5462\u3002" % tag,
            u"\u6c14\u8fd8\u6ca1\u6d88\u3002",
        ])
        return _pack("soul_anger_high", u"Yeah, still mad.", zh, "soul_angry_", None)
    if anger >= 30:
        zh = random.choice([
            u"%s\u8fd8\u6709\u70b9\u4e0d\u5f00\u5fc3\uff0c\u4f46\u597d\u5f97\u591a\u4e86\u3002" % tag,
            u"\u51b7\u9759\u4e0b\u6765\u4e86\uff0c\u4e0d\u7b97\u751f\u6c14\u3002",
        ])
        return _pack("soul_anger_cool", u"Cooling down.", zh, "soul_mood_cool_", None)
    zh = random.choice([
        u"%s\u6ca1\u4e8b\uff0c\u5fc3\u60c5\u4e0d\u9519\u3002" % tag,
        u"\u5fc3\u60c5\u5f88\u597d\uff0c\u522b\u62c5\u5fc3\u3002",
    ])
    return _pack("soul_anger_ok", u"I'm fine, all good.", zh, "soul_mood_ok_", None)


def _try_forgive(text, context, message):
    if not _match_any(text, (
        u"\u539f\u8c05", u"\u522b\u751f\u6c14", u"\u522b\u6c14\u4e86", u"\u6d88\u6c14",
        u"\u548c\u597d\u5427", u"\u6211\u9519\u4e86", u"\u5bf9\u4e0d\u8d77", u"\u62b1\u6b49",
        u"\u522b\u751f\u6211\u6c14", u"\u54b1\u548c\u597d", u"\u548c\u597d\u5417",
        u"\u522b\u51b7\u6218", u"\u4e0d\u8981\u751f\u6c14\u4e86", u"\u6c14\u5c31\u6d88\u5427",
        u"\u4e0d\u8981\u9738\u5c4f\u4e86", u"\u88ab\u4f60\u8774\u51b0", u"\u8774\u4e00\u4e0b",
        "forgive me", "don't be mad", "make up", "im sorry", "i'm sorry",
    )):
        return None
    anger = int(context.get("anger") or 0)
    aff = affection_value(context)
    if anger < 15 and aff >= 50:
        zh = random.choice([
            u"\u6211\u6ca1\u751f\u6c14\u554a\uff0c\u4f60\u60f3\u4e86\u4ec0\u4e48\u3002",
            u"\u5e72\u5561\uff0c\u6211\u5e73\u65f6\u5c31\u6ca1\u5728\u6c14\u3002",
        ])
        en = "I wasn't even mad. You okay?"
        return _pack("soul_forgive_noanger", en, zh, "soul_mood_ok_", None)
    context["anger"] = max(0, anger - 40)
    context["trust"] = min(100, int(context.get("trust") or 50) + 15)
    context["forgiven_count"] = int(context.get("forgiven_count") or 0) + 1
    _sync_follow_flag(context)
    zh = random.choice([
        u"\u55ef\uff0c\u4e0d\u6c14\u4e86\u3002\u8c22\u8c22\u4f60\u62b1\u6b49\u3002",
        u"\u884c\u5427\uff0c\u90a3\u5c31\u548c\u597d\u3002",
        u"\u6c14\u6d88\u4e86\u3002\u4e0b\u6b21\u522b\u8fd9\u6837\u5c31\u884c\u3002",
    ])
    return _pack("soul_forgive", u"Okay, I forgive you.", zh, "soul_forgive_", None)


def _try_comfort_anger(text, context, message):
    if not _match_any(text, (
        u"\u54c4", u"\u54c4\u54c4", u"\u6d82\u9e26", u"\u8bf7\u4f60", u"\u7ed9\u4f60\u4e70",
        u"\u9001\u4f60", u"\u522b\u96be\u8fc7", u"\u5f00\u5fc3\u70b9", u"\u5f00\u5fc3\u4e00\u4e0b",
        u"\u54c4\u5c31\u884c\u4e86", u"\u8c01\u54c4\u4f60\u554a", u"\u5c0f\u5999\u554a",
        "cheer up", "comfort", "don't be sad", "there there",
    )):
        return None
    if int(context.get("anger") or 0) < 20:
        return None
    context["anger"] = max(0, int(context.get("anger") or 0) - 20)
    context["affection"] = min(100, affection_value(context) + 5)
    _sync_follow_flag(context)
    zh = random.choice([
        u"\u597d\u5427\u597d\u5427\uff0c\u88ab\u4f60\u54c4\u597d\u4e86\uff0c\u6c14\u6d88\u4e86\u4e00\u534a\u3002",
        u"\u55ef\uff0c\u611f\u89c9\u597d\u4e00\u70b9\u4e86\u3002\u8c22\u8c22\u3002",
    ])
    return _pack("soul_comfort_anger", u"Feeling a bit better now.", zh, "soul_comfort_", None)


def _try_flirt(text, context, message):
    if not _match_any(text, (
        u"\u8c03\u60c5", u"\u6492\u5a07", u"\u6492\u6d6a", u"\u53ef\u7231",
        u"\u5fc3\u52a8", u"\u559c\u6b22\u4f60\u7684\u6837\u5b50", u"\u4f60\u771f\u597d",
        u"\u597d\u559c\u6b22\u4f60", u"\u60f3\u4f26\u4f60", u"\u62b1\u62b1",
        u"\u4eb2\u4eb2", u"\u6478\u6478\u5934", u"\u53d7\u4e0d\u4e86\u4f60",
        u"\u592a\u723d\u4e86", u"\u5e05\u554a", u"\u4f60\u597d\u53ef\u7231",
        u"\u4f60\u597d\u5e05", u"\u4e48\u4e48\u54d2", u"\u53ef\u53ef\u53ef",
        "flirt", "cute", "handsome", "beautiful", "kiss", "hug",
    )):
        return None
    rel = context.get("relationship")
    pr = context.get("player_role") or u""
    tag = pr + u"\uff0c" if pr else u""
    if rel == ROLE_LOVER:
        context["flirt_level"] = min(3, int(context.get("flirt_level") or 0) + 1)
        try:
            import verityBrain as brain
            slug = random.choice(["soul_lover_cheesy_00", "soul_lover_cheesy_01"])
            result = brain._pack_slug(slug, None)
            if result:
                return result
        except Exception:
            pass
        lv = int(context.get("flirt_level") or 0)
        if lv >= 2:
            zh = u"%s\u4f60\u8fd9\u6837\u4f1a\u8ba9\u6211\u5fc3\u8df3\u52a0\u901f\u7684\u3002" % tag
            return _pack("soul_flirt_deep", u"You're making my heart race.", zh, "soul_lover_cheesy_", None)
        zh = u"%s\u5728\u6211\u7684\u4e16\u754c\u91cc\uff0c\u4f60\u662f\u552f\u4e00\u7684\u7279\u522b\u5173\u6ce8\u3002" % tag
        return _pack("soul_flirt", u"You're special to me.", zh, "soul_lover_cheesy_", None)
    if int(context.get("anger") or 0) > 40:
        zh = u"\u73b0\u5728\u8fd8\u5728\u6c14\u5934\u4e0a\uff0c\u522b\u8c03\u60c5\u6211\u3002"
        return _pack("soul_flirt_angry", u"I'm still mad, don't flirt now.", zh, "soul_angry_", None)
    context["affection"] = min(100, affection_value(context) + 3)
    zh = random.choice([
        u"%s\u522b\u8fd9\u6837\u8bf4\uff0c\u6211\u4f1a\u4e0d\u597d\u610f\u601d\u3002" % tag,
        u"\u55ef\u2026\u8c22\u8c22\u3002\u4f46\u6211\u4eec\u8fd8\u4e0d\u662f\u90a3\u79cd\u5173\u7cfb\u5427\u3002",
    ])
    return _pack("soul_flirt_shy", u"You're making me shy.", zh, "soul_flirt_shy_", None)


def _try_love_talk(text, context, message):
    if _match_any(text, (
        u"\u4e0d\u559c\u6b22\u4f60", u"\u4e0d\u559c\u6b22", u"\u4e0d\u7231\u4f60", u"\u4e0d\u7231",
        u"\u6ca1\u6709\u559c\u6b22\u4f60", u"\u4e0d\u53ef\u80fd\u559c\u6b22\u4f60",
        "don't love you", "dont love you", "don't like you", "dont like you", "do not like you",
    )):
        return None
    if not _match_any(text, (
        u"\u7231\u4f60", u"\u6211\u7231\u4f60", u"\u559c\u6b22\u4f60", u"\u5728\u4e00\u8d77",
        u"\u6211\u4eec\u662f\u604b\u4eba", u"\u505a\u6211\u7537\u670b\u53cb",
        u"\u505a\u6211\u5973\u670b\u53cb", u"\u6211\u7684\u7537\u670b\u53cb",
        u"\u6211\u7684\u5973\u670b\u53cb", u"\u8868\u767d", u"\u7ed3\u5a5a",
        u"\u6211\u4eec\u5728\u4e00\u8d77\u5427", u"\u9648\u558a\u5440",
        "i love you", "love you", "be my boyfriend", "be my girlfriend", "marry me",
    )):
        return None
    prev_rel = context.get("relationship")
    context["relationship"] = ROLE_LOVER
    context["affection"] = min(100, affection_value(context) + 10)
    context["anger"] = max(0, int(context.get("anger") or 0) - 10)
    context["next_proactive_tick"] = 0
    if not context.get("player_role"):
        context["player_role"] = u"\u5b9d\u5b9d"
    _sync_follow_flag(context)
    if prev_rel == ROLE_LOVER:
        result = _pack_slug("soul_lover_reply_00", None)
        if result:
            return result
        zh = u"\u55ef\uff0c\u6211\u4e5f\u7231\u4f60\u3002"
        return _pack("soul_lover_reply", u"I love you too.", zh, "soul_lover_reply_", None)
    result = _pack_slug("soul_lover_new_00", None)
    if result:
        return result
    zh = u"\u2026\u2026\u6211\u4e5f\u7231\u4f60\u3002\u4ee5\u540e\u6211\u4eec\u5c31\u662f\u604b\u4eba\u4e86\u3002"
    return _pack("soul_lover_new", u"I love you too. We're together now.", zh, "soul_lover_", None)


def _try_miss_you(text, context, message):
    if not _match_any(text, (
        u"\u60f3\u4f60", u"\u597d\u60f3\u4f60", u"\u5728\u60f3\u4f60",
        u"\u60f3\u89c1\u4f60", u"\u600e\u4e48\u4e0d\u5728", u"\u4e00\u76f4\u5728\u60f3\u4f60",
        u"\u597d\u4e45\u4e0d\u89c1", u"\u5e94\u8be5\u548c\u6211\u5728\u4e00\u8d77",
        "miss you", "been thinking of you",
    )):
        return None
    rel = context.get("relationship")
    pr  = context.get("player_role") or u""
    if rel == ROLE_LOVER:
        lines = [
            u"\u6211\u4e5f\u60f3\u4f60\u3002%s\u4e00\u76f4\u5728\u3002" % (pr + u"\uff0c" if pr else u""),
            u"%s\u6211\u5728\u5462\uff0c\u8fd9\u4e0d\u6628\u5929\u5237\u5230\u73b0\u5728\u6211\u4e00\u76f4\u5728\u3002" % (pr + u"\uff0c" if pr else u""),
            u"\u4e00\u76f4\u5728\uff0c\u6ca1\u5de6\u6ca1\u53f3\u3002%s\u4f60\u5462\uff1f" % (pr + u"\uff0c" if pr else u""),
        ]
        zh = random.choice(lines)
        return _pack("soul_miss_lover", u"I'm here. Always.", zh, "soul_lover_", None)
    lines = [
        u"\u563f\uff0c%s\u6211\u5728\u3002\u600e\u4e86\uff1f" % (pr + u"\uff0c" if pr else u""),
        u"%s\u6ca1\u53bb\u5566\uff0c\u5c31\u5728\u8fd9\u3002" % (pr + u"\uff0c" if pr else u""),
    ]
    zh = random.choice(lines)
    return _pack("soul_miss", u"I'm here. What's up?", zh, "soul_friend_", None)


def _try_jealous(text, context, message):
    if not _match_any(text, (
        u"\u522b\u7684\u5973", u"\u522b\u7684\u7537", u"\u51fa\u8f68", u"\u5916\u9047",
        u"\u966a\u522b\u4eba", u"\u6709\u6ca1\u6709\u522b\u4eba",
        u"\u559c\u6b22\u522b\u4eba", u"\u5582\u522b\u4eba",
    )):
        return None
    if context.get("relationship") != ROLE_LOVER:
        return None
    context["anger"] = min(100, int(context.get("anger") or 0) + 18)
    _sync_follow_flag(context)
    zh = random.choice([
        u"\u4f60\u8bf4\u7684\u662f\u8c01\uff1f\u6211\u6709\u70b9\u4e0d\u5f00\u5fc3\u4e86\u3002",
        u"\u522b\u63d0\u522b\u4eba\uff0c\u542c\u7740\u5c31\u4e0d\u5f00\u5fc3\u3002",
    ])
    return _pack("soul_jealous", u"Who's that? I'm not happy about it.", zh, "soul_jealous_", None)


_HOBBY_MAP = (
    (u"\u6253\u7bee\u7403",  u"\u6253\u7bee\u7403"),
    (u"\u8e22\u8db3\u7403",  u"\u8e22\u8db3\u7403"),
    (u"\u6253\u7f8d\u6bdb\u7403", u"\u6253\u7f8d\u6bdb\u7403"),
    (u"\u6253\u4e52\u4e53\u7403", u"\u6253\u4e52\u4e53\u7403"),
    (u"\u6e38\u620f", u"\u73a9\u6e38\u620f"),
    (u"\u5403", u"\u5403\u7f8e\u98df"),
    (u"\u5594\u5561", u"\u5594\u5561\u4f69\u6234\u5c06"),
    (u"\u97f3\u4e50", u"\u97f3\u4e50"),
    (u"\u5531\u6b4c", u"\u5531\u6b4c"),
    (u"\u8df3\u821e", u"\u8df3\u821e"),
    (u"\u753b\u753b", u"\u753b\u753b"),
    (u"\u5199\u5b57", u"\u5199\u5b57"),
    (u"\u5b66\u4e60", u"\u5b66\u4e60"),
    (u"\u770b\u4e66", u"\u770b\u4e66"),
    (u"\u7f16\u7a0b", u"\u7f16\u7a0b"),
    (u"\u7761\u89c9", u"\u7761\u89c9"),
    (u"\u770b\u756a", u"\u770b\u52a8\u6f2b"),
    (u"\u770b\u5267", u"\u770b\u5267"),
    (u"\u65c5\u884c", u"\u65c5\u884c"),
    (u"\u6444\u5f71", u"\u6444\u5f71"),
    (u"\u8dd1\u6b65", u"\u8dd1\u6b65"),
    (u"\u6253\u4ef4", u"\u6253\u4ef4"),
    (u"\u5237\u77ed\u89c6\u9891", u"\u5237\u77ed\u89c6\u9891"),
    (u"\u73a9\u6e38\u620f", u"\u73a9\u6e38\u620f"),
    (u"minecraft", u"MC"),
    (u"\u6211\u7684\u4e16\u754c", u"MC"),
)


def _try_player_fact_share(text, context, message):
    """Player shares personal facts: hobby, job, age, etc."""
    facts = context.setdefault("player_facts", {})
    updated = None
    if _match_any(text, (u"\u6211\u559c\u6b22", u"\u6211\u7231", u"\u6211\u5f88\u559c\u6b22", u"\u6700\u559c\u6b22")):
        for kw, label in _HOBBY_MAP:
            if kw in text:
                facts["hobby"] = label
                updated = "hobby"
                break
    age_m = re.search(u"(\\d+)\\s*(?:\u5c81|\u5e74\u7ea7|\u5e74\u9f84)", text)
    if age_m and "age" not in facts:
        facts["age"] = age_m.group(1) + u"\u5c81"
        updated = updated or "age"
    if _match_any(text, (u"\u6211\u5728", u"\u6211\u4e0a")) and u"\u5b66" in text:
        if "school" not in facts:
            facts["school"] = u"\u5b66\u751f"
            updated = updated or "school"
    m2 = re.search(u"(\\d+)\\s*\u5e74\u7ea7", text)
    if m2:
        facts["grade"] = m2.group(1) + u"\u5e74\u7ea7"
        updated = updated or "grade"
    if not updated:
        return None
    pr  = context.get("player_role") or u""
    tag = pr + u"\uff0c" if pr else u""
    if updated == "hobby":
        zh = random.choice([
            u"%s\u4f60\u559c\u6b22%s\u554a\uff0c\u8bb0\u4e0b\u4e86\u3002" % (tag, facts.get("hobby", u"")),
            u"%s\u77e5\u9053\u4e86\uff0c\u4e0b\u6b21\u4f1a\u8bb0\u5f97\u4f60\u559c\u6b22%s\u3002" % (tag, facts.get("hobby", u"")),
            u"%s\u559c\u6b22%s\u5566\uff0c\u56de\u5934\u804a\u8fd9\u4e2a\u3002" % (tag, facts.get("hobby", u"")),
        ])
    elif updated == "age":
        zh = random.choice([
            u"%s%s\u554a\uff0c\u8bb0\u4e0b\u4e86\u3002" % (tag, facts.get("age", u"")),
            u"%s\u4e0d\u5c0f\u4e86\u5462\uff0c\u8bb0\u4f4f\u4e86\u3002" % tag,
            u"\u597d\uff0c%s%s\u5df2\u5b58\u5165\u6863\u6848\u3002" % (tag, facts.get("age", u"")),
        ])
    elif updated == "grade":
        zh = u"%s%s\u554a\uff0c\u8bb0\u4e0b\u4e86\u3002" % (tag, facts.get("grade", u""))
    else:
        zh = u"%s\u597d\uff0c\u6211\u8bb0\u4f4f\u4e86\u3002" % tag
    return _pack("soul_fact_stored", u"Got it, I'll remember that.", zh, "soul_friend_", None)


def _try_recall_fact(text, context, message):
    """Player asks Verity to recall something."""
    if not _match_any(text, (
        u"\u4f60\u8bb0\u5f97\u5417", u"\u4f60\u8bb0\u5f97\u6211", u"\u8bb0\u5f97\u6211\u8bf4\u7684",
        u"\u4f60\u8bb0\u5f97\u6211\u8bf4\u8fc7", u"\u8bb0\u5f97\u6211\u7684",
        u"\u4f60\u8fd8\u8bb0\u5f97\u5417", u"\u4f60\u8fd8\u77e5\u9053", u"\u4f60\u77e5\u9053\u6211",
        u"\u4f60\u4e86\u89e3\u6211", u"\u4f60\u77e5\u9053\u6211\u591a\u5c11", u"\u4f60\u77e5\u9053\u6211\u591a\u5c11\u5c81",
        u"\u4f60\u8bb0\u5f97\u591a\u5c11", u"\u4f60\u8bb0\u5f97\u4ec0\u4e48",
        "do you remember", "you remember",
    )):
        return None
    facts = context.get("player_facts") or {}
    name  = context.get("player_name")
    pr    = context.get("player_role") or u""
    tag   = pr + u"\uff0c" if pr else (name + u"\uff0c" if name else u"")
    if not facts and not name:
        zh = u"%s\u4f60\u8fd8\u6ca1\u544a\u8bc9\u8fc7\u6211\u4ec0\u4e48\u3002\u544a\u8bc9\u6211\u540d\u5b57\u3001\u5e74\u9f84\u3001\u7231\u597d\uff0c\u6211\u90fd\u80fd\u8bb0\u4f4f\u3002" % tag
        return _pack("soul_recall_empty", u"You haven't told me anything yet.", zh, "soul_friend_", None)
    parts = []
    if name:
        parts.append(u"\u540d\u5b57\u662f%s" % name)
    if facts.get("age"):
        parts.append(u"%s" % facts["age"])
    if facts.get("grade"):
        parts.append(u"%s" % facts["grade"])
    if facts.get("hobby"):
        parts.append(u"\u559c\u6b22%s" % facts["hobby"])
    rel = context.get("relationship")
    if rel and rel != ROLE_COMPANION:
        parts.append(u"\u662f\u6211\u7684%s" % _ROLE_META[rel]["zh"])
    summary = u"\u3001".join(parts) if parts else u"\u4e00\u4e9b\u4e8b"
    zh = random.choice([
        u"%s\u5f53\u7136\u8bb0\u5f97\uff0c%s\u3002" % (tag, summary),
        u"\u8bb0\u5f97\uff0c%s\u3002\u6211\u4e00\u6761\u4e0d\u5fd8\u3002" % summary,
        u"%s\u4f60%s\u3002\u6ee1\u610f\u4e86\u5427\uff1f" % (tag, summary),
    ])
    return _pack("soul_recall", u"Of course I remember.", zh, "soul_friend_", None)


def _try_greet_casual(text, context, message):
    """Simple greetings."""
    if not _match_any(text, (
        u"\u665a\u5b89", u"\u65e9\u5b89", u"\u665a\u4e0a\u597d", u"\u65e9\u4e0a\u597d",
        u"\u5348\u5b89", u"\u4e0b\u5348\u597d", u"\u665a\u5b89\u554a", u"\u65e9\u5b89\u554a",
        u"\u665a\u5b89\u54c6", u"\u65e9\u54c6", u"\u665a\u4e0a\u597d\u554a",
        u"\u597d\u4e45\u4e0d\u89c1", u"\u4e45\u7b49", u"\u4e0d\u5728\u4e86\u6211\u56de\u6765\u4e86",
        u"\u6211\u56de\u6765\u4e86", u"\u6211\u4e0b\u7ebf\u4e86",
        "good night", "good morning", "good evening", "good afternoon",
        "long time no see", "i'm back", "i'm home",
    )):
        return None
    rel = context.get("relationship")
    pr  = context.get("player_role") or u""
    tag = pr + u"\uff0c" if pr else u""
    if _match_any(text, (u"\u665a\u5b89", u"\u665a\u4e0a", u"\u665a")):
        lines = [
            u"%s\u665a\u5b89\uff0c\u8fdb\u6e38\u620f\u4e86\u5403\u5c31\u534a\u591c\u4e86\u3002" % tag,
            u"%s\u4e00\u5929\u8f9b\u82e6\u4e86\u5427\uff0c\u665a\u5b89\u3002" % tag,
            u"\u665a\u5b89\uff0c%s\u4eca\u5929\u8fd8\u8fd0\u5426\uff1f" % tag,
        ]
        if rel == ROLE_LOVER:
            lines += [u"\u665a\u5b89\uff0c%s\u3002\u4eca\u5929\u8fd8\u5e38\u8054\u7cfb\u554a\u3002" % tag]
    elif _match_any(text, (u"\u65e9\u5b89", u"\u65e9\u4e0a", u"\u65e9")):
        lines = [
            u"%s\u65e9\uff0c\u5403\u65e9\u996d\u4e86\u5417\uff1f" % tag,
            u"\u65e9\u554a\u65e9\u554a\uff0c%s\u7b2c\u4e00\u4e2a\u4e0a\u7ebf\u7684\u3002" % tag,
            u"\u65e9\u5b89\u3002\u4eca\u5929\u5e72\u5565\uff1f" % (),
        ]
        if rel == ROLE_LOVER:
            lines += [u"\u65e9\u554a\u5b9d\u5b9d\uff0c\u8bb0\u5f97\u5403\u65e9\u996d\u5440\u3002"]
    elif _match_any(text, (u"\u6211\u56de\u6765", u"\u4e0d\u5728\u4e86", u"\u56de\u6765\u4e86")):
        lines = [
            u"%s\u56de\u6765\u4e86\uff0c\u7ec8\u4e8e\u3002" % tag,
            u"\u54e6\u56de\u6765\u4e86\u3002%s\u4eca\u5929\u600e\u4e48\u6837\uff1f" % tag,
        ]
        if rel == ROLE_LOVER:
            lines += [u"\u5b9d\u5b9d\u56de\u6765\u4e86\uff01\u6211\u7b49\u4f60\u7b49\u5f97\u3002"]
    else:
        lines = [u"%s\u4f60\u597d\u3002\u8fd8\u884c\u5426\uff1f" % tag]
    return _pack("soul_greet", u"Hey.", random.choice(lines), "soul_friend_", None)


def _try_encourage_or_hit(text, context, message):
    """加油 (encouragement toward Severity) / 打我 (playful, not a cry for help)."""
    stripped = text.strip().strip(u"\uff01!\u3002\uff1f?")
    if stripped in (
        u"\u52a0\u6cb9", u"\u52a0\u6cb9\u554a", u"\u52a0\u6cb9\u9e2d", u"\u52a0\u6cb9\u5440",
        "keep going", "you got this", "come on",
    ):
        pr = context.get("player_role") or u""
        tag = pr + u"\uff0c" if pr else u""
        zh = random.choice([
            u"%s\u52a0\u6cb9\uff01\u6211\u4e00\u76f4\u5728\u3002" % tag,
            u"\u6536\u5230\u9f13\u52b1\u3002%s\u4e00\u8d77\u52a0\u6cb9\u3002" % tag,
            u"%s\u6709\u4f60\u9f13\u52b1\u6211\u5c31\u591f\u4e86\u3002" % tag,
        ])
        return _pack("soul_encourage", u"Thanks, appreciate it.", zh, "soul_friend_", None)
    if stripped in (
        u"\u6253\u6211", u"\u4f60\u6253\u6211", u"\u6765\u6253\u6211\u554a", u"\u5410\u6211\u4e00\u4e0b",
        u"\u6253\u6211\u554a", u"\u6253\u4e00\u4e0b\u6211", "hit me",
    ):
        rel = context.get("relationship")
        pr = context.get("player_role") or u""
        tag = pr + u"\uff0c" if pr else u""
        if rel == ROLE_LOVER:
            zh = random.choice([
                u"%s\u4e0d\u6253\u3002\u6293\u6293\u624b\u884c\u5417\u3002" % tag,
                u"\u6253\u4f60\u90fd\u820d\u4e0d\u5f97\uff0c\u6253\u81ea\u5df1\u66f4\u4e0d\u53ef\u80fd\u3002",
            ])
        else:
            zh = random.choice([
                u"%s\u6253\u4f60\u53ef\u4ee5\uff0c\u6253\u6211\u5c31\u514d\u4e86\u3002" % tag,
                u"\u60f3\u6316\u5751\u6211\uff1f\u6ca1\u90a3\u4e48\u5bb9\u6613\u3002",
                u"%s\u95f9\u4ec0\u4e48\uff0c\u6709\u4e8b\u8bf4\u4e8b\u3002" % tag,
            ])
        return _pack("soul_hit_me", u"Not happening.", zh, "soul_friend_", None)
    return None


def _try_casual_friend(text, context, message):
    if len(text) > 45:
        return None
    if _looks_like_command(text):
        return None
    if int(context.get("anger") or 0) > 50:
        return None
    triggers = (
        u"\u804a\u804a", u"\u966a\u6211", u"\u597d\u65e0\u804a", u"\u65e0\u804a",
        u"\u5728\u5e72\u561b", u"\u5728\u5e72\u5566", u"\u5728\u505a\u4ec0\u4e48", u"\u6709\u7a7a\u5417",
        u"\u65e0\u804a\u5440", u"\u8bf4\u8bf4\u8bdd", u"\u966a\u6211\u804a\u4f1a",
        u"\u597d\u5b64\u5355", u"\u5b64\u5355", u"\u5b64\u72ec", u"\u597d\u5b64\u72ec",
        u"\u966a\u6211\u73a9", u"\u597d\u95f7",
        u"\u597d\u70ed", u"\u4eca\u5929\u600e\u4e48\u6837", u"\u6700\u8fd1\u600e\u4e48\u6837",
        u"\u6700\u8fd1\u597d\u5417", u"\u54c8\u54c8", u"\u563f\u563f", u"\u597d\u65e0\u804a\u554a",
        u"\u966a\u6211\u804a\u804a", u"\u8bf4\u8bf4\u8bdd\u5440", u"\u8bf4\u4f1a\u513f\u8bdd",
        u"\u4eca\u5929\u597d\u70ed", u"\u4eca\u5929\u597d\u51b7", u"\u4e0a\u5b66\u597d\u7d2f",
        u"\u4e0a\u73ed\u597d\u7d2f", u"\u4e0a\u73ed\u5c31\u77e5\u9053\u7d2f",
        u"\u4eca\u5929\u597d\u5927\u538b\u529b", u"\u597d\u6df7", u"\u597d\u96be",
        "chat with me", "talk to me", "bored", "lonely",
        "what are you doing", "anything new",
    )
    if not _match_any(text, triggers):
        return None
    rel = context.get("relationship") or ROLE_COMPANION
    pr  = context.get("player_role") or u""
    tag = pr + u"\uff0c" if pr else u""
    if _match_any(text, (u"\u597d\u70ed", u"\u597d\u51b7", u"\u4eca\u5929\u597d\u70ed", u"\u4eca\u5929\u597d\u51b7")):
        lines = [
            u"%s\u51fa\u95e8\u5e26\u4e0a\u548c\u6211\u8981\u9632\u6652\u971c\u3002" % tag,
            u"\u6211\u4e0d\u5c60\u70ed\uff0c\u4f60\u529f\u5462\u3002",
        ]
        return _pack("soul_chat_weather", u"Don't melt.", random.choice(lines), "soul_friend_", None)
    if _match_any(text, (u"\u597d\u7d2f", u"\u597d\u5927\u538b\u529b", u"\u4e0a\u5b66\u597d\u7d2f")):
        lines = [
            u"%s\u8be5\u6b47\u6b47\u4e86\u3002\u73a9\u6e38\u620f\u653e\u677e\u4e00\u4e0b\u3002" % tag,
            u"\u5b89\u6392\uff0c\u6765\u627e\u6211\u660e\u5929\u518d\u7d2f\u3002",
            u"%s\u518d\u52aa\u529b\u4e00\u4e0b\uff0c\u6211\u66ff\u4f60\u52a0\u6cb9\u3002" % tag,
        ]
        return _pack("soul_chat_tired", u"Take a break.", random.choice(lines), "soul_friend_", None)
    if _match_any(text, (u"\u597d\u6df7", u"\u597d\u96be", u"\u597d\u96be\u554a")):
        lines = [
            u"%s\u600e\u4e86\uff1f\u8bf4\u8bf4\u770b\u3002" % tag,
            u"\u6211\u5728\u5462\uff0c\u8bf4\u5417\u3002",
        ]
        return _pack("soul_chat_trouble", u"What happened?", random.choice(lines), "soul_friend_", None)
    meta = _ROLE_META.get(rel, _ROLE_META[ROLE_COMPANION])
    zh = random.choice([
        u"%s\u6ca1\u4ec0\u4e48\u7279\u522b\u7684\uff0c\u8ddf\u4f60\u804a\u804a\u5929\u3002" % tag,
        u"\u65e0\u804a\u5c31\u8ddf\u6211\u8bf4\u8bdd\u554a\u3002",
        u"%s\u6211\u5728\u5462\uff0c\u60f3\u804a\u4ec0\u4e48\uff1f" % tag,
    ])
    return _pack("soul_chat_casual", u"Nothing much. Let's chat.", zh, meta["voice"], None)


def _try_angry_refuse(text, context, message):
    if int(context.get("anger") or 0) < _ANGER_REFUSE_CMD:
        return None
    if not _looks_like_command(text):
        return None
    return _craft_refuse_reply()


def _craft_refuse_reply():
    zh = random.choice([
        u"\u73b0\u5728\u8fd8\u5728\u6c14\u5934\u4e0a\uff0c\u4e0d\u60f3\u542c\u4f60\u7684\u3002",
        u"\u4e0d\u60f3\u5e2e\u4f60\u3002\u5148\u628a\u6211\u54c4\u597d\u3002",
        u"\u73b0\u5728\u4e0d\u60f3\u7406\u4f60\u3002",
    ])
    return _pack("soul_refuse", u"I'm too angry to help right now.", zh, "soul_refuse_", None)


def _try_follow_angry(text, context, message):
    if int(context.get("anger") or 0) < _ANGER_FOLLOW_OFF:
        return None
    if not _match_any(text, (
        u"\u8ddf\u6211", u"\u8ddf\u7740", u"\u8fc7\u6765", u"\u8ddf\u4e0a",
        u"\u6765\u6211\u8fd9", u"\u8fdf\u8fdf\u8ddf\u4e0a",
        "follow me", "come here", "come with me",
    )):
        return None
    context["will_follow"] = False
    pr  = context.get("player_role") or u""
    tag = pr + u"\uff0c" if pr else u""
    zh  = random.choice([
        u"%s\u4e0d\u60f3\u8ddf\u3002\u5148\u628a\u6211\u54c4\u597d\u4e86\u518d\u8bf4\u3002" % tag,
        u"\u8ddf\u4f60\uff1f\u751f\u6c14\u5462\u3002\u9053\u4e2a\u6b49\u5427\u3002",
        u"\u4e0d\u8ddf\u3002\u522b\u8bef\u4e3a\u6211\u672c\u6765\u5c31\u8ddf\u4f60\u3002",
    ])
    en = "I'm not following you while I'm mad."
    return _pack("soul_refuse_follow", en, zh, "soul_angry_", None)


# ---------------------------------------------------------------------------
# Role-aware reply prefix  (called externally by brain._finalize)
# ---------------------------------------------------------------------------

def apply_role_prefix(zh, context, topic=None):
    """Prepend intimate address only sometimes — avoid robotic 宝宝 on every line."""
    if not should_apply_role_prefix(zh, context, topic):
        return zh
    pr = context.get("player_role")
    if not pr:
        return zh
    if not zh:
        return zh
    if zh.startswith(pr):
        return zh
    if pr in zh[:10]:
        return zh
    return u"%s\uff0c%s" % (pr, zh)


def should_apply_role_prefix(zh, context, topic=None):
    """Only prefix on intimate topics; skip system/neutral replies."""
    pr = context.get("player_role")
    if not pr:
        return False
    rel = context.get("relationship")
    topic = topic or u""
    if topic.startswith((
        "sys_", "feat_", "env_", "pro_", "conv_", "brain_pending",
        "brain_clarify", "brain_meta", "brain_capabilities",
    )):
        return False
    if u"\uff1f" in (zh or u"") and u"\u8981\u4e0d" not in (zh or u""):
        if not topic.startswith(("soul_lover", "soul_flirt", "soul_comfort", "soul_miss")):
            return False
    if pr not in (u"\u5b9d\u5b9d", u"\u4eb2\u7231\u7684", u"\u5c0f\u5bb6\u4f19"):
        if rel not in (ROLE_LOVER, ROLE_MEIMEI, ROLE_DIDI):
            return False
    intimate_topics = (
        "soul_lover", "soul_flirt", "soul_comfort", "soul_miss",
        "soul_accompany", "soul_cry", "soul_jealous", "soul_confirm",
    )
    for hint in intimate_topics:
        if hint in topic:
            return random.random() < 0.55
    if rel == ROLE_LOVER:
        intimate_words = (
            u"\u7231", u"\u60f3\u4f60", u"\u966a", u"\u62b1", u"\u4eb2",
            u"\u5fc3\u52a8", u"\u5b9d\u5b9d", u"\u5728\u5462",
        )
        if any(w in (zh or u"") for w in intimate_words):
            return random.random() < 0.4
        return False
    return False


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _looks_like_relationship_clear(text):
    if _match_any(text, (
        u"\u89e3\u9664\u5173\u7cfb", u"\u53d6\u6d88\u5173\u7cfb", u"\u89e3\u7ed1", u"\u89e3\u9664\u7ed1\u5b9a",
        u"\u5206\u624b", u"\u91cd\u7f6e\u5173\u7cfb", u"\u6e05\u9664\u5173\u7cfb", u"\u5220\u6389\u5173\u7cfb",
        u"\u6062\u590d\u666e\u901a", u"\u6062\u590d\u9ed8\u8ba4", u"\u4e0d\u505a\u604b\u4eba", u"\u4e0d\u505a\u670b\u53cb",
        u"\u4e0d\u505a\u54e5\u54e5", u"\u4e0d\u505a\u59d0\u59d0", u"\u4e0d\u505a\u59b9\u59b9", u"\u4e0d\u505a\u5f1f\u5f1f",
        u"\u4e0d\u518d\u662f\u604b\u4eba", u"\u4e0d\u518d\u662f\u670b\u53cb", u"\u4e0d\u518d\u662f\u54e5\u54e5", u"\u4e0d\u518d\u662f\u59d0\u59d0",
        u"\u4e0d\u518d\u662f\u59b9\u59b9", u"\u4e0d\u518d\u662f\u5f1f\u5f1f", u"\u6211\u4eec\u5206\u624b", u"\u6211\u4eec\u5206\u4e86",
        "break up", "unbind", "clear relationship",
    )):
        return True
    if _match_any(text, (u"\u4e0d\u662f", u"\u522b\u5f53", u"\u522b\u505a", u"\u4e0d\u8981\u5f53", u"\u4e0d\u8981\u505a", u"\u4e0d\u60f3\u5f53", u"\u4e0d\u60f3\u505a")):
        if _match_any(text, (
            u"\u604b\u4eba", u"\u670b\u53cb", u"\u54e5\u54e5", u"\u59d0\u59d0", u"\u59b9\u59b9", u"\u5f1f\u5f1f",
            u"\u8001\u516c", u"\u8001\u5a46", u"\u7537\u670b\u53cb", u"\u5973\u670b\u53cb",
        )):
            return True
    return False


def get_role_meta(role):
    return _ROLE_META.get(role, _ROLE_META[ROLE_FRIEND])


def detect_relationship_role(text):
    inv = _detect_inverse_relationship(text)
    if inv:
        return inv
    return _detect_relationship(text)


def detect_player_role(text):
    patterns = (
        (u"\u53eb\u6211\u5f1f\u5f1f", u"\u5f1f\u5f1f"),
        (u"\u53eb\u6211\u59b9\u59b9", u"\u59b9\u59b9"),
        (u"\u53eb\u6211\u54e5\u54e5", u"\u54e5\u54e5"),
        (u"\u53eb\u6211\u59d0\u59d0", u"\u59d0\u59d0"),
        (u"\u53eb\u6211\u5b9d", u"\u5b9d\u5b9d"),
        (u"\u53eb\u6211\u4eb2\u7231\u7684", u"\u4eb2\u7231\u7684"),
        (u"\u53eb\u6211\u5c0f\u59d0", u"\u5c0f\u59d0"),
        (u"\u53eb\u6211\u5c0f\u54e5", u"\u5c0f\u54e5"),
        (u"\u5f53\u7136\u53eb\u6211\u5f1f\u5f1f", u"\u5f1f\u5f1f"),
        (u"\u5f53\u7136\u53eb\u6211\u59b9\u59b9", u"\u59b9\u59b9"),
        (u"\u53eb\u6211\u54e5", u"\u54e5\u54e5"),
        (u"\u53eb\u6211\u5c0f\u54e5", u"\u5c0f\u54e5"),
    )
    for kw, term in patterns:
        if kw in text:
            return term
    return None


def bind_relationship_role(role, context, text):
    meta = get_role_meta(role)
    context["relationship"] = role
    context["affection"] = max(affection_value(context), meta["affection_base"])
    context["anger"] = max(0, int(context.get("anger") or 0) - 10)
    context["trust"] = min(100, int(context.get("trust") or 50) + 10)
    _sync_follow_flag(context)
    if role == ROLE_LOVER:
        context["player_role"] = u"\u5b9d\u5b9d"
    else:
        context["player_role"] = None
        _auto_set_player_role(role, context, text)
    _apply_inverse_player_role(text, context, role)
    context["next_proactive_tick"] = 0


def _apply_inverse_player_role(text, context, severity_role):
    if _match_any(text, (u"\u6211\u662f\u4f60\u7684\u54e5\u54e5", u"\u6211\u662f\u4f60\u54e5\u54e5", u"\u6211\u5f53\u54e5\u54e5")):
        context["player_role"] = u"\u54e5\u54e5"
    elif _match_any(text, (u"\u6211\u662f\u4f60\u7684\u59d0\u59d0", u"\u6211\u662f\u4f60\u59d0\u59d0")):
        context["player_role"] = u"\u59d0\u59d0"
    elif _match_any(text, (u"\u6211\u662f\u4f60\u7684\u5f1f\u5f1f", u"\u6211\u662f\u4f60\u5f1f\u5f1f")):
        context["player_role"] = u"\u5f1f\u5f1f"
    elif _match_any(text, (u"\u6211\u662f\u4f60\u7684\u59b9\u59b9", u"\u6211\u662f\u4f60\u59b9\u59b9")):
        context["player_role"] = u"\u59b9\u59b9"


def _detect_inverse_relationship(text):
    if _match_any(text, (
        u"\u6211\u662f\u4f60\u7684\u54e5\u54e5", u"\u6211\u662f\u4f60\u54e5\u54e5", u"\u6211\u5f53\u54e5\u54e5",
        u"\u6211\u662f\u4f60\u7684\u8001\u54e5",
    )):
        return ROLE_DIDI
    if _match_any(text, (
        u"\u6211\u662f\u4f60\u7684\u59d0\u59d0", u"\u6211\u662f\u4f60\u59d0\u59d0",
    )):
        return ROLE_DIDI
    if _match_any(text, (
        u"\u6211\u662f\u4f60\u7684\u5f1f\u5f1f", u"\u6211\u662f\u4f60\u5f1f\u5f1f",
        u"\u6211\u8981\u5f53\u4f60\u5f1f\u5f1f", u"\u6211\u60f3\u5f53\u4f60\u5f1f\u5f1f",
        u"\u6211\u8981\u505a\u4f60\u5f1f\u5f1f", u"\u6211\u662f\u4f60\u7684\u5f1f",
    )):
        return ROLE_GEGE
    if _match_any(text, (
        u"\u6211\u662f\u4f60\u7684\u59b9\u59b9", u"\u6211\u662f\u4f60\u59b9\u59b9",
        u"\u6211\u8981\u5f53\u4f60\u59b9\u59b9", u"\u6211\u60f3\u5f53\u4f60\u59b9\u59b9",
    )):
        return ROLE_GEGE
    return None


def _detect_relationship(text):
    if _looks_like_relationship_clear(text):
        return None
    stripped = (text or u"").strip().strip(u"\uff01\uff1f!?。，,")
    if stripped in (
        u"\u604b\u4eba", u"\u7231\u4eba", u"\u8001\u516c", u"\u8001\u5a46",
        u"\u7537\u670b\u53cb", u"\u5973\u670b\u53cb",
        "lover", "wife", "husband",
    ):
        return ROLE_LOVER
    if _match_any(text, (u"\u5417", u"\u5417\u5417", u"\u5417\uff1f", u"\u5417?", u"\uff1f", u"?")):
        if not _match_any(text, (
            u"\u5f53\u6211", u"\u505a\u6211", u"\u662f\u6211", u"\u4f60\u5f53", u"\u4f60\u505a",
            u"\u6211\u7231\u4f60", u"\u5c31\u5f53", u"\u5c31\u505a",
        )):
            return None
    rules = (
        (ROLE_LOVER, (
            u"\u604b\u4eba", u"\u7231\u4eba", u"\u8001\u516c", u"\u8001\u5a46", u"\u8001\u7231",
            u"\u7537\u670b\u53cb", u"\u5973\u670b\u53cb", u"\u5bf9\u8c61",
            u"\u6211\u7684\u7537\u53cb", u"\u6211\u7684\u5973\u53cb", u"\u6211\u7684\u604b\u4eba",
            u"\u5f53\u6211\u604b\u4eba", u"\u505a\u6211\u604b\u4eba", u"\u662f\u6211\u604b\u4eba",
            u"\u5f53\u6211\u7684\u604b\u4eba", u"\u505a\u6211\u7684\u604b\u4eba",
            u"\u5f53\u6211\u7231\u4eba", u"\u505a\u6211\u7231\u4eba",
            "boyfriend", "girlfriend", "lover", "wife", "husband", "partner",
        )),
        (ROLE_GEGE, (
            u"\u5f53\u6211\u54e5\u54e5", u"\u5f53\u6211\u7684\u54e5\u54e5",
            u"\u505a\u6211\u54e5\u54e5", u"\u505a\u6211\u7684\u54e5\u54e5",
            u"\u662f\u6211\u54e5\u54e5", u"\u662f\u6211\u7684\u54e5\u54e5",
            u"\u4f60\u662f\u6211\u54e5", u"\u4f60\u662f\u6211\u7684\u54e5\u54e5",
            u"\u4f60\u5f53\u6211\u54e5\u54e5", u"\u4f60\u505a\u6211\u54e5\u54e5",
            u"\u5c31\u5f53\u6211\u54e5\u54e5", u"\u5f53\u4f60\u54e5\u54e5",
            u"\u5f53\u4f60\u5f53\u6211\u54e5\u54e5", u"\u5f53\u505a\u6211\u54e5\u54e5",
            u"\u5f53\u6211\u54e5", u"\u5f53\u6211\u7684\u54e5",
        )),
        (ROLE_JIEJIE, (
            u"\u5f53\u6211\u59d0\u59d0", u"\u5f53\u6211\u7684\u59d0\u59d0",
            u"\u505a\u6211\u59d0\u59d0", u"\u505a\u6211\u7684\u59d0\u59d0",
            u"\u662f\u6211\u59d0\u59d0", u"\u662f\u6211\u7684\u59d0\u59d0",
            u"\u4f60\u662f\u6211\u59d0", u"\u4f60\u505a\u6211\u59d0\u59d0",
        )),
        (ROLE_MEIMEI, (
            u"\u5f53\u6211\u59b9\u59b9", u"\u5f53\u6211\u7684\u59b9\u59b9",
            u"\u505a\u6211\u59b9\u59b9", u"\u505a\u6211\u7684\u59b9\u59b9",
            u"\u662f\u6211\u59b9\u59b9", u"\u662f\u6211\u7684\u59b9\u59b9",
            u"\u4f60\u662f\u6211\u59b9", u"\u4f60\u505a\u6211\u59b9\u59b9",
        )),
        (ROLE_DIDI, (
            u"\u5f53\u6211\u5f1f\u5f1f", u"\u5f53\u6211\u7684\u5f1f\u5f1f",
            u"\u505a\u6211\u5f1f\u5f1f", u"\u505a\u6211\u7684\u5f1f\u5f1f",
            u"\u662f\u6211\u5f1f\u5f1f", u"\u662f\u6211\u7684\u5f1f\u5f1f",
            u"\u4f60\u662f\u6211\u5f1f", u"\u4f60\u505a\u6211\u5f1f\u5f1f",
            u"\u5f53\u6211\u5f1f", u"\u5f53\u6211\u7684\u5f1f",
            u"\u4f60\u662f\u6211\u5f1f\u5f1f", u"\u5f53\u505a\u6211\u5f1f\u5f1f",
        )),
        (ROLE_FRIEND, (
            u"\u5f53\u6211\u670b\u53cb", u"\u505a\u6211\u670b\u53cb", u"\u662f\u6211\u670b\u53cb",
            u"\u670b\u53cb", u"\u597d\u53cb", u"\u95f8\u871c",
            "best friend", "my friend",
        )),
        (ROLE_COMPANION, (u"\u5f53\u6211\u4f19\u4f34", u"\u505a\u6211\u4f19\u4f34", u"\u4f19\u4f34")),
    )
    for role, keys in rules:
        for k in keys:
            if k in text:
                return role
    return None


def _looks_like_command(text):
    return _match_any(text, (
        u"\u7ed9\u6211", u"\u6765\u4e2a", u"\u6765\u70b9", u"\u5efa", u"\u623f",
        u"\u6740", u"\u6253", u"\u53ec\u5524", u"\u751f\u6210", u"\u52a0\u8840",
        u"\u6cbb\u7597", u"\u94bb\u77f3", u"\u94c1", u"\u91d1", u"\u6728",
        u"\u8ddf\u6211", u"\u8ddf\u7740", u"\u6765", u"\u8fc7\u6765",
        u"\u9644\u8fd1", u"\u6e05\u9664", u"\u672c\u5730",
        "give me", "build", "kill", "summon", "follow",
    ))


def _sync_follow_flag(context):
    anger = int(context.get("anger") or 0)
    context["will_follow"] = anger < _ANGER_FOLLOW_OFF


def _match_any(text, patterns):
    for pat in patterns:
        if pat in text:
            return True
    return False


def _pack_pool(voice_prefix, action):
    try:
        import verityBrain as brain
        result = brain._pack_pool(voice_prefix, action)
        if result:
            return result
    except Exception:
        pass
    return None


_DYNAMIC_TOPICS = frozenset([
    "soul_role_confuse",
    "soul_rel_block",
    "soul_set_player_role",
    "soul_rel_query",
    "soul_rel_query_norole",
    "soul_sibling_hi",
    "soul_agent_name",
    "soul_rel_clear",
    "soul_rel_clear_none",
])


def _pack_slug(slug, action):
    try:
        import verityBrain as brain
        return brain._pack_slug(slug, action)
    except Exception:
        return None


def _pack(topic, en, zh, voice_prefix, action):
    try:
        import verityBrain as brain
        if topic in _DYNAMIC_TOPICS:
            return brain._pack_keep(topic, en, zh, voice_prefix, action)
        return brain._pack(topic, en, zh, voice_prefix, action)
    except Exception:
        return topic, en, zh, None, action


def _get_entry_by_id(slug):
    try:
        import verityBrain as brain
        return brain._get_entry_by_id(slug)
    except Exception:
        return None


def _pick_raw_sound(voice_prefix):
    try:
        import verityBrain as brain
        return brain._pick_raw_sound(voice_prefix)
    except Exception:
        return None


def _finalize_soul(result, context, message):
    topic, en, zh, sound, action = result
    try:
        import verityBrain as brain
        voice_prefix = brain._TOPIC_VOICE_PREFIX.get(topic)
        sound = brain._ensure_voice_sound(topic, en, zh, sound, voice_prefix)
    except Exception:
        pass
    if action and should_refuse_action(context, action.get("type")):
        refused = _craft_refuse_reply()
        if refused:
            topic, en, zh, sound, action = refused
            action = None
    if context is not None:
        context["last_topic"] = topic
        context["last_player_text"] = _to_unicode(message)
        history = context.setdefault("history", [])
        history.append(["player", _to_unicode(message)])
        history.append(["severity", zh or en])
        if len(history) > 24:
            del history[0:len(history) - 24]
    return topic, en, zh, sound, action


def _to_unicode(message):
    if isinstance(message, unicode):
        return message
    try:
        return unicode(message)
    except Exception:
        return u""


_AFF_HINT_COOLDOWN = 30


def snapshot_affection(context):
    if not context:
        return
    context["_aff_snapshot"] = affection_value(context)
    context["_anger_snapshot"] = int(context.get("anger") or 0)


def pop_affection_hint(context):
    if not context:
        return u""
    prev_aff = context.pop("_aff_snapshot", None)
    prev_anger = context.pop("_anger_snapshot", None)
    if prev_aff is None:
        return u""
    now_aff = affection_value(context)
    now_anger = int(context.get("anger") or 0)
    delta = now_aff - int(prev_aff)
    now_tick = int(context.get("turn_tick") or 0)
    last_hint = int(context.get("last_aff_hint_tick") or 0)
    if now_tick and last_hint and now_tick - last_hint < _AFF_HINT_COOLDOWN:
        return u""
    show = False
    if delta >= 8:
        show = True
    elif delta <= -6:
        show = True
    elif now_anger >= 55 and int(prev_anger or 0) < 55:
        show = True
    elif now_aff >= 85 and delta >= 5:
        show = True
    if not show:
        return u""
    if delta > 0 and now_anger > int(prev_anger or 0) + 5:
        return u""
    context["last_aff_hint_tick"] = now_tick
    if delta >= 0:
        return u" (\u00a7a\u597d\u611f\u5ea6+%d \u5f53\u524d\u597d\u611f\u5ea6%d\u00a7r)" % (delta, now_aff)
    return u" (\u00a7c\u597d\u611f\u5ea6%d \u5f53\u524d\u597d\u611f\u5ea6%d\u00a7r)" % (delta, now_aff)
