# -*- coding: utf-8 -*-
"""Vanilla mob aliases + Bedrock-correct summon identifiers."""
from __future__ import print_function

try:
    unicode
except NameError:
    unicode = str

# Bedrock 1.21 valid entity type strings (NetEase China).
VANILLA_ENTITY_IDS = (
    "allay", "armadillo", "axolotl", "bat", "bee", "blaze", "bogged", "breeze",
    "camel", "cat", "cave_spider", "chicken", "cod", "cow", "creeper",
    "dolphin", "donkey", "drowned", "elder_guardian", "enderman", "endermite",
    "evoker", "fox", "frog", "ghast", "glow_squid", "goat", "guardian",
    "hoglin", "horse", "husk", "iron_golem", "llama", "magma_cube", "mooshroom",
    "mule", "ocelot", "panda", "parrot", "phantom", "pig", "piglin",
    "piglin_brute", "pillager", "polar_bear", "pufferfish", "rabbit", "ravager",
    "salmon", "sheep", "shulker", "silverfish", "skeleton", "skeleton_horse",
    "slime", "sniffer", "snow_golem", "spider", "squid", "stray", "strider",
    "tadpole", "trader_llama", "tropical_fish", "turtle", "vex", "villager_v2",
    "vindicator", "wandering_trader", "warden", "witch", "wither", "wither_skeleton",
    "wolf", "zoglin", "zombie", "zombie_horse", "zombified_piglin",
    "zombie_villager_v2", "ender_dragon", "snail",
)

# Legacy/wrong ids -> correct Bedrock ids.
ID_NORMALIZE = {
    "minecraft:zombie_pigman": "minecraft:zombified_piglin",
    "minecraft:pig_zombie": "minecraft:zombified_piglin",
    "minecraft:pigzombie": "minecraft:zombified_piglin",
    "minecraft:villager": "minecraft:villager_v2",
    "minecraft:zombie_villager": "minecraft:zombie_villager_v2",
    "minecraft:snowman": "minecraft:snow_golem",
    "minecraft:mob": None,
    "minecraft:illusioner": None,
    "minecraft:starfish": None,
    "zombie_pigman": "minecraft:zombified_piglin",
    "pig_zombie": "minecraft:zombified_piglin",
    "pigzombie": "minecraft:zombified_piglin",
    "pigman": "minecraft:zombified_piglin",
    "villager": "minecraft:villager_v2",
    "zombie_villager": "minecraft:zombie_villager_v2",
    "snowman": "minecraft:snow_golem",
    "snow_golem": "minecraft:snow_golem",
    "iron_golem": "minecraft:iron_golem",
    "wither_skull": None,
    "illusioner": None,
    "starfish": None,
}

EXTRA_ALIASES = {
    u"\u76d2\u5b50\u602a": "minecraft:shulker",
    u"\u5e7d\u7075": "minecraft:vex",
    u"\u5c4f\u98ce\u602a\u517d": "minecraft:iron_golem",
    u"\u94c1\u5076\u50cf": "minecraft:iron_golem",
    u"\u5c4f\u98ce": "minecraft:iron_golem",
    u"\u96ea\u5076\u50cf": "minecraft:snow_golem",
    u"\u96ea\u4eba": "minecraft:snow_golem",
    u"\u6d77\u9f99": "minecraft:guardian",
    u"\u5b88\u536b\u8005": "minecraft:guardian",
    u"\u53f2\u83b1\u59c6": "minecraft:shulker",
    u"\u5524\u9b54\u8005": "minecraft:evoker",
    u"\u52ab\u63f4\u517d": "minecraft:ravager",
    u"\u52ab\u63f4\u8005": "minecraft:pillager",
    u"\u536b\u9053\u5175": "minecraft:vindicator",
    u"\u6d78\u6ca1\u8005": "minecraft:drowned",
    u"\u6d78\u6ca5\u8005": "minecraft:drowned",
    u"\u5c38\u58f3": "minecraft:husk",
    u"\u6d41\u7554": "minecraft:stray",
    u"\u706b\u7130\u602a": "minecraft:blaze",
    u"\u8759\u8839\u602a": "minecraft:bat",
    u"\u8717\u725b": "minecraft:snail",
    u"\u8718\u86db": "minecraft:spider",
    u"\u6df1\u6f5c\u8005": "minecraft:warden",
    u"\u8721\u6c64\u602a\u517d": "minecraft:warden",
    u"\u51cb\u96f6": "minecraft:wither",
    u"\u864e\u96f6": "minecraft:wither",
    u"\u6d88\u5931\u68f0": "minecraft:wither",
    u"\u672b\u5f71\u9f99": "minecraft:ender_dragon",
    u"\u6d77\u9f9f": "minecraft:turtle",
    u"\u6d77\u9ca4": "minecraft:dolphin",
    u"\u7f8a\u9a7b\u5546\u4eba": "minecraft:wandering_trader",
    u"\u6d41\u6d6a\u5546\u4eba": "minecraft:wandering_trader",
    u"\u7f8a\u9a7b\u9a7f": "minecraft:trader_llama",
    u"\u5c4b\u5996": "minecraft:phantom",
    u"\u732a": "minecraft:pig",
    u"\u7f8a": "minecraft:sheep",
    u"\u725b": "minecraft:cow",
    u"\u9e21": "minecraft:chicken",
    u"\u50f5\u5c38": "minecraft:zombie",
    u"\u9ab7\u9ac5": "minecraft:skeleton",
    u"\u82e6\u529b\u6016": "minecraft:creeper",
    u"\u672b\u5f71\u4eba": "minecraft:enderman",
    u"\u6751\u6c11": "minecraft:villager_v2",
    u"\u5c4b\u5996\u602a": "minecraft:phantom",
    u"\u7f8a\u9a7b\u5546\u4eba\u7684\u7f8a\u9a7b\u9a7f": "minecraft:trader_llama",
    u"\u9752\u82de\u82b1": "minecraft:axolotl",
    u"\u8702\u871c": "minecraft:bee",
    u"\u9752\u86d9": "minecraft:frog",
    u"\u76d1\u5b88\u8005": "minecraft:warden",
    u"\u7c89\u5a31\u517d": "minecraft:zombified_piglin",
    u"\u50f5\u5c38\u732a\u7075": "minecraft:zombified_piglin",
    "bee": "minecraft:bee",
    "axolotl": "minecraft:axolotl",
    "frog": "minecraft:frog",
    "tadpole": "minecraft:tadpole",
    "allay": "minecraft:allay",
    "camel": "minecraft:camel",
    "warden": "minecraft:warden",
    "wither": "minecraft:wither",
    "dragon": "minecraft:ender_dragon",
    "ender_dragon": "minecraft:ender_dragon",
    "zombie": "minecraft:zombie",
    "skeleton": "minecraft:skeleton",
    "creeper": "minecraft:creeper",
    "pig": "minecraft:pig",
    "cow": "minecraft:cow",
    "sheep": "minecraft:sheep",
    "chicken": "minecraft:chicken",
    "horse": "minecraft:horse",
    "wolf": "minecraft:wolf",
    "cat": "minecraft:cat",
    "spider": "minecraft:spider",
    "enderman": "minecraft:enderman",
    "phantom": "minecraft:phantom",
    "pillager": "minecraft:pillager",
    "ravager": "minecraft:ravager",
    "evoker": "minecraft:evoker",
    "vindicator": "minecraft:vindicator",
    "blaze": "minecraft:blaze",
    "ghast": "minecraft:ghast",
    "guardian": "minecraft:guardian",
    "elder_guardian": "minecraft:elder_guardian",
    "shulker": "minecraft:shulker",
    "slime": "minecraft:slime",
    "magma_cube": "minecraft:magma_cube",
    "drowned": "minecraft:drowned",
    "husk": "minecraft:husk",
    "stray": "minecraft:stray",
    "witch": "minecraft:witch",
    "wandering_trader": "minecraft:wandering_trader",
    "trader_llama": "minecraft:trader_llama",
    "sniffer": "minecraft:sniffer",
    "bogged": "minecraft:bogged",
    "breeze": "minecraft:breeze",
    "armadillo": "minecraft:armadillo",
    "zombified_piglin": "minecraft:zombified_piglin",
    "zombie_pigman": "minecraft:zombified_piglin",
}


def normalize_summon_id(mob_id):
    if not mob_id:
        return None
    if not isinstance(mob_id, unicode):
        try:
            mob_id = unicode(mob_id)
        except Exception:
            return None
    key = mob_id.strip()
    if key in ID_NORMALIZE:
        return ID_NORMALIZE[key]
    low = key.lower()
    if low in ID_NORMALIZE:
        return ID_NORMALIZE[low]
    if not key.startswith("minecraft:"):
        key = "minecraft:" + low.replace(" ", "_").replace("-", "_")
    if key in ID_NORMALIZE:
        return ID_NORMALIZE[key]
    slug = key.replace("minecraft:", "")
    if slug.endswith("s") and slug[:-1] in VANILLA_ENTITY_IDS:
        slug = slug[:-1]
        key = "minecraft:" + slug
    if slug in VANILLA_ENTITY_IDS:
        return key
    return None


def _norm_token(token):
    if token is None:
        return u""
    if not isinstance(token, unicode):
        try:
            token = unicode(token)
        except Exception:
            token = u""
    return token.strip().lower()


def resolve_mob_id(token, mob_map=None):
    raw = token
    if raw is None:
        return None
    if not isinstance(raw, unicode):
        try:
            raw = unicode(raw)
        except Exception:
            return None
    raw = raw.strip()
    if not raw:
        return None
    merged = dict(EXTRA_ALIASES)
    if mob_map:
        merged.update(mob_map)
    if raw in merged:
        return normalize_summon_id(merged[raw])
    low = _norm_token(raw)
    if low in merged:
        return normalize_summon_id(merged[low])
    slug = low.replace(" ", "_").replace("-", "_")
    if slug in merged:
        return normalize_summon_id(merged[slug])
    if slug in ID_NORMALIZE:
        return normalize_summon_id(ID_NORMALIZE[slug])
    if slug.endswith("s") and slug[:-1] in VANILLA_ENTITY_IDS:
        slug = slug[:-1]
    if slug in VANILLA_ENTITY_IDS:
        return normalize_summon_id("minecraft:" + slug)
    return None


def get_all_mob_ids(mob_map=None):
    ids = set()
    for eid in VANILLA_ENTITY_IDS:
        norm = normalize_summon_id("minecraft:" + eid)
        if norm:
            ids.add(norm)
    for val in EXTRA_ALIASES.values():
        norm = normalize_summon_id(val)
        if norm:
            ids.add(norm)
    if mob_map:
        for val in mob_map.values():
            norm = normalize_summon_id(val)
            if norm:
                ids.add(norm)
    return sorted(ids)
