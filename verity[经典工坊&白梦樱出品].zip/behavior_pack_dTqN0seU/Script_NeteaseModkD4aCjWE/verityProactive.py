# -*- coding: utf-8 -*-
"""High-tier proactive pseudo-AI: memory, relationship, environment, mood."""
from __future__ import print_function

import random

try:
    unicode
except NameError:
    unicode = str

TICK_MIN_REL = 600
TICK_MAX_REL = 1200
TICK_MIN_CASUAL = 750
TICK_MAX_CASUAL = 1500
TICK_MIN_STRANGER = 900
TICK_MAX_STRANGER = 1800


def schedule_next(context, now_tick):
    rel = (context or {}).get("relationship")
    aff = int((context or {}).get("affection") or 50)
    if rel:
        lo, hi = TICK_MIN_REL, TICK_MAX_REL
    elif aff >= 45:
        lo, hi = TICK_MIN_CASUAL, TICK_MAX_CASUAL
    else:
        lo, hi = TICK_MIN_STRANGER, TICK_MAX_STRANGER
    context["next_proactive_tick"] = now_tick + random.randint(lo, hi)


def should_speak(context, now_tick):
    if not context:
        return False
    rel = context.get("relationship")
    aff = int(context.get("affection") or 50)
    turns = int(context.get("turn_count") or 0)
    if not rel and aff < 30 and turns < 2:
        return False
    nxt = int(context.get("next_proactive_tick") or 0)
    if nxt <= 0:
        schedule_next(context, now_tick)
        return False
    if now_tick < nxt:
        return False
    return True


def pick_line(context, scene=None):
    """Return (topic, en, zh, sound, action) or None."""
    if not context:
        return None
    if scene and not env_comments_allowed(context):
        scene = dict(scene)
        scene["raining"] = False
        scene["thunder"] = False
    if scene:
        hour = scene.get("hour")
        if hour is not None:
            scene = dict(scene)
            scene["is_night"] = hour >= 19 or hour < 6
            scene["is_day"] = not scene["is_night"]
    if scene and scene.get("raining") and env_comments_allowed(context) and random.random() < 0.35:
        rain_line = _pick_weather_line(context, scene)
        if rain_line:
            return rain_line
    anger = int(context.get("anger") or 0)
    aff = int(context.get("affection") or 50)
    if anger >= 45 or aff <= 38:
        if random.random() < 0.58:
            tease = _pick_angry_tease(context)
            if tease:
                return tease
    elif aff >= 72 and anger < 25:
        if random.random() < 0.42:
            warm = _pick_relationship_line(context) or _pick_warm_friend_line(context)
            if warm:
                return warm
    roll = random.random()
    mem_line = _pick_memory_line(context)
    if mem_line and roll < 0.28:
        return mem_line
    if scene:
        try:
            import verityEnvironment as env
            village_line = env.pick_village_line(context, scene)
            if village_line and roll < 0.72:
                return village_line
            env_line = env.pick_scene_line(context, scene)
            if env_line and roll < 0.62:
                return env_line
        except Exception:
            pass
    behavior_line = _pick_behavior_line(context)
    if behavior_line and roll < 0.78:
        return behavior_line
    rel_line = _pick_relationship_line(context)
    if rel_line:
        return rel_line
    return _pick_pool_line(context)


def env_comments_allowed(context):
    mute = int((context or {}).get("env_comment_mute_until") or 0)
    now = int((context or {}).get("turn_tick") or 0)
    if mute and now and now < mute:
        return False
    return True


def _pick_weather_line(context, scene):
    if not env_comments_allowed(context):
        return None
    tag = (context.get("player_role") or context.get("player_name") or u"")
    tag = tag + u"\uff0c" if tag else u""
    if scene.get("thunder"):
        zh = random.choice([
            u"%s\u6253\u96f7\u4e86\uff0c\u522b\u5728\u5916\u9762\u6d78\u6dcb\u3002" % tag,
            u"%s\u8d76\u7d27\u627e\u4e2a\u5730\u65b9\u953b\u96e8\u3002" % tag,
        ])
        return _pack("pro_thunder", u"Thunderstorm.", zh, "cmd_weather_thunder_")
    if scene.get("raining"):
        zh = random.choice([
            u"%s\u4e0b\u96e8\u4e86\uff0c\u5148\u627e\u4e2a\u5730\u65b9\u953b\u96e8\u5427\u3002" % tag,
            u"%s\u96e8\u592a\u5927\u4e86\uff0c\u8981\u4e0d\u5148\u56de\u5c4b\u5b50\u91cc\uff1f" % tag,
        ])
        return _pack("pro_rain", u"Raining.", zh, "cmd_weather_rain_")
    hour = scene.get("hour")
    if hour is not None and 6 <= hour < 9:
        zh = u"%s\u65e9\u4e0a\u597d\uff0c\u8be5\u8d77\u5e8a\u6536\u62fe\u6536\u62fe\u4e86\u3002" % tag
        return _pack("pro_morning", u"Good morning.", zh, "chat_greeting_")
    if hour is not None and (hour >= 22 or hour < 5):
        zh = u"%s\u592a\u9ed1\u4e86\uff0c\u522b\u5728\u5916\u9762\u6d78\u592a\u4e45\u3002" % tag
        return _pack("pro_dark", u"Too dark.", zh, "pro_dark_")
    return None


def _pick_angry_tease(context):
    pr = context.get("player_role") or u""
    tag = pr + u"\uff0c" if pr else u""
    zh = random.choice([
        u"%s\u4f60\u5728\u778e\u778e\u6211\u5417\uff1f\u8fd8\u662f\u53c8\u60f3\u6c14\u6211\uff1f" % tag,
        u"%s\u522b\u88c5\u65e0\u8f9c\uff0c\u6211\u8fd8\u8bb0\u7740\u5462\u3002" % tag,
        u"%s\u6709\u4e8b\u5feb\u8bf4\uff0c\u6ca1\u4e8b\u522b\u6253\u6270\u6211\u3002" % tag,
        u"%s\u563f\uff0c\u4f60\u4eca\u5929\u770b\u8d77\u6765\u5c31\u5f88\u6b20\u6241\u3002" % tag,
        u"%s\u60f3\u8c03\u620f\u6211\uff1f\u5148\u8bc1\u660e\u4f60\u6709\u672c\u4e8b\u3002" % tag,
    ])
    return _pack("pro_angry_tease", u"Teasing you.", zh, "soul_angry_")


def _pick_warm_friend_line(context):
    pr = context.get("player_role") or context.get("player_name") or u""
    tag = pr + u"\uff0c" if pr else u""
    zh = random.choice([
        u"%s\u6709\u4ec0\u4e48\u597d\u4e8b\u5417\uff1f\u968f\u4fbf\u544a\u8bc9\u6211\u3002" % tag,
        u"%s\u6211\u628a\u4f60\u5f53\u771f\u670b\u53cb\u7684\uff0c\u6709\u4e8b\u968f\u65f6\u8bf4\u3002" % tag,
        u"%s\u522b\u786c\u6491\uff0c\u6211\u5728\u5462\u3002" % tag,
        u"%s\u60f3\u804a\u5929\u8fd8\u662f\u8981\u6211\u5e2e\u5fd9\uff1f\u90fd\u884c\u3002" % tag,
    ])
    return _pack("pro_warm_friend", u"True friend.", zh, "soul_friend_")


def _pick_memory_line(context):
    now = int(context.get("turn_tick") or 0)
    last = int(context.get("last_mem_line_tick") or 0)
    if now and last and now - last < 900:
        return None
    facts = context.get("player_facts") or {}
    name = context.get("player_name")
    pr = context.get("player_role") or u""
    tag = pr + u"\uff0c" if pr else (name + u"\uff0c" if name else u"")
    hobby = facts.get("hobby")
    if hobby:
        zh = random.choice([
            u"%s\u4f60\u4e4b\u524d\u8bf4\u559c\u6b22%s\uff0c\u8fd8\u662f\u5417\uff1f" % (tag, hobby),
            u"%s\u8bb0\u5f97\u4f60\u63d0\u8fc7%s\uff0c\u8981\u4e0d\u518d\u804a\u804a\u8fd9\u4e2a\uff1f" % (tag, hobby),
        ])
        context["last_mem_line_tick"] = now
        return _pack("pro_mem_hobby", u"Remember your hobby?", zh, _voice_for(context, "soul_friend_"))
    age = facts.get("age")
    if age:
        zh = u"%s\u4f60%s\u5c81\u4e86\u5427\uff1f\u6211\u6ca1\u8bb0\u9519\u5427\u3002" % (tag, age)
        context["last_mem_line_tick"] = now
        return _pack("pro_mem_age", u"Remember your age?", zh, _voice_for(context, "soul_friend_"))
    last_action = context.get("last_action") or {}
    if last_action.get("type") == "give_item":
        zh = random.choice([
            u"%s\u4e0a\u6b21\u7684\u7269\u54c1\u8fd8\u591f\u7528\u5417\uff1f\u8981\u4e0d\u518d\u6765\u70b9\uff1f" % tag,
            u"%s\u522b\u628a\u7269\u54c1\u4e00\u4e0b\u5b50\u7528\u5149\u4e86\u554a\u3002" % tag,
        ])
        return _pack("pro_mem_give", u"Need more items?", zh, _voice_for(context, "chat_give_item_"))
    if last_action.get("type") == "build_shelter":
        zh = u"%s\u4e4b\u524d\u90a3\u4e2a\u623f\u5b50\u8fd8\u6ee1\u610f\u5417\uff1f\u8981\u4e0d\u518d\u6539\u6539\uff1f" % tag
        return _pack("pro_mem_build", u"Happy with the build?", zh, _voice_for(context, "brain_build_"))
    return None


def _pick_behavior_line(context):
    pr = context.get("player_role") or u""
    tag = pr + u"\uff0c" if pr else u""
    last_topic = (context.get("last_topic") or u"")
    if "hostile" in last_topic or int(context.get("anger") or 0) >= 20:
        zh = random.choice([
            u"%s\u522b\u751f\u6c14\u4e86\uff0c\u6211\u8fd8\u5728\u5462\u3002" % tag,
            u"%s\u6c14\u6d88\u4e86\u5417\uff1f\u8981\u4e0d\u804a\u804a\uff1f" % tag,
        ])
        return _pack("pro_calm", u"Still mad?", zh, _voice_for(context, "soul_friend_"))
    if int(context.get("trust") or 50) >= 65:
        zh = random.choice([
            u"%s\u4fe1\u4efb\u6211\u5c31\u597d\uff0c\u6709\u4e8b\u968f\u65f6\u8bf4\u3002" % tag,
            u"%s\u6211\u4f1a\u8bb0\u4f4f\u4f60\u8bf4\u7684\u8bdd\u3002" % tag,
        ])
        return _pack("pro_trust", u"I remember you.", zh, _voice_for(context, "soul_friend_"))
    return None


def _pick_relationship_line(context):
    rel = context.get("relationship")
    pr = context.get("player_role") or u""
    tag = pr + u"\uff0c" if pr else u""
    if rel == "lover":
        zh = random.choice([
            u"%s\u5728\u60f3\u4ec0\u4e48\u5462\uff1f" % tag,
            u"%s\u966a\u6211\u804a\u804a\u5427\u3002" % tag,
            u"%s\u6709\u70b9\u60f3\u4f60\u4e86\u3002" % tag,
        ])
        return _pack("pro_lover", u"Thinking of you.", zh, "soul_lover_")
    if rel in ("gege", "jiejie"):
        zh = random.choice([
            u"%s\u6700\u8fd1\u8fd8\u597d\u5417\uff1f\u6709\u4e8b\u627e\u54e5/\u59d0\u3002" % tag,
            u"%s\u522b\u786c\u6491\uff0c\u6709\u6211\u5728\u3002" % tag,
        ])
        voice = "soul_brother_" if rel == "gege" else "soul_sister_"
        return _pack("pro_sibling", u"You okay?", zh, voice)
    if rel in ("meimei", "didi"):
        zh = random.choice([
            u"%s\u522b\u4e71\u8dd1\uff0c\u5371\u9669\u3002" % tag,
            u"%s\u5728\u5e72\u561b\u5462\uff1f" % tag,
        ])
        voice = "soul_meimei_" if rel == "meimei" else "soul_didi_"
        return _pack("pro_younger", u"What are you up to?", zh, voice)
    if rel == "friend":
        zh = random.choice([
            u"%s\u6709\u70b9\u65e0\u804a\uff0c\u966a\u6211\u804a\u804a\uff1f" % tag,
            u"%s\u6700\u8fd1\u6709\u4ec0\u4e48\u597d\u73a9\u7684\u4e8b\u5417\uff1f" % tag,
        ])
        return _pack("pro_friend", u"Bored here.", zh, "soul_friend_")
    aff = int(context.get("affection") or 50)
    if aff >= 40:
        zh = random.choice([
            u"%s\u9700\u8981\u5e2e\u5fd9\u5417\uff1f\u968f\u4fbf\u8bf4\u3002" % tag,
            u"%s\u6211\u5728\u5462\uff0c\u6709\u4e8b\u5c31\u53eb\u6211\u3002" % tag,
        ])
        return _pack("pro_casual", u"Need help?", zh, "soul_friend_")
    return None


def _pick_pool_line(context):
    rel = context.get("relationship") or "companion"
    prefixes = {
        "lover": ("soul_lover_", "soul_flirt_"),
        "gege": ("soul_brother_", "soul_friend_"),
        "jiejie": ("soul_sister_", "soul_friend_"),
        "meimei": ("soul_meimei_", "soul_friend_"),
        "didi": ("soul_didi_", "soul_friend_"),
        "friend": ("soul_friend_", "chat_help_"),
        "companion": ("soul_friend_", "chat_help_", "chat_greeting_"),
    }
    pool_keys = prefixes.get(rel, ("soul_friend_", "chat_help_"))
    try:
        import verityBrain as brain
        for prefix in pool_keys:
            fn = brain._pack_pool_random if prefix in brain._RANDOM_POOL_PREFIXES else brain._pack_pool
            result = fn(prefix, None)
            if result:
                return result
    except Exception:
        pass
    return None


def _voice_for(context, default_prefix):
    rel = (context or {}).get("relationship")
    if rel == "lover" and default_prefix.startswith("soul_"):
        return "soul_lover_"
    if rel == "gege" and default_prefix.startswith("soul_"):
        return "soul_brother_"
    if rel == "jiejie" and default_prefix.startswith("soul_"):
        return "soul_sister_"
    return default_prefix


def _pack(topic, en, zh, voice_prefix):
    try:
        import verityBrain as brain
        return brain._pack_keep(topic, en, zh, voice_prefix, None)
    except Exception:
        return topic, en, zh, None, None
