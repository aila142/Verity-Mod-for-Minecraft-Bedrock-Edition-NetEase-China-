# -*- coding: utf-8 -*-
"""
Verity - client-side system.
"""
from __future__ import print_function

import mod.client.extraClientApi as clientApi

ClientSystem = clientApi.GetClientSystemCls()
CF = clientApi.GetEngineCompFactory()

MOD_NAME = "VerityMod"
SERVER_NAME = "server"
UI_NAMESPACE = MOD_NAME
UI_KEY = "verity_hold_ui"
UI_SCREEN_DEF = "verity_ui.main"
BOX_ENTITY = "verity:xz"
MOB_ENTITY = "verity:mob"
HELD_ITEM = "verity:item_2"
HELD_ITEM_VARIANTS = (
    "verity:item_2",
    "verity:item_3",
    "verity:item_4",
)
MONSTER_HORROR_SOUNDS = (
    "verity.voice.guaiwuchuxianyiyue",
    "verity.voice.guaiwujiao",
)
BGM_TRACKS = (
    "verity.voice.yinyueyi",
    "verity.voice.yiyueer",
)
WAKE_QUERY_NAME = "query.mod.verity_xz_wake"
INTRO_FALL_QUERY = "query.mod.verity_intro_fall"
TALK_QUERY_NAME = "query.mod.verity_talk"
FALL_INTRO_TICKS = 217
BOX_LOOP_SOUND = "verity.voice.huhan"
# call.ogg ~4-5s; add 1s pause after each clip before replay
CALL_DURATION_TICKS = 125
DEFAULT_TALK_TICKS = 70
VOICE_QUEUE_DEFAULT_TICKS = 85
VOICE_QUEUE_MIN_TICKS = 70
VOICE_QUEUE_MAX_TICKS = 140
VOICE_QUEUE_SECS_PER_CHAR = 0.34


class VerityModClientSystem(ClientSystem):
    def __init__(self, namespace, systemName):
        ClientSystem.__init__(self, namespace, systemName)

        self._player_id = clientApi.GetLocalPlayerId()
        self._audio_comp = CF.CreateCustomAudio(self._player_id)
        self._mobile_platform = None
        self._client_tick = 0
        self._active_voice_sound = None
        self._voice_queue = []
        self._voice_queue_busy = False
        self._voice_queue_until = 0

        self._box_loop_entity = None
        self._box_loop_active = False
        self._box_woken = False
        self._next_box_call_tick = 0
        self._mob_id = None
        self._intro_fall_entity = None
        self._intro_fall_end_tick = 0
        self._talk_entity = None
        self._talk_end_tick = 0
        self._hold_ui_node = None
        self._ui_registered = False
        self._bgm_track = None
        self._monster_horror_loop = None
        self._monster_horror_token = 0

        ns = clientApi.GetEngineNamespace()
        sn = clientApi.GetEngineSystemName()
        self.ListenForEvent(ns, sn, "UiInitFinished", self, self._on_ui_init)
        self.ListenForEvent(ns, sn, "AddEntityClientEvent", self, self._on_add_entity)
        self.ListenForEvent(ns, sn, "EntityRemoveEvent", self, self._on_entity_remove)
        self.ListenForEvent(ns, sn, "OnScriptTickClient", self, self._on_script_tick)
        self.ListenForEvent(ns, sn, "OnKeyPressInGame", self, self._on_key_press)
        self.ListenForEvent(ns, sn, "PlayerTryDropItemClientEvent", self, self._on_try_drop_item)
        self.ListenForEvent(ns, sn, "InventoryItemChangedClientEvent", self, self._on_inventory_item_changed_client)
        self.ListenForEvent(MOD_NAME, SERVER_NAME, "VerityMobSpawnEvent", self, self._on_mob_spawn)
        self.ListenForEvent(MOD_NAME, SERVER_NAME, "VerityWakeEvent", self, self._on_wake)
        self.ListenForEvent(MOD_NAME, SERVER_NAME, "VerityPlaySoundEvent", self, self._on_play_sound)
        self.ListenForEvent(MOD_NAME, SERVER_NAME, "VerityBoxSpawnEvent", self, self._on_box_spawn)
        self.ListenForEvent(MOD_NAME, SERVER_NAME, "VerityShowHoldUiEvent", self, self._on_show_hold_ui)
        self.ListenForEvent(MOD_NAME, SERVER_NAME, "VerityHideHoldUiEvent", self, self._on_hide_hold_ui)
        self.ListenForEvent(MOD_NAME, SERVER_NAME, "VerityStopMusicEvent", self, self._on_stop_music)
        self.ListenForEvent(MOD_NAME, SERVER_NAME, "VerityStopMonsterSoundEvent", self, self._on_stop_monster_sound)

        print("Verity client system ready")

    def Destroy(self):
        self._hide_hold_ui()
        self._stop_active_voice()
        self._stop_monster_horror_audio()
        self._stop_box_loop()
        self._clear_talk_anim()
        self._clear_intro_fall()
        ns = clientApi.GetEngineNamespace()
        sn = clientApi.GetEngineSystemName()
        self.UnListenForEvent(ns, sn, "UiInitFinished", self, self._on_ui_init)
        self.UnListenForEvent(ns, sn, "AddEntityClientEvent", self, self._on_add_entity)
        self.UnListenForEvent(ns, sn, "EntityRemoveEvent", self, self._on_entity_remove)
        self.UnListenForEvent(ns, sn, "OnScriptTickClient", self, self._on_script_tick)
        self.UnListenForEvent(ns, sn, "OnKeyPressInGame", self, self._on_key_press)
        self.UnListenForEvent(ns, sn, "PlayerTryDropItemClientEvent", self, self._on_try_drop_item)
        self.UnListenForEvent(ns, sn, "InventoryItemChangedClientEvent", self, self._on_inventory_item_changed_client)
        self.UnListenForEvent(MOD_NAME, SERVER_NAME, "VerityMobSpawnEvent", self, self._on_mob_spawn)
        self.UnListenForEvent(MOD_NAME, SERVER_NAME, "VerityWakeEvent", self, self._on_wake)
        self.UnListenForEvent(MOD_NAME, SERVER_NAME, "VerityPlaySoundEvent", self, self._on_play_sound)
        self.UnListenForEvent(MOD_NAME, SERVER_NAME, "VerityBoxSpawnEvent", self, self._on_box_spawn)
        self.UnListenForEvent(MOD_NAME, SERVER_NAME, "VerityShowHoldUiEvent", self, self._on_show_hold_ui)
        self.UnListenForEvent(MOD_NAME, SERVER_NAME, "VerityHideHoldUiEvent", self, self._on_hide_hold_ui)
        self.UnListenForEvent(MOD_NAME, SERVER_NAME, "VerityStopMusicEvent", self, self._on_stop_music)
        self.UnListenForEvent(MOD_NAME, SERVER_NAME, "VerityStopMonsterSoundEvent", self, self._on_stop_monster_sound)

    def _on_ui_init(self, args=None):
        try:
            self._audio_comp = CF.CreateCustomAudio(self._player_id)
        except Exception:
            pass
        if not self._ui_registered:
            ok = clientApi.RegisterUI(
                UI_NAMESPACE,
                UI_KEY,
                "Script_NeteaseModkD4aCjWE.verityUiScreen.VerityUiScreen",
                UI_SCREEN_DEF,
            )
            self._ui_registered = bool(ok)
            if not ok:
                print("Verity UI register failed")

    def _item_name(self, item_dict):
        if not item_dict:
            return ""
        return item_dict.get("itemName") or item_dict.get("newItemName") or ""

    def _is_valid_verity_item(self, item_dict):
        if self._item_name(item_dict) not in HELD_ITEM_VARIANTS:
            return False
        try:
            return int(item_dict.get("count") or 0) > 0
        except Exception:
            return False

    def _player_holds_severity_item(self):
        if not self._player_id:
            return False
        try:
            item_comp = CF.CreateItem(self._player_id)
            enum_mod = clientApi.GetMinecraftEnum()
            pos_map = enum_mod.ItemPosType
            for pos_type in (pos_map.CARRIED, pos_map.OFFHAND):
                items = item_comp.GetPlayerAllItems(pos_type) or []
                for item in items:
                    if self._is_valid_verity_item(item):
                        return True
        except Exception:
            try:
                item_comp = CF.CreateItem(self._player_id)
                for pos_type in (2, 1):
                    items = item_comp.GetPlayerAllItems(pos_type) or []
                    for item in items:
                        if self._is_valid_verity_item(item):
                            return True
            except Exception:
                pass
        return False

    def _sync_hold_ui(self):
        if self._player_holds_severity_item():
            if not self._hold_ui_node:
                self._show_hold_ui()
        else:
            self._hide_hold_ui()

    def _show_hold_ui(self):
        if self._hold_ui_node:
            return
        if not self._ui_registered:
            self._on_ui_init()
        try:
            node = clientApi.CreateUI(
                UI_NAMESPACE,
                UI_KEY,
                {
                    "client": self,
                    "isHud": 1,
                    "isDesktop": not self._is_mobile(),
                },
            )
        except Exception as exc:
            print("Verity UI create error: %s" % exc)
            node = None
        if not node:
            return
        try:
            node.SetIsHud(1)
        except Exception:
            pass
        self._hold_ui_node = node

    def _hide_hold_ui(self):
        if not self._hold_ui_node:
            return
        try:
            self._hold_ui_node.SetRemove()
        except Exception:
            pass
        self._hold_ui_node = None

    def _on_show_hold_ui(self, args=None):
        if self._player_holds_severity_item():
            self._show_hold_ui()
        else:
            self._hide_hold_ui()

    def _on_hide_hold_ui(self, args=None):
        self._hide_hold_ui()

    def _on_inventory_item_changed_client(self, args=None):
        self._sync_hold_ui()

    def _on_try_drop_item(self, args=None):
        if not args:
            return
        item = args.get("itemDict") or {}
        if not self._is_valid_verity_item(item):
            return
        args["cancel"] = True
        self.NotifyToServer("VerityDropTransformEvent", {"playerId": self._player_id})

    def _on_key_press(self, args=None):
        if not args or not self._hold_ui_node or self._is_mobile():
            return
        if str(args.get("isDown", "")) != "1":
            return
        key = str(args.get("key", ""))
        if key == "82":
            self.NotifyToServer("VerityPlaceEvent", {"playerId": self._player_id})
            self._hide_hold_ui()
        elif key == "71":
            self.NotifyToServer("VerityThrowEvent", {"playerId": self._player_id})
            self._hide_hold_ui()

    def _is_mobile(self):
        if self._mobile_platform is None:
            try:
                self._mobile_platform = clientApi.GetPlatform() in (1, 2)
            except Exception:
                self._mobile_platform = False
        return self._mobile_platform

    def _entity_exists(self, entity_id):
        if not entity_id:
            return False
        try:
            return bool(CF.CreateEngineType(entity_id).GetEngineTypeStr())
        except Exception:
            return False

    def _get_entity_type(self, entity_id):
        if not entity_id:
            return ""
        try:
            return CF.CreateEngineType(entity_id).GetEngineTypeStr() or ""
        except Exception:
            return ""

    def _register_query(self, entity_id, query_name, value):
        try:
            comp = CF.CreateQueryVariable(entity_id)
            comp.Register(query_name, 0.0)
            comp.Set(query_name, float(value))
        except Exception as exc:
            print("Verity query error (%s): %s" % (query_name, exc))

    def _start_intro_fall(self, entity_id):
        if not entity_id:
            return
        self._register_query(entity_id, INTRO_FALL_QUERY, 1.0)
        self._intro_fall_entity = entity_id
        self._intro_fall_end_tick = self._client_tick + FALL_INTRO_TICKS

    def _clear_intro_fall(self):
        if self._intro_fall_entity and self._entity_exists(self._intro_fall_entity):
            self._register_query(self._intro_fall_entity, INTRO_FALL_QUERY, 0.0)
        self._intro_fall_entity = None
        self._intro_fall_end_tick = 0

    def _register_wake_query(self, entity_id, value):
        self._register_query(entity_id, WAKE_QUERY_NAME, value)

    def _reset_box_client_state(self):
        self._box_woken = False
        self._box_loop_active = False
        self._box_loop_entity = None
        self._next_box_call_tick = 0
        self._stop_active_voice()

    def _start_talk_anim(self, entity_id, sound_name, zh_text=None, duration_ticks=None):
        if not entity_id or self._get_entity_type(entity_id) != MOB_ENTITY:
            return
        if duration_ticks is not None:
            duration = int(duration_ticks)
        else:
            duration = self._estimate_voice_ticks(sound_name, zh_text)
        self._register_query(entity_id, TALK_QUERY_NAME, 1.0)
        self._talk_entity = entity_id
        end_tick = self._client_tick + duration
        if end_tick > self._talk_end_tick:
            self._talk_end_tick = end_tick

    def _extend_talk_anim(self, extra_ticks):
        if not self._talk_entity or extra_ticks <= 0:
            return
        end_tick = self._client_tick + int(extra_ticks)
        if end_tick > self._talk_end_tick:
            self._talk_end_tick = end_tick
        self._register_query(self._talk_entity, TALK_QUERY_NAME, 1.0)

    def _clear_talk_anim(self):
        if self._talk_entity and self._entity_exists(self._talk_entity):
            self._register_query(self._talk_entity, TALK_QUERY_NAME, 0.0)
        self._talk_entity = None
        self._talk_end_tick = 0

    def _estimate_voice_ticks(self, sound_name, zh_text=None):
        ticks = VOICE_QUEUE_DEFAULT_TICKS
        if sound_name and "greet" in sound_name:
            ticks = 90
        if zh_text:
            try:
                char_count = len(zh_text)
            except Exception:
                char_count = 0
            if char_count > 0:
                secs = max(1.5, char_count * VOICE_QUEUE_SECS_PER_CHAR)
                ticks = max(ticks, int(secs * 20.0))
        return max(VOICE_QUEUE_MIN_TICKS, min(ticks, VOICE_QUEUE_MAX_TICKS))

    def _talk_anim_entity(self, entity_id=None):
        if entity_id and self._entity_exists(entity_id):
            if self._get_entity_type(entity_id) == MOB_ENTITY:
                return entity_id
        if self._mob_id and self._entity_exists(self._mob_id):
            return self._mob_id
        return None

    def _enqueue_voice(self, sound_name, pos, entity_id, loop, volume, zh_text=None):
        self._voice_queue.append({
            "sound": sound_name,
            "pos": pos,
            "entityId": entity_id,
            "loop": loop,
            "volume": volume,
            "ticks": self._estimate_voice_ticks(sound_name, zh_text),
            "zh": zh_text,
        })

    def _play_voice_now(self, item):
        sound_name = item.get("sound")
        if not sound_name:
            return
        pos = item.get("pos") or (0.0, 0.0, 0.0)
        entity_id = item.get("entityId")
        loop = bool(item.get("loop", False))
        volume = float(item.get("volume", 1.0))
        zh_text = item.get("zh")
        talk_id = self._talk_anim_entity(entity_id)
        self._play_sound(sound_name, pos, entity_id, loop, volume, talk_id, zh_text)
        self._voice_queue_busy = True
        self._voice_queue_until = self._client_tick + int(item.get("ticks") or VOICE_QUEUE_DEFAULT_TICKS)

    def _pump_voice_queue(self):
        if self._voice_queue_busy:
            if self._client_tick < self._voice_queue_until:
                return
            self._voice_queue_busy = False
            self._active_voice_sound = None
        if not self._voice_queue:
            if self._talk_entity and self._client_tick >= self._talk_end_tick:
                self._clear_talk_anim()
            return
        item = self._voice_queue.pop(0)
        self._play_voice_now(item)
        if self._voice_queue:
            self._extend_talk_anim(int(item.get("ticks") or VOICE_QUEUE_DEFAULT_TICKS))

    def _is_monster_horror_sound(self, sound_name):
        if not sound_name:
            return False
        return sound_name in MONSTER_HORROR_SOUNDS

    def _play_monster_horror_loop(self, sound_name, volume=1.0):
        if not sound_name:
            return
        comp = self._audio_comp
        if not comp:
            try:
                self._audio_comp = CF.CreateCustomAudio(self._player_id)
                comp = self._audio_comp
            except Exception:
                return
        if self._monster_horror_loop and self._monster_horror_loop != sound_name:
            try:
                comp.StopCustomMusic(self._monster_horror_loop, 0.15)
            except Exception:
                pass
        try:
            comp.PlayCustomMusic(
                sound_name, (0.0, 0.0, 0.0), volume, 1.0, True, self._player_id
            )
            self._monster_horror_loop = sound_name
        except Exception as exc:
            print("Verity monster horror loop error (%s): %s" % (sound_name, exc))

    def _play_monster_horror_one_shot(self, sound_name, volume=1.0):
        if not sound_name:
            return
        comp = self._audio_comp
        if not comp:
            return
        try:
            comp.PlayCustomMusic(sound_name, (0.0, 0.0, 0.0), volume, 1.0, False, self._player_id)
        except Exception as exc:
            print("Verity monster roar error (%s): %s" % (sound_name, exc))

    def _stop_monster_horror_audio(self):
        comp = self._audio_comp
        if comp:
            if self._monster_horror_loop:
                try:
                    comp.StopCustomMusic(self._monster_horror_loop, 0.05)
                except Exception:
                    pass
            for snd in MONSTER_HORROR_SOUNDS:
                try:
                    comp.StopCustomMusic(snd, 0.05)
                except Exception:
                    pass
        self._monster_horror_loop = None

    def _on_stop_monster_sound(self, args=None):
        self._monster_horror_token = 0
        self._stop_monster_horror_audio()

    def _is_bgm_track(self, sound_name):
        if not sound_name:
            return False
        if sound_name in BGM_TRACKS:
            return True
        return False

    def _play_bgm(self, sound_name, loop=True, volume=1.0):
        if not sound_name:
            return
        comp = self._audio_comp
        if not comp:
            try:
                self._audio_comp = CF.CreateCustomAudio(self._player_id)
                comp = self._audio_comp
            except Exception:
                return
        if self._bgm_track and self._bgm_track != sound_name:
            try:
                comp.StopCustomMusic(self._bgm_track, 0.35)
            except Exception:
                pass
        try:
            comp.PlayGlobalCustomMusic(sound_name, volume, loop)
            self._bgm_track = sound_name
            print("Verity client bgm: %s" % sound_name)
        except Exception as exc:
            print("Verity bgm error (%s): %s" % (sound_name, exc))

    def _stop_bgm(self):
        if not self._bgm_track or not self._audio_comp:
            self._bgm_track = None
            return
        try:
            self._audio_comp.StopCustomMusic(self._bgm_track, 0.5)
        except Exception:
            pass
        self._bgm_track = None

    def _stop_active_voice(self):
        if not self._active_voice_sound or not self._audio_comp:
            self._active_voice_sound = None
            self._clear_talk_anim()
            return
        if self._is_bgm_track(self._active_voice_sound):
            self._active_voice_sound = None
            self._clear_talk_anim()
            return
        if self._is_monster_horror_sound(self._active_voice_sound):
            self._active_voice_sound = None
            self._clear_talk_anim()
            return
        try:
            self._audio_comp.StopCustomMusic(self._active_voice_sound, 0.05)
        except Exception:
            pass
        self._active_voice_sound = None
        self._voice_queue = []
        self._voice_queue_busy = False
        self._voice_queue_until = 0
        self._clear_talk_anim()

    def _play_sound(self, sound_name, pos, entity_id=None, loop=False, volume=1.0, talk_entity_id=None, zh_text=None):
        """Match woodMod client: entity-bound uses (0,0,0) relative coords."""
        if not sound_name:
            return
        comp = self._audio_comp
        if not comp:
            try:
                self._audio_comp = CF.CreateCustomAudio(self._player_id)
                comp = self._audio_comp
            except Exception:
                return
        try:
            if entity_id is None and self._is_mobile():
                entity_id = self._player_id
            if not entity_id and self._mob_id and self._entity_exists(self._mob_id):
                entity_id = self._mob_id
            if entity_id:
                comp.PlayCustomMusic(
                    sound_name, (0.0, 0.0, 0.0), volume, 1.0, loop, entity_id
                )
            else:
                comp.PlayCustomMusic(
                    sound_name, pos, volume, 1.0, loop, None
                )
            if not self._is_bgm_track(sound_name) and not self._is_monster_horror_sound(sound_name):
                self._active_voice_sound = sound_name
            talk_id = self._talk_anim_entity(talk_entity_id)
            if talk_id:
                self._start_talk_anim(talk_id, sound_name, zh_text)
            print("Verity client play: %s" % sound_name)
        except Exception as exc:
            print("Verity play sound error (%s): %s" % (sound_name, exc))

    def _track_box(self, entity_id):
        if not entity_id:
            return
        self._box_loop_entity = entity_id
        self._box_loop_active = True
        self._next_box_call_tick = self._client_tick + 15
        self._register_wake_query(entity_id, 0.0)

    def _stop_box_loop(self):
        self._box_loop_active = False
        self._box_loop_entity = None
        if self._audio_comp:
            try:
                self._audio_comp.StopCustomMusic(BOX_LOOP_SOUND, 0.1)
            except Exception:
                pass

    def _on_add_entity(self, args):
        entity_id = args.get("id")
        type_str = args.get("engineTypeStr") or self._get_entity_type(entity_id)
        if entity_id and type_str == BOX_ENTITY:
            self._reset_box_client_state()
            self._track_box(entity_id)
        elif entity_id and type_str == MOB_ENTITY:
            self._mob_id = entity_id
            # If box was just opened (wake sequence), start fall animation immediately
            # so there's no visible frame before the animation begins
            if self._box_woken and not self._intro_fall_entity:
                self._start_intro_fall(entity_id)
                self._box_woken = False

    def _on_entity_remove(self, args):
        entity_id = args.get("id")
        if not entity_id:
            return
        if entity_id == self._box_loop_entity:
            self._stop_box_loop()
        if entity_id == self._mob_id:
            self._mob_id = None
            self._clear_talk_anim()
            self._clear_intro_fall()
        if entity_id == self._talk_entity:
            self._clear_talk_anim()

    def _on_script_tick(self, args=None):
        self._client_tick += 1
        self._pump_voice_queue()

        if self._client_tick % 8 == 0:
            self._sync_hold_ui()

        if self._talk_entity and self._client_tick >= self._talk_end_tick:
            if not self._voice_queue_busy and not self._voice_queue:
                self._clear_talk_anim()

        if self._intro_fall_entity and self._client_tick >= self._intro_fall_end_tick:
            self._clear_intro_fall()

        if not self._box_loop_active or self._box_woken:
            return
        if self._client_tick < self._next_box_call_tick:
            return
        if not self._box_loop_entity or not self._entity_exists(self._box_loop_entity):
            self._stop_box_loop()
            return
        self._play_sound(BOX_LOOP_SOUND, (0.0, 0.0, 0.0), self._box_loop_entity, False, 1.0)
        self._next_box_call_tick = self._client_tick + CALL_DURATION_TICKS

    def _on_box_spawn(self, args):
        entity_id = args.get("entityId")
        if not entity_id:
            return
        self._reset_box_client_state()
        self._track_box(entity_id)

    def _on_stop_music(self, args=None):
        self._stop_bgm()

    def _on_mob_spawn(self, args):
        entity_id = args.get("entityId")
        if not entity_id:
            return
        self._mob_id = entity_id
        # Only start fall if not already running (may have been started in _on_add_entity)
        if args.get("introFall") and not self._intro_fall_entity:
            self._start_intro_fall(entity_id)

    def _on_wake(self, args):
        entity_id = args.get("entityId")
        if not entity_id:
            return
        self._box_woken = True
        self._stop_box_loop()
        self._register_wake_query(entity_id, 1.0)

    def _on_play_sound(self, args):
        sound_name = args.get("sound")
        if not sound_name or sound_name == BOX_LOOP_SOUND:
            return
        monster_horror = bool(args.get("monsterHorror")) or self._is_monster_horror_sound(sound_name)
        if monster_horror:
            token = int(args.get("horrorToken") or 0)
            if token <= 0:
                return
            if self._monster_horror_token not in (0, token):
                return
            self._monster_horror_token = token
            volume = float(args.get("volume", 1.0))
            if bool(args.get("loop", False)):
                self._play_monster_horror_loop(sound_name, volume)
            else:
                self._play_monster_horror_one_shot(sound_name, volume)
            return
        if args.get("bgm") or self._is_bgm_track(sound_name):
            self._play_bgm(
                sound_name,
                loop=bool(args.get("loop", True)),
                volume=float(args.get("volume", 1.0)),
            )
            return
        pos = (
            float(args.get("x", 0.0)),
            float(args.get("y", 0.0)),
            float(args.get("z", 0.0)),
        )
        loop = bool(args.get("loop", False))
        volume = float(args.get("volume", 1.0))
        zh_text = args.get("zh")
        entity_id = self._player_id
        talk_entity_id = args.get("entityId") or self._mob_id
        use_queue = bool(args.get("queue", False))
        interrupt = bool(args.get("interrupt", True))
        if interrupt:
            self._stop_active_voice()
        if use_queue:
            self._enqueue_voice(sound_name, pos, entity_id, loop, volume, zh_text)
            talk_id = self._talk_anim_entity(talk_entity_id)
            if talk_id:
                self._start_talk_anim(talk_id, sound_name, zh_text)
            self._pump_voice_queue()
            return
        self._play_sound(sound_name, pos, entity_id, loop, volume, talk_entity_id, zh_text)
