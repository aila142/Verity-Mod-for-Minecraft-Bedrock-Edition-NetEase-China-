# -*- coding: utf-8 -*-
"""Scene-aware dialogue: scan nearby blocks/entities and craft contextual lines."""
from __future__ import print_function

import random

try:
    unicode
except NameError:
    unicode = str

_WATER = (
    "water", "flowing_water", "kelp", "seagrass", "bubble_column",
)
_TREE = ("log", "leaves", "mangrove", "cherry")
_SAND = ("sand", "red_sand", "sandstone")
_SNOW = ("snow", "snow_layer", "powder_snow", "ice", "packed_ice")
_STONE = ("stone", "deepslate", "tuff", "granite", "diorite", "andesite")
_GRASS = ("grass", "dirt", "podzol", "mycelium")

_HOSTILE = (
    "zombie", "skeleton", "creeper", "spider", "witch", "phantom",
    "pillager", "vindicator", "evoker", "blaze", "ghast", "warden",
    "drowned", "husk", "stray", "slime", "magma_cube",
)
_ANIMAL = (
    "pig", "cow", "sheep", "chicken", "rabbit", "horse", "donkey",
    "wolf", "cat", "fox", "bee", "goat", "axolotl", "frog",
)


def scan_scene(probe_fn, cx, cy, cz, dim, game_hour=None, entity_types=None, weather=None):
    """Return a lightweight scene dict from block probes and entity type strings."""
    scene = {
        "water": 0,
        "trees": 0,
        "sand": 0,
        "snow": 0,
        "stone": 0,
        "grass": 0,
        "samples": 0,
        "height_min": cy,
        "height_max": cy,
        "hostile_near": 0,
        "animal_near": 0,
        "villager_near": 0,
        "hour": game_hour,
        "is_night": False,
        "is_day": True,
        "raining": False,
        "thunder": False,
    }
    w = weather or {}
    scene["raining"] = bool(w.get("raining"))
    scene["thunder"] = bool(w.get("thunder"))
    if game_hour is not None:
        scene["is_night"] = game_hour >= 19 or game_hour < 6
        scene["is_day"] = not scene["is_night"]

    for et in (entity_types or []):
        low = (et or "").lower()
        if not low:
            continue
        if "villager" in low or "wandering_trader" in low:
            scene["villager_near"] += 1
        matched_hostile = False
        for token in _HOSTILE:
            if token in low:
                scene["hostile_near"] += 1
                matched_hostile = True
                break
        if matched_hostile:
            continue
        for token in _ANIMAL:
            if token in low:
                scene["animal_near"] += 1
                break

    radius = 7
    step = 2
    y_levels = (cy - 1, cy, cy + 1)
    for dx in range(-radius, radius + 1, step):
        for dz in range(-radius, radius + 1, step):
            for y in y_levels:
                name = probe_fn(cx + dx, y, cz + dz, dim)
                if not name:
                    continue
                scene["samples"] += 1
                low = name.lower()
                if _name_has_any(low, _WATER):
                    scene["water"] += 1
                if _name_has_any(low, _TREE):
                    scene["trees"] += 1
                if _name_has_any(low, _SAND):
                    scene["sand"] += 1
                if _name_has_any(low, _SNOW):
                    scene["snow"] += 1
                if _name_has_any(low, _STONE):
                    scene["stone"] += 1
                if _name_has_any(low, _GRASS):
                    scene["grass"] += 1
            ground = probe_fn(cx + dx, cy - 1, cz + dz, dim)
            if ground and not _is_air_name(ground):
                gy = cy - 1
                if gy < scene["height_min"]:
                    scene["height_min"] = gy
                if gy > scene["height_max"]:
                    scene["height_max"] = gy

    scene["height_range"] = scene["height_max"] - scene["height_min"]
    scene["flat"] = scene["height_range"] <= 2 and scene["grass"] >= 3
    scene["mountain"] = scene["height_range"] >= 5
    scene["forest"] = scene["trees"] >= 4
    scene["river_bank"] = scene["water"] >= 2 and scene["grass"] >= 2
    scene["desert"] = scene["sand"] >= 5 and scene["trees"] <= 1
    scene["snowy"] = scene["snow"] >= 3
    scene["rocky"] = scene["stone"] >= 8 and scene["grass"] <= 2
    return scene


def env_comments_allowed(context):
    mute = int((context or {}).get("env_comment_mute_until") or 0)
    now = int((context or {}).get("turn_tick") or 0)
    if mute and now and now < mute:
        return False
    return True


def pick_village_line(context, scene):
    """Proactive village proximity comment with cooldown."""
    if not scene or int(scene.get("villager_near") or 0) < 1:
        return None
    now = int((context or {}).get("turn_tick") or 0)
    until = int((context or {}).get("village_comment_until") or 0)
    if until and now and now < until:
        return None
    import random as _rnd
    context["village_comment_until"] = now + _rnd.randint(3600, 6000)
    tag = _role_tag(context)
    lines = _pack_variants(
        context, "env_village_near",
        u"%s\u524d\u9762\u50cf\u662f\u6751\u5e84\uff0c\u8981\u4e0d\u8981\u8fdb\u53bb\u6253\u4e2a\u62db\u547c\uff1f" % tag,
        u"%s\u95fb\u5230\u6751\u5e84\u5473\u4e86\uff0c\u9644\u8fd1\u5e94\u8be5\u6709\u6751\u6c11\u3002" % tag,
        "Village nearby.",
        "env_village_near_",
    )
    if not lines:
        return None
    pick = _rnd.choice(lines)
    if pick and len(pick) >= 5:
        zh = pick[2] or u""
        if u"\u6253\u4e2a\u62db\u547c" in zh or u"\u8981\u4e0d\u8981" in zh:
            try:
                import verityConversation as conv
                conv.set_pending_question(context, "confirm_village_greet", zh, None, now)
            except Exception:
                pass
    return pick


def pick_scene_line(context, scene):
    """Return (topic, en, zh, sound, action) or None."""
    if not env_comments_allowed(context):
        return None
    if not scene or int(scene.get("samples") or 0) < 4:
        return None
    tag = _role_tag(context)
    lines = []

    if scene.get("river_bank"):
        lines.extend(_pack_variants(
            context, "env_river_build",
            u"%s\u5c0f\u6cb3\u8fb9\u5efa\u623f\u5b50\u633a\u4e0d\u9519\u7684\uff0c\u6c34\u666f\u4e5f\u597d\u770b\u3002" % tag,
            u"%s\u8fd9\u513f\u9760\u6c34\uff0c\u642d\u4e2a\u6728\u5c4b\u6216\u77f3\u5934\u623f\u90fd\u884c\u3002" % tag,
            "Riverbank looks good for a base.",
            "brain_build_",
        ))
    if scene.get("flat") and scene.get("grass") >= 3:
        lines.extend(_pack_variants(
            context, "env_flat_build",
            u"%s\u8fd9\u4e00\u7247\u633a\u5e73\u7684\uff0c\u9002\u5408\u5efa\u623f\u5b50\u3002" % tag,
            u"%s\u5730\u52bf\u5f00\u9614\uff0c\u653e\u4e2a\u907f\u96be\u6240\u521a\u597d\u3002" % tag,
            "Flat ground — good for building.",
            "brain_build_",
        ))
    if scene.get("forest"):
        lines.extend(_pack_variants(
            context, "env_forest",
            u"%s\u6797\u5b50\u633a\u591a\u7684\uff0c\u6728\u6750\u4e0d\u7528\u6015\u7f3a\u3002" % tag,
            u"%s\u6811\u6797\u73af\u5883\uff0c\u8981\u662f\u5efa\u6728\u5934\u623f\u5f88\u7701\u4e8b\u3002" % tag,
            "Plenty of wood around here.",
            "brain_build_",
        ))
    if scene.get("mountain"):
        lines.extend(_pack_variants(
            context, "env_mountain",
            u"%s\u5c71\u52bf\u6709\u70b9\u590d\u6742\uff0c\u5efa\u623f\u5f97\u5148\u627e\u575a\u5b9e\u5730\u9762\u3002" % tag,
            u"%s\u8fd9\u513f\u9ad8\u4f4e\u4e0d\u5e73\uff0c\u4f46\u666f\u89c2\u5e94\u8be5\u4e0d\u9519\u3002" % tag,
            "Hilly terrain — pick a flat spot first.",
            "chat_help_",
        ))
    if scene.get("desert"):
        lines.extend(_pack_variants(
            context, "env_desert",
            u"%s\u6c99\u6f06\u6f06\u7684\uff0c\u8bb0\u5f97\u5e26\u6c34\uff0c\u522b\u665a\u4e0a\u70ed\u6b7b\u3002" % tag,
            u"%s\u8352\u6f06\u70ed\u571f\uff0c\u8981\u662f\u642d\u5c4b\u5b50\u5f97\u9632\u665a\u4e0a\u602a\u7269\u3002" % tag,
            "Desert heat — stay hydrated.",
            "chat_help_",
        ))
    if scene.get("snowy"):
        lines.extend(_pack_variants(
            context, "env_snow",
            u"%s\u4e0b\u96ea\u5730\u533a\u633a\u51b7\u7684\uff0c\u591a\u505a\u70b9\u70ad\u706b\u5427\u3002" % tag,
            u"%s\u96ea\u5730\u867d\u7136\u6f02\u4eae\uff0c\u4f46\u591c\u91cc\u602a\u4f1a\u591a\u3002" % tag,
            "Cold biome — keep warm.",
            "brain_cold_",
        ))
    if scene.get("rocky"):
        lines.extend(_pack_variants(
            context, "env_rocky",
            u"%s\u77f3\u5934\u633a\u591a\uff0c\u6316\u4e00\u6316\u80fd\u627e\u5230\u597d\u6750\u6599\u3002" % tag,
            u"%s\u5ca9\u77f3\u5730\u5e26\uff0c\u9002\u5408\u6316\u77ff\u6216\u642d\u77f3\u5934\u623f\u3002" % tag,
            "Rocky area — good for mining.",
            "chat_help_",
        ))
    if int(scene.get("hostile_near") or 0) >= 1:
        lines.extend(_pack_variants(
            context, "env_hostile",
            u"%s\u9644\u8fd1\u6709\u602a\uff0c\u522b\u788c\u5fc3\uff0c\u5148\u6e05\u4e00\u6e05\u518d\u5efa\u3002" % tag,
            u"%s\u5468\u56f4\u4e0d\u592a\u5b89\u5168\uff0c\u8981\u4e0d\u6211\u5e2e\u4f60\u6e05\u602a\uff1f" % tag,
            "Hostiles nearby — stay alert.",
            "brain_clear_mobs_",
        ))
    if int(scene.get("animal_near") or 0) >= 2:
        lines.extend(_pack_variants(
            context, "env_animals",
            u"%s\u9644\u8fd1\u6709\u52a8\u7269\uff0c\u98df\u7269\u6765\u6e90\u633a\u5145\u8db3\u7684\u3002" % tag,
            u"%s\u770b\u5230\u597d\u591a\u52a8\u7269\uff0c\u8981\u4e0d\u5148\u56f4\u4e2a\u680f\u6811\uff1f" % tag,
            "Animals nearby — food supply looks good.",
            "brain_give_food_",
        ))
    if int(scene.get("villager_near") or 0) >= 1:
        lines.extend(_pack_variants(
            context, "env_villager",
            u"%s\u6709\u6751\u6c11\u5728\u9644\u8fd1\uff0c\u8d70\uff0c\u6211\u4eec\u53bb\u770b\u770b\u6709\u4ec0\u4e48\u597d\u4e1c\u897f\u3002" % tag,
            u"%s\u6751\u6c11\u5546\u5e97\u8bf4\u4e0d\u5b9a\u6709\u7528\u7684\u4ea4\u6613\u3002" % tag,
            "Villagers nearby — might trade.",
            "chat_greeting_",
        ))
    if scene.get("is_night"):
        lines.extend(_pack_variants(
            context, "env_night",
            u"%s\u5929\u9ed1\u4e86\uff0c\u8981\u662f\u5916\u9762\u6d3b\u52a8\u8bb0\u5f97\u70b9\u706b\u628a\u602a\u8d76\u8d70\u3002" % tag,
            u"%s\u591c\u665a\u602a\u591a\uff0c\u6700\u597d\u5148\u56de\u907f\u96be\u6240\u3002" % tag,
            "Night falls — light it up.",
            "chat_help_",
        ))
    elif scene.get("is_day") and scene.get("hour") is not None:
        hour = scene["hour"]
        if 6 <= hour < 10:
            lines.extend(_pack_variants(
                context, "env_morning",
                u"%s\u65e9\u6668\u633a\u8212\u670d\u7684\uff0c\u9002\u5408\u6536\u96c6\u8d44\u6e90\u3002" % tag,
                u"%s\u65e9\u4e0a\u597d\uff0c\u8981\u662f\u5efa\u623f\u5b50\u73b0\u5728\u5f00\u5de5\u521a\u597d\u3002" % tag,
                "Morning — good time to gather.",
                "chat_greeting_",
            ))
        elif 10 <= hour < 14:
            lines.extend(_pack_variants(
                context, "env_noon",
                u"%s\u592a\u9633\u633a\u6653\u7684\uff0c\u522b\u6652\u592a\u4e45\u3002" % tag,
                u"%s\u6b63\u5348\u4e86\uff0c\u8bb0\u5f97\u8865\u6c34\u518d\u51fa\u95e8\u3002" % tag,
                "Midday sun — stay hydrated.",
                "chat_help_",
            ))
        elif 18 <= hour < 22:
            lines.extend(_pack_variants(
                context, "env_evening",
                u"%s\u5929\u5feb\u9ed1\u4e86\uff0c\u6536\u62fe\u4e00\u4e0b\u56de\u5bb6\u5427\u3002" % tag,
                u"%s\u665a\u4e0a\u4e86\uff0c\u522b\u5728\u5916\u9762\u6d78\u592a\u4e45\u3002" % tag,
                "Evening — head back soon.",
                "chat_help_",
            ))
        elif hour >= 22 or hour < 6:
            lines.extend(_pack_variants(
                context, "env_late_night",
                u"%s\u592a\u9ed1\u4e86\uff0c\u8be5\u7761\u89c9\u5c31\u53bb\u7761\u5427\u3002" % tag,
                u"%s\u6df1\u591c\u4e86\uff0c\u522b\u786c\u6491\u7740\u4e86\u3002" % tag,
                "Late night — get some sleep.",
                "chat_help_",
            ))

    if scene.get("raining"):
        lines.extend(_pack_variants(
            context, "env_rain",
            u"%s\u4e0b\u96e8\u4e86\uff0c\u5148\u627e\u4e2a\u5730\u65b9\u953b\u96e8\u5427\u3002" % tag,
            u"%s\u96e8\u633a\u5927\u7684\uff0c\u8981\u4e0d\u5148\u56de\u907f\u96be\u6240\u953b\u4e00\u953b\uff1f" % tag,
            "Raining — find shelter.",
            "cmd_weather_rain_",
        ))
    if scene.get("thunder"):
        lines.extend(_pack_variants(
            context, "env_thunder",
            u"%s\u6253\u96f7\u4e86\uff0c\u522b\u5728\u9ad8\u5904\u6446\u5bb6\u5177\u3002" % tag,
            u"%s\u96f7\u7535\u5929\u6c14\uff0c\u5c3d\u91cf\u522b\u5728\u5916\u9762\u6d78\u6dcb\u3002" % tag,
            "Thunder — stay indoors.",
            "cmd_weather_thunder_",
        ))

    if not lines:
        return None
    pick = random.choice(lines)
    if pick and len(pick) >= 5:
        zh = pick[2] or u""
        if u"\u8981\u4e0d\u6211\u5e2e\u4f60\u6e05\u602a" in zh:
            act = {"type": "kill_hostile", "radius": 24}
            return pick[0], pick[1], pick[2], pick[3], act
    return pick


def summarize_scene(context, scene):
    """Build a single chat line from cached scene scan (no action)."""
    if not scene or int(scene.get("samples") or 0) < 4:
        return u"\u6211\u8fd8\u770b\u4e0d\u592a\u6e05\u5468\u56f4\u5730\u5f62\uff0c\u4f60\u5e26\u6211\u8d70\u8d70\u3002"
    tag = _role_tag(context)
    parts = []
    if int(scene.get("hostile_near") or 0) >= 1:
        parts.append(u"\u6709\u602a\u7269")
    if int(scene.get("animal_near") or 0) >= 1:
        parts.append(u"\u6709\u52a8\u7269")
    if int(scene.get("villager_near") or 0) >= 1:
        parts.append(u"\u6709\u6751\u6c11")
    if scene.get("river_bank"):
        parts.append(u"\u9760\u8fd1\u6709\u6c34")
    if scene.get("forest"):
        parts.append(u"\u6811\u6797")
    if scene.get("desert"):
        parts.append(u"\u8352\u6f06\u70ed\u571f")
    if scene.get("snowy"):
        parts.append(u"\u96ea\u5730")
    if scene.get("mountain"):
        parts.append(u"\u5c71\u5730")
    if scene.get("flat") and scene.get("grass") >= 3:
        parts.append(u"\u5e73\u5730")
    if parts:
        return tag + u"\u9644\u8fd1" + u"\u3001".join(parts) + u"\u3002"
    if scene.get("river_bank"):
        return tag + u"\u9760\u6c34\u7684\u5730\u65b9\u633a\u9002\u5408\u5efa\u623f\uff0c\u666f\u8272\u4e5f\u597d\u3002"
    if scene.get("flat") and scene.get("grass") >= 3:
        return tag + u"\u8fd9\u4e00\u7247\u633a\u5e73\u7684\uff0c\u5efa\u623f\u5b50\u633a\u5408\u9002\u3002"
    if scene.get("forest"):
        return tag + u"\u6811\u591a\uff0c\u6728\u6750\u4e0d\u7f3a\uff0c\u642d\u4e2a\u6728\u5934\u623f\u5f88\u7701\u4e8b\u3002"
    if scene.get("mountain"):
        return tag + u"\u5c71\u52bf\u6709\u70b9\u659c\uff0c\u5efa\u623f\u524d\u5148\u627e\u575a\u5b9e\u5730\u9762\u3002"
    if scene.get("desert"):
        return tag + u"\u8352\u6f06\u70ed\u571f\uff0c\u8981\u662f\u642d\u5c4b\u5b50\u5f97\u9632\u665a\u4e0a\u602a\u7269\u3002"
    if scene.get("snowy"):
        return tag + u"\u96ea\u5730\u51b7\uff0c\u5efa\u623f\u5b50\u591a\u70b9\u70ad\u706b\u5427\u3002"
    if int(scene.get("hostile_near") or 0) >= 1:
        return tag + u"\u5468\u56f4\u6709\u602a\uff0c\u5148\u6e05\u602a\u518d\u5efa\u623f\u66f4\u5b89\u5168\u3002"
    if int(scene.get("villager_near") or 0) >= 1:
        return tag + u"\u6709\u6751\u6c11\u5728\u9644\u8fd1\uff0c\u8fd9\u513f\u5efa\u623f\u5b50\u65b9\u4fbf\u505a\u4ea4\u6613\u3002"
    return tag + u"\u770b\u4e86\u4e00\u5708\uff0c\u5efa\u623f\u5b50\u8fd8\u884c\uff0c\u5177\u4f53\u770b\u4f60\u60f3\u642d\u4ec0\u4e48\u6837\u7684\u3002"


def _name_has_any(name, tokens):
    for token in tokens:
        if token in name:
            return True
    return False


def _is_air_name(name):
    low = (name or "").lower()
    return ("air" in low) or (not low)


def _relationship_tier(context):
    rel = (context or {}).get("relationship")
    aff = int((context or {}).get("affection") or 50)
    trust = int((context or {}).get("trust") or 50)
    if rel == "lover" or aff >= 72:
        return "intimate"
    if rel in ("gege", "jiejie", "meimei", "didi", "friend") or aff >= 52 or trust >= 58:
        return "friendly"
    return "stranger"


def _role_tag(context):
    pr = (context or {}).get("player_role") or (context or {}).get("player_name") or u""
    if pr:
        return pr + u"\uff0c"
    return u""


def _pack_variants(context, topic_base, zh_a, zh_b, en_base, voice_prefix):
    tier = _relationship_tier(context)
    rel = (context or {}).get("relationship")
    if tier == "intimate" and rel == "lover":
        if voice_prefix.startswith("soul_") or voice_prefix.startswith("chat_"):
            voice_prefix = "soul_lover_"
    elif tier == "stranger" and voice_prefix.startswith("soul_lover_"):
        voice_prefix = "soul_friend_"
    out = []
    out.append(_make_line(topic_base + "_a", en_base, zh_a, voice_prefix))
    out.append(_make_line(topic_base + "_b", en_base, zh_b, voice_prefix))
    return out


def _make_line(topic, en, zh, voice_prefix):
    try:
        import verityBrain as brain
        return brain._pack(topic, en, zh, voice_prefix, None)
    except Exception:
        return topic, en, zh, None, None
