# -*- coding: utf-8 -*-
"""Verity dialogue layer — runs before Verity build/combat corpus."""
from __future__ import print_function

try:
    unicode
except NameError:
    unicode = str

VERITY_FALLBACK_ZH = u"\u4f60\u53ef\u4ee5\u95ee\u6211\u4efb\u4f55\u4e8b\u3002\u6211\u5168\u90fd\u77e5\u9053\u3002"
VERITY_FALLBACK_SOUND = "verity.voice.opening"


def try_verity_reply(text):
    """Return (topic, en, zh, sound, action) or None."""
    try:
        import verityKnowledgeCore as vk
        ans = vk.try_knowledge_answer(text)
        if ans:
            return (
                u"verity_knowledge",
                u"",
                ans,
                "verity.voice.opening",
                None,
            )
    except Exception:
        pass
    try:
        import verityChat as vc
        ans = vc.try_basic_chat(text)
        if ans:
            return (u"verity_chat", u"", ans, None, None)
    except Exception:
        pass
    return None


def verity_smart_fallback():
    return (
        u"verity_fallback",
        u"",
        VERITY_FALLBACK_ZH,
        VERITY_FALLBACK_SOUND,
        None,
    )
