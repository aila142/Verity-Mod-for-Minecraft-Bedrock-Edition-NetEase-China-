# -*- coding: utf-8 -*-
"""Session chat log, pending AI questions, yes/no follow-through."""
from __future__ import print_function

import random
import re

try:
    unicode
except NameError:
    unicode = str

_CHAT_LIMIT = 120
_PENDING_TTL = 900

_YES_KW = (
    u"\u662f\u7684", u"\u662f\u554a", u"\u5bf9\u554a", u"\u5bf9\u7684", u"\u6ca1\u9519",
    u"\u8981\u7684", u"\u8981\u554a", u"\u8981\u7684", u"\u8981", u"\u597d\u7684", u"\u597d\u5440",
    u"\u597d\u5440", u"\u597d\u5440", u"\u597d", u"\u884c", u"\u884c\u7684", u"\u884c\u5427",
    u"\u53ef\u4ee5", u"\u6ca1\u95ee\u9898", u"\u6765\u5427", u"\u6e05\u5427", u"\u5e2e\u6211",
    u"\u9ebb\u70e6", u"\u55ef", u"\u55ef\u55ef", u"\u606c", u"\u662f", u"\u5bf9",
    u"\u6709", u"\u8981\u5427", u"\u5f53\u7136", u"\u5f53\u7136\u8981",
    u"\u6ee1\u610f", u"\u633a\u597d", u"\u8fd8\u884c", u"\u8fd8\u53ef\u4ee5", u"\u4e0d\u9519",
    u"\u633a\u68d2", u"\u633a\u6ee1\u610f", u"\u6ca1\u95ee\u9898", u"\u53ef\u4ee5\u554a",
    u"\u53bb", u"\u8fdb\u53bb", u"\u6253\u62db\u547c", u"\u62db\u547c", u"\u6751\u6c11",
    "yes", "yeah", "yep", "ok", "okay", "sure", "please", "go ahead", "go", "lets go",
)
_NO_KW = (
    u"\u4e0d\u8981", u"\u522b", u"\u4e0d\u7528", u"\u7b97\u4e86", u"\u4e0d\u884c", u"\u4e0d\u8981\u4e86",
    u"\u4e0d\u7528\u4e86", u"\u5148\u4e0d", u"\u6682\u65f6\u4e0d", u"\u514d\u4e86", u"\u5426",
    u"\u4e0d\u662f", u"\u4e0d\u5bf9", u"\u4e0d\u7528\u8c22", u"\u4e0d\u7528\u4e86",
    u"\u4e0d\u6ee1\u610f", u"\u4e0d\u592a\u6ee1\u610f", u"\u4e0d\u597d", u"\u4e0d\u592a\u884c",
    u"\u4e0d\u592a\u597d", u"\u522b\u4e86", u"\u7b97\u4e86\u5427",
    "no", "nope", "don't", "dont", "not now", "never mind",
)

_QUESTION_CLEAR_MOBS = (
    u"\u6e05\u602a", u"\u6e05\u602a\u7269", u"\u6253\u602a", u"\u6253\u6389\u602a",
    u"\u5e2e\u4f60\u6e05", u"\u5e2e\u6211\u6e05", u"\u5468\u56f4\u4e0d\u592a\u5b89\u5168",
    u"\u9644\u8fd1\u6709\u602a",
)
_QUESTION_BUILD = (
    u"\u5e2e\u4f60\u5efa", u"\u8981\u4e0d\u8981\u5efa", u"\u642d\u4e2a\u907f\u96be",
)


def ensure_conversation(context):
    if context is None:
        return
    context.setdefault("chat_log", [])
    context.setdefault("pending_question", None)
    context.setdefault("last_ai_question", None)


def append_message(context, role, text, tick=None):
    ensure_conversation(context)
    line = _u(text)
    if not line:
        return
    entry = {"role": role, "text": line}
    if tick is not None:
        entry["tick"] = int(tick)
    context["chat_log"].append(entry)
    log = context["chat_log"]
    if len(log) > _CHAT_LIMIT:
        del log[0:len(log) - _CHAT_LIMIT]


def set_pending_question(context, qtype, source_zh, action=None, tick=None):
    ensure_conversation(context)
    pending = {
        "type": qtype,
        "zh": _u(source_zh),
        "action": action,
        "tick": int(tick or 0),
    }
    context["pending_question"] = pending
    context["last_ai_question"] = pending


def clear_pending_question(context):
    if context is None:
        return
    context["pending_question"] = None


def note_ai_reply(context, zh, action=None, tick=None):
    """Detect offer-style questions in Verity lines and store pending state."""
    ensure_conversation(context)
    text = _u(zh)
    if not text:
        return
    is_question = (
        u"\uff1f" in text or u"?" in text
        or u"\u8981\u4e0d" in text or u"\u662f\u5426" in text
    )
    if not is_question:
        return
    if action and action.get("type"):
        if action.get("type") in ("report_scene", "query_game_time", "query_players"):
            return
        set_pending_question(context, action.get("type"), text, action, tick)
        return
    if _match_any(text, _QUESTION_CLEAR_MOBS):
        act = {"type": "kill_hostile", "radius": 24}
        set_pending_question(context, "kill_hostile", text, act, tick)
        return
    if _match_any(text, _QUESTION_BUILD):
        act = {"type": "build_shelter", "material": "oak"}
        set_pending_question(context, "build_shelter", text, act, tick)
        return
    # Vague proactive "需要帮忙吗" must NOT trap the next unrelated message.
    if _match_any(text, (
        u"\u9700\u8981\u5e2e\u5fd9", u"\u8981\u6211\u5e2e", u"\u5e2e\u4f60\u5e2e",
        u"\u8981\u4e0d\u8981\u5e2e", u"\u8981\u6211\u5e2e\u5417",
        u"\u6709\u4e8b\u5c31\u53eb", u"\u968f\u4fbf\u8bf4",
    )):
        return
    if u"\u8fd8\u662f\u5417" in text or u"\u8fd8\u662f\u5417\u5417" in text or u"\u6ca1\u8bb0\u9519" in text:
        if u"\u559c\u6b22" in text or u"\u7231\u597d" in text or u"\u63d0\u8fc7" in text:
            set_pending_question(context, "confirm_hobby", text, None, tick)
            return
        if u"\u5c81" in text:
            set_pending_question(context, "confirm_age", text, None, tick)
            return
    if u"\u8981\u4e0d\u8981\u8fdb\u53bb\u6253\u4e2a\u62db\u547c" in text or u"\u6253\u4e2a\u62db\u547c" in text:
        set_pending_question(context, "confirm_village_greet", text, None, tick)
        return
    if u"\u6ee1\u610f" in text or u"\u8fd8\u597d\u5417" in text or u"\u8fd8\u884c\u5417" in text:
        if u"\u623f" in text or u"\u5efa" in text or u"\u642d" in text or u"\u5c4b" in text:
            set_pending_question(
                context, "confirm_build", text,
                {"type": "build_shelter", "style": "shelter"}, tick,
            )
            return
    if u"\u8fd8\u591f\u7528" in text or u"\u518d\u6765\u70b9" in text or u"\u8fd8\u9700\u8981" in text:
        last_action = (context or {}).get("last_action")
        if last_action:
            set_pending_question(context, "confirm_more_items", text, dict(last_action), tick)
            return


def note_player_message(context, text, tick=None):
    append_message(context, "player", text, tick)


def get_recent_turns(context, limit=20):
    ensure_conversation(context)
    log = context.get("chat_log") or []
    if limit <= 0:
        return list(log)
    if len(log) <= limit:
        return list(log)
    return list(log[-limit:])


def get_last_severity_text(context):
    for entry in reversed(get_recent_turns(context, 30)):
        if entry.get("role") == "severity":
            return entry.get("text") or u""
    return u""


def get_last_player_text(context):
    for entry in reversed(get_recent_turns(context, 30)):
        if entry.get("role") == "player":
            return entry.get("text") or u""
    return u""


def has_recent_emotional_thread(context):
    sad_hints = (
        u"\u4f24\u5fc3", u"\u96be\u8fc7", u"\u59d4\u5c48", u"\u545c\u545c", u"\u54ed",
        u"\u5b64\u5355", u"\u5fc3\u75db", u"\u5b89\u6150", u"\u54c4\u6211",
    )
    for entry in reversed(get_recent_turns(context, 12)):
        text = entry.get("text") or u""
        for hint in sad_hints:
            if hint in text:
                return True
    last_topic = (context or {}).get("last_topic") or u""
    if last_topic.startswith(("brain_sad", "soul_comfort", "soul_cry", "chat_help")):
        return True
    return False


def _is_affirmation(text):
    t = (text or u"").strip().strip(u"\uff01\uff1f!?。，,")
    if not t or len(t) > 12:
        return False
    if _is_denial(text):
        return False
    if t in _YES_KW:
        return True
    for kw in _YES_KW:
        if t == kw or t.endswith(kw):
            return True
    if t in (u"\u8981", u"\u597d", u"\u884c", u"\u662f", u"\u606c", u"\u55ef"):
        return True
    if t.startswith(u"\u8981") and len(t) <= 4:
        return True
    return False


def _is_denial(text):
    t = (text or u"").strip().strip(u"\uff01\uff1f!?。，,")
    if not t:
        return False
    for kw in _NO_KW:
        if kw in t:
            return True
    return False


def _pending_stale(context, now_tick):
    pending = (context or {}).get("pending_question")
    if not pending:
        return True
    started = int(pending.get("tick") or 0)
    if started and now_tick and now_tick - started > _PENDING_TTL:
        return True
    return False


def _infer_pending_from_log(context):
    log = (context or {}).get("chat_log") or []
    for entry in reversed(log):
        if entry.get("role") != "severity":
            continue
        text = entry.get("text") or u""
        if u"\uff1f" in text or u"?" in text or u"\u8981\u4e0d" in text or u"\u5417" in text:
            if _match_any(text, _QUESTION_CLEAR_MOBS):
                return {
                    "type": "kill_hostile",
                    "zh": text,
                    "action": {"type": "kill_hostile", "radius": 24},
                }
            if _match_any(text, _QUESTION_BUILD):
                return {
                    "type": "build_shelter",
                    "zh": text,
                    "action": {"type": "build_shelter", "material": "oak"},
                }
            if u"\u559c\u6b22" in text or u"\u7231\u597d" in text or u"\u63d0\u8fc7" in text:
                if u"\u8fd8\u662f\u5417" in text or u"\u5417" in text:
                    return {"type": "confirm_hobby", "zh": text, "action": None}
            if u"\u623f" in text or u"\u5c4b" in text or u"\u642d" in text:
                if u"\u6ee1\u610f" in text or u"\u8fd8\u597d" in text:
                    return {
                        "type": "confirm_build",
                        "zh": text,
                        "action": {"type": "build_shelter", "style": "shelter"},
                    }
            if u"\u8fd8\u591f\u7528" in text or u"\u518d\u6765\u70b9" in text or u"\u8fd8\u8981" in text:
                last_action = (context or {}).get("last_action")
                if last_action:
                    return {
                        "type": "confirm_more_items",
                        "zh": text,
                        "action": dict(last_action),
                    }
            if u"\u6253\u6751\u6c11" in text or u"\u653b\u51fb\u6751\u6c11" in text:
                return {
                    "type": "confirm_attack_villager",
                    "zh": text,
                    "action": {"type": "attack_villager", "radius": 32},
                }
        break
    return None


def _is_skeptic_question(text):
    stripped = (text or u"").strip().strip(u"\uff01\uff1f!?。，,")
    return stripped in (
        u"\u771f\u7684\u5417", u"\u771f\u7684\u5417\u5417", u"\u662f\u5417", u"\u662f\u5417\u5417",
        u"\u5f53\u771f\u5417", u"\u771f\u7684\u5047\u7684", u"\u6ca1\u9a97\u6211\u5427",
        "really", "seriously", "for real",
    )


def try_pending_reply(text, context, message):
    ensure_conversation(context)
    if _is_skeptic_question(text):
        return None
    now_tick = int((context or {}).get("turn_tick") or 0)
    pending = context.get("pending_question")
    if _pending_stale(context, now_tick):
        clear_pending_question(context)
        pending = None
    if not pending:
        pending = _infer_pending_from_log(context)
    if not pending:
        return None
    if not _is_affirmation(text) and not _is_denial(text):
        stripped = (text or u"").strip()
        if len(stripped) <= 10 and pending.get("type", "").startswith("confirm_"):
            return None
        clear_pending_question(context)
        return None
    action = pending.get("action")
    qtype = pending.get("type") or (action or {}).get("type")
    clear_pending_question(context)
    if _is_denial(text):
        if qtype == "confirm_hobby":
            zh = u"\u54e6\uff0c\u6362\u7231\u597d\u4e86\uff1f\u544a\u8bc9\u6211\u4f60\u73b0\u5728\u559c\u6b22\u4ec0\u4e48\u3002"
            return _pack("conv_hobby_no", u"Hobby changed?", zh, "soul_friend_", None)
        if qtype == "confirm_build":
            zh = u"\u884c\uff0c\u6211\u7ed9\u4f60\u91cd\u65b0\u642d\u4e00\u5957\u3002"
            act = {"type": "build_shelter", "style": "shelter"}
            return _pack("conv_build_no", u"Rebuilding.", zh, "build_wood_", act)
        if qtype == "confirm_more_items":
            zh = u"\u597d\uff0c\u90a3\u5148\u4e0d\u8865\u4e86\u3002"
            return _pack("conv_more_no", u"Okay, not now.", zh, "soul_friend_", None)
        zh = random.choice([
            u"\u884c\u5427\uff0c\u90a3\u5c31\u5148\u4e0d\u641e\u4e86\u3002",
            u"\u597d\uff0c\u968f\u4fbf\u4f60\uff0c\u6709\u4e8b\u518d\u53eb\u6211\u3002",
            u"\u6536\u5230\uff0c\u6211\u4e0d\u591a\u5634\u4e86\u3002",
        ])
        return _pack("conv_pending_no", u"Okay, skipping.", zh, None, None)
    if qtype == "confirm_hobby":
        facts = (context or {}).get("player_facts") or {}
        hobby = facts.get("hobby") or u""
        if hobby:
            zh = u"\u8bb0\u5f97\uff0c\u4f60\u8fd8\u559c\u6b22%s\u3002" % hobby
        else:
            zh = u"\u8bb0\u5f97\uff0c\u4f60\u63d0\u8fc7\u7684\u6211\u90fd\u8bb0\u7740\u5462\u3002"
        return _pack("conv_hobby_yes", u"Got it.", zh, "soul_friend_", None)
    if qtype == "confirm_village_greet":
        if _is_denial(text):
            zh = u"\u884c\uff0c\u90a3\u5148\u4e0d\u8fdb\u6751\u4e86\u3002"
            return _pack("conv_village_no", u"Skipping village.", zh, "soul_friend_", None)
        zh = random.choice([
            u"\u597d\uff0c\u8ddf\u7740\u6211\u8fc7\u53bb\u770b\u770b\u6751\u6c11\u3002",
            u"\u884c\uff0c\u53bb\u627e\u6751\u6c11\u3002\u522b\u88ab\u5751\u4e86\u3002",
        ])
        return _pack("conv_village_yes", u"Heading to villagers.", zh, "env_village_greet_", None)
    if qtype == "confirm_build":
        zh = u"\u6ee1\u610f\u5c31\u597d\uff0c\u4ee5\u540e\u60f3\u6539\u518d\u8bf4\u3002"
        return _pack("conv_build_yes", u"Glad you like it.", zh, "soul_friend_", None)
    if qtype == "confirm_more_items":
        act = action or (context or {}).get("last_action")
        if _is_denial(text):
            zh = u"\u597d\uff0c\u90a3\u5148\u4e0d\u8865\u4e86\u3002"
            return _pack("conv_more_no", u"Okay, not now.", zh, "soul_friend_", None)
        if act and act.get("type") == "give_item":
            zh = u"\u597d\uff0c\u518d\u7ed9\u4f60\u6765\u70b9\u3002"
            return _pack("conv_more_yes", u"More items.", zh, "followup_", act)
        zh = u"\u597d\uff0c\u8981\u518d\u6765\u70b9\u5417\uff1f\u8bf4\u5177\u4f53\u8981\u4ec0\u4e48\u3002"
        return _pack("conv_more_yes", u"Sure, what else?", zh, "soul_friend_", None)
    if qtype == "confirm_attack_villager":
        if _is_denial(text):
            ctx = context or {}
            ctx["villager_attack_allowed"] = False
            zh = u"\u884c\uff0c\u90a3\u5148\u4e0d\u6253\u6751\u6c11\u4e86\u3002"
            return _pack("conv_villager_no", u"Skipping villagers.", zh, "soul_friend_", None)
        ctx = context or {}
        ctx["villager_attack_allowed"] = True
        act = action or {"type": "attack_villager", "radius": 32}
        zh = u"\u597d\uff0c\u6751\u6c11\u4ea4\u7ed9\u6211\u3002"
        return _pack("conv_villager_yes", u"Attacking villagers.", zh, "combat_attack_villager_", act)
    if qtype == "kill_hostile" or (action and action.get("type") == "kill_hostile"):
        zh = random.choice([
            u"\u884c\uff0c\u9644\u8fd1\u602a\u7269\u6211\u6765\u6e05\u3002",
            u"\u6536\u5230\uff0c\u5468\u56f4\u602a\u7269\u4ea4\u7ed9\u6211\u3002",
            u"\u597d\uff0c\u7a0d\u7b49\uff0c\u6211\u628a\u9644\u8fd1\u6e05\u4e00\u6e05\u3002",
        ])
        act = action or {"type": "kill_hostile", "radius": 24}
        return _pack("conv_pending_clear", u"Clearing hostiles.", zh, None, act)
    if qtype == "build_shelter" or (action and action.get("type") == "build_shelter"):
        zh = random.choice([
            u"\u884c\uff0c\u6211\u5e2e\u4f60\u642d\u4e2a\u7b80\u5355\u907f\u96be\u6240\u3002",
            u"\u597d\uff0c\u90a3\u6211\u5f00\u59cb\u5efa\u4e86\u554a\u3002",
        ])
        act = action or {"type": "build_shelter", "material": "oak"}
        return _pack("conv_pending_build", u"Building shelter.", zh, None, act)
    if qtype == "offer_help":
        zh = u"\u597d\uff0c\u8bf4\u5177\u4f53\u70b9\u3002\u8981\u7269\u54c1\u3001\u6253\u602a\u8fd8\u662f\u76d6\u623f\uff1f"
        return _pack("conv_pending_help", u"What do you need?", zh, None, None)
    zh = u"\u597d\uff0c\u6536\u5230\u4e86\u3002"
    return _pack("conv_pending_yes", u"Got it.", zh, None, action)


def _pack(topic, en, zh, prefix, action):
    try:
        import verityBrain as brain
        return brain._pack(topic, en, zh, prefix, action)
    except Exception:
        return topic, en, zh, None, action


def _match_any(text, kws):
    for kw in kws:
        if kw in text:
            return True
    return False


def _u(text):
    if isinstance(text, unicode):
        return text
    try:
        return unicode(text)
    except Exception:
        return u""
