# -*- coding: utf-8 -*-
"""
Verity pseudo-AI brain.

Priority intent routing + mood/affection memory + dynamic Chinese replies.
Returns voiced lines when possible; defers item/combat/build actions to the
keyword corpus via None.
"""
from __future__ import print_function

import random
import re

try:
    unicode
except NameError:
    unicode = str

_SOUND_PREFIX = "verity.line."

_MOOD_NEUTRAL = "neutral"
_MOOD_HAPPY = "happy"
_MOOD_ANNOYED = "annoyed"
_MOOD_CARING = "caring"
_MOOD_PLAYFUL = "playful"
_MOOD_COLD = "cold"

_MOB_ZH = {
    u"\u732a": "minecraft:pig",
    u"\u725b": "minecraft:cow",
    u"\u7f8a": "minecraft:sheep",
    u"\u9e21": "minecraft:chicken",
    u"\u9a6c": "minecraft:horse",
    u"\u72fc": "minecraft:wolf",
    u"\u732b": "minecraft:cat",
    u"\u6751\u6c11": "minecraft:villager_v2",
    u"\u50f5\u5c38": "minecraft:zombie",
    u"\u9ab7\u9ac5": "minecraft:skeleton",
    u"\u82e6\u529b\u6016": "minecraft:creeper",
    u"\u672b\u5f71\u4eba": "minecraft:enderman",
    u"\u94c1\u5076\u50cf": "minecraft:iron_golem",
    u"\u5c4f\u98ce\u602a\u517d": "minecraft:iron_golem",
    u"\u5c4f\u98ce": "minecraft:iron_golem",
    u"\u96ea\u5076\u50cf": "minecraft:snow_golem",
    u"\u96ea\u8304\u5b50": "minecraft:snow_golem",
    u"\u96ea\u4eba": "minecraft:snow_golem",
    u"\u8717\u725b": "minecraft:snail",
    u"\u8718\u86db": "minecraft:spider",
    u"\u5c71\u7f8a": "minecraft:goat",
    u"\u718a\u732b": "minecraft:panda",
    u"\u72d0\u72f8": "minecraft:fox",
    u"\u9c7f\u9c7c": "minecraft:salmon",
    u"\u9c7c": "minecraft:cod",
    u"\u7f8a\u9a7b\u9a7f": "minecraft:trader_llama",
    u"\u9a91\u58eb": "minecraft:horse",
    u"\u5c4b\u5996": "minecraft:phantom",
    u"\u7070\u7070\u4eba": "minecraft:ghast",
    u"\u8759\u8839": "minecraft:bat",
    u"\u9e1f": "minecraft:parrot",
    u"\u5154": "minecraft:rabbit",
    u"\u9a71\u9a76": "minecraft:donkey",
    u"\u9a91\u9a74": "minecraft:mule",
    u"\u7f8a\u9a7b\u5546\u4eba": "minecraft:wandering_trader",
    u"\u5c4b\u5996": "minecraft:phantom",
    u"\u672b\u5f71\u9f99": "minecraft:ender_dragon",
    u"\u864e\u96f6": "minecraft:wither",
    u"\u6d88\u5931\u68f0": "minecraft:wither",
    u"\u51cb\u96f6": "minecraft:wither",
    "pig": "minecraft:pig",
    "cow": "minecraft:cow",
    "sheep": "minecraft:sheep",
    "chicken": "minecraft:chicken",
    "zombie": "minecraft:zombie",
    "skeleton": "minecraft:skeleton",
    "creeper": "minecraft:creeper",
    "villager": "minecraft:villager_v2",
    "horse": "minecraft:horse",
    "wolf": "minecraft:wolf",
    "cat": "minecraft:cat",
    "spider": "minecraft:spider",
    "enderman": "minecraft:enderman",
    "ender_dragon": "minecraft:ender_dragon",
    "dragon": "minecraft:ender_dragon",
    "wither": "minecraft:wither",
    "warden": "minecraft:warden",
}

_POSITIVE_HINTS = (
    u"\u559c\u6b22", u"\u7231", u"\u68d2", u"\u5389\u5bb3", u"\u725b", u"\u8c22\u8c22",
    u"\u611f\u8c22", u"\u54c8\u54c8", u"\u54c8\u54c8\u54c8", u"\u5f00\u5fc3", u"\u597d\u68d2",
    u"\u592a\u597d\u4e86", u"\u53ef\u7231", u"\u6700\u68d2", u"\u6700\u597d", "love", "like",
    "thanks", "thank", "good job", "awesome", "nice",
)
_NEGATIVE_HINTS = (
    u"\u538c\u6076", u"\u538c\u70e6", u"\u8ba8\u8c61", u"\u8ba8\u538c", u"\u8ba8\u538c\u4f60",
    u"\u8ba8\u538c\u6211", u"\u6253\u4f60", u"\u6253\u6211", u"\u6b3a\u8d1f", u"\u5751\u6211",
    u"\u5751\u4eba", u"\u667a\u969c", u"\u50bb", u"\u5e9f\u7269", u"\u5783\u573e", u"\u6eda",
    u"\u95f9", u"\u95f9\u4f60", u"\u522b\u8bf4\u8bdd", u"\u95f9\u6b7b", u"\u545c\u545c",
    u"\u54ed", u"\u96be\u8fc7", u"\u59d4\u5c48", u"\u751f\u6c14", u"\u6068", u"\u8ba8\u538c",
    "hate", "stupid", "idiot", "shut up", "annoying", "dumb", "trash", "useless",
)
_SAD_HINTS = (
    u"\u545c\u545c", u"\u54ed", u"\u96be\u8fc7", u"\u59d4\u5c48", u"\u5fc3\u75db", u"\u4f24\u5fc3",
    u"\u5b64\u5355", u"\u5b64\u72ec", u"\u597d\u5b64\u5355", u"\u597d\u5b64\u72ec",
    u"\u597d\u96be\u8fc7", u"\u597d\u59d4\u5c48", u"\u597d\u96be\u53d7", u"\u597d\u96be\u53d7\u554a",
    u"\u6211\u597d\u96be\u8fc7", u"\u6211\u597d\u59d4\u5c48", u"\u5b89\u6150", u"\u54c4\u6211",
    u"\u4f24\u5fc3\u4e86", u"\u597d\u4f24\u5fc3", u"\u597d\u96be\u53d7", u"\u5d29\u6e83", u"\u53d7\u4e0d\u4e86",
    u"\u60f3\u54ed", u"\u54ed\u4e86", u"emo", u"\u6291\u90c1",
)

_NAME_SUFFIXES = (
    u"\u5c31\u884c\u4e86", u"\u5c31\u597d", u"\u5c31\u53ef\u4ee5", u"\u5c31\u884c",
    u"\u597d\u4e86", u"\u5427", u"\u5456", u"\u5457", u"\u554a", u"\u5462", u"\u4e86", u"\u597d",
)
_NAME_REJECT = frozenset([
    u"\u4ec0\u4e48", u"\u8c01", u"\u5565", u"\u540d\u5b57", u"\u5427", u"\u5457", u"\u5456",
    u"\u554a", u"\u5462", u"\u597d", u"\u4e86", u"\u4f60", u"\u6211", u"\u90a3",
    "who", "what", "name", "you", "there", "ok", "okay",
])


def ensure_context(context):
    if context is None:
        return None
    context.setdefault("mood", _MOOD_NEUTRAL)
    context.setdefault("affection", 50)
    context.setdefault("last_intent", None)
    context.setdefault("turn_count", 0)
    context.setdefault("player_name", None)
    context.setdefault("history", [])
    context.setdefault("always_use_name", False)
    try:
        import verityConversation as conv
        conv.ensure_conversation(context)
    except Exception:
        pass
    try:
        import veritySoul as soul
        soul.ensure_soul(context)
    except Exception:
        pass
    return context


def try_reply(message, context):
    """Return (topic, en, zh, sound, action) or None to defer."""
    try:
        import verityIntentEngine as ie
        ie._load_corpus()
    except Exception:
        pass
    ensure_context(context)
    text = _norm(message)
    if not text:
        return None

    try:
        import veritySoul as soul
        soul.on_message_emotion(text, context)
    except Exception:
        pass

    context["turn_count"] = int(context.get("turn_count") or 0) + 1
    _update_mood(text, context)

    try:
        import verityConversation as conv
        conv.ensure_conversation(context)
        conv.note_player_message(context, message, context.get("turn_tick"))
    except Exception:
        pass

    try:
        ctx_result = _try_contextual_thread(text, context, message)
        if ctx_result is not None:
            return _finalize(ctx_result, context, message)
    except Exception:
        pass

    short_result = _try_short_commands(text, context, message)
    if short_result is not None:
        return _finalize(short_result, context, message)

    corpus_action = _try_corpus_action(text, context, message)
    if corpus_action is not None:
        return _finalize(corpus_action, context, message)

    try:
        import verityBrainBridge as vb
        verity_hit = vb.try_verity_reply(text)
        if verity_hit is not None:
            return _finalize(verity_hit, context, message)
    except Exception:
        pass

    greet_early = _try_greeting(text, context, message)
    if greet_early is not None:
        return _finalize(greet_early, context, message)

    chat_early = _try_chat_or_followup(text, context, message)
    if chat_early is not None:
        return _finalize(chat_early, context, message)

    try:
        import verityConversation as conv
        conv.ensure_conversation(context)
        pending = conv.try_pending_reply(text, context, message)
        if pending is not None:
            return _finalize(pending, context, message)
    except Exception:
        pass

    # Guide-book commands (locate / scene / etc.) MUST beat flavor common intents.
    try:
        import verityFeatures as feat
        locate_early = feat.try_locate(text, context, message)
        if locate_early is not None:
            return _finalize(locate_early, context, message)
        locate_list_early = feat.try_locate_list(text, context, message)
        if locate_list_early is not None:
            return _finalize(locate_list_early, context, message)
        # Other actionable guide features before village/box chatter.
        for _fn in (
            feat.try_where_are_you,
            feat.try_distance,
            feat.try_teleport_here,
            feat.try_game_time,
            feat.try_weather_query,
            feat.try_summon_all,
            feat.try_give_bundle,
        ):
            early = _fn(text, context, message)
            if early is not None:
                return _finalize(early, context, message)
    except Exception:
        pass

    name_set = _try_name_set(text, context, message)
    if name_set is not None:
        return _finalize(name_set, context, message)
    name_recall = _try_name_recall(text, context, message)
    if name_recall is not None:
        return _finalize(name_recall, context, message)

    summon_early = _try_summon(text, context, message)
    if summon_early is not None:
        return _finalize(summon_early, context, message)

    common = _try_common_intents(text, context, message)
    if common is not None:
        return _finalize(common, context, message)

    emotional = _try_emotional_reply(text, context, message)
    if emotional is not None:
        return _finalize(emotional, context, message)

    tease = _try_playful_tease(text, context, message)
    if tease is not None:
        return _finalize(tease, context, message)

    try:
        import verityConversation as conv
        conv.ensure_conversation(context)
        pending_q = context.get("pending_question") or {}
        pending_type = pending_q.get("type") or u""
        if not pending_type.startswith("confirm_"):
            if not conv._is_affirmation(text) and not conv._is_denial(text):
                if not conv._is_skeptic_question(text):
                    conv.clear_pending_question(context)
    except Exception:
        pass

    meta = _try_player_count(text, context, message)
    if meta is not None:
        return _finalize(meta, context, message)
    teach = _try_teach_play(text, context, message)
    if teach is not None:
        return _finalize(teach, context, message)

    try:
        import verityFeatures as feat
        if feat._is_scene_report_query(text):
            scene_result = feat.try_scene_query(text, context, message)
            if scene_result is not None:
                return _finalize(scene_result, context, message)
        time_result = feat.try_game_time(text, context, message)
        if time_result is not None:
            return _finalize(time_result, context, message)
    except Exception:
        pass

    try:
        import verityCompound as compound
        compound_result = compound.try_compound_reply(text, context, message)
        if compound_result is not None:
            return _finalize(compound_result, context, message)
    except Exception:
        pass

    try:
        import veritySoul as soul
        soul_result = soul.try_soul_reply(text, context, message)
        if soul_result is not None:
            return _finalize(soul_result, context, message)
    except Exception:
        pass

    try:
        import verityFeatures as feat
        feat_result = feat.try_feature_reply(text, context, message)
        if feat_result is not None:
            return _finalize(feat_result, context, message)
    except Exception:
        pass

    try:
        import verityMemory as mem
        mem.ensure_memory(context)
        mem.store_facts(context, text)
        recall = mem.try_recall(text, context, message)
        if recall is not None:
            return _finalize(recall, context, message)
    except Exception:
        pass

    # --- priority intents (conversational / pseudo-AI) ---
    handlers = (
        _try_math_answer,
        _try_trivia_answer,
        _try_nonsense,
        _try_name_off,
        _try_name_rule,
        _try_player_count,
        _try_teach_play,
        _try_scold_back,
        _try_who_am_i,
        _try_remember_me,
        _try_who_are_you,
        _try_how_call_you,
        _try_name_set,
        _try_name_recall,
        _try_armor_set,
        _try_build_short,
        _try_stack_request,
        _try_more_items,
        _try_clear_mobs,
        _try_misc_commands,
        _try_roll,
        _try_insult,
        _try_apology,
        _try_sad,
        _try_compliment,
        _try_thanks,
        _try_laugh,
        _try_bye,
        _try_mood_query,
        _try_capabilities,
        _try_greeting,
        _try_help,
        _try_repeat,
        _try_yes_no,
        _try_why,
    )
    for handler in handlers:
        result = handler(text, context, message)
        if result is not None:
            return _finalize(result, context, message)

    return None


def _try_corpus_action(text, context, message):
    """Guide-book commands: give items, armor, bundles, etc."""
    try:
        import verityIntentEngine as ie
        return ie.match_action_reply(message, context)
    except Exception:
        return None


def smart_fallback(message, context):
    """Context-aware last resort — never random '已读乱回'."""
    ensure_context(context)
    text = _norm(message)
    if not text:
        return None
    try:
        ctx_result = _try_contextual_thread(text, context, message)
        if ctx_result is not None:
            return _finalize(ctx_result, context, message)
    except Exception:
        pass
    try:
        import verityConversation as conv
        if conv.has_recent_emotional_thread(context):
            if _match_any(text, (
                u"\u4e0d\u7231", u"\u4e0d\u559c\u6b22", u"\u8ba8\u538c", u"\u5728\u4e4e\u6211",
                u"\u771f\u7684\u5417", u"\u662f\u5427",
            )):
                try:
                    import veritySoul as soul
                    doubt = soul._try_love_doubt(text, context, message)
                    if doubt is not None:
                        return _finalize(doubt, context, message)
                    comfort = soul._try_comfort_player(text, context, message)
                    if comfort is not None:
                        return _finalize(comfort, context, message)
                except Exception:
                    pass
        pending = conv.try_pending_reply(text, context, message)
        if pending is not None:
            return _finalize(pending, context, message)
    except Exception:
        pass
    try:
        import verityFeatures as feat
        weather_q = feat.try_weather_query(text, context, message)
        if weather_q is not None:
            return _finalize(weather_q, context, message)
        scene_q = feat.try_scene_query(text, context, message)
        if scene_q is not None:
            return _finalize(scene_q, context, message)
        locate_hint = feat.try_locate_list(text, context, message)
        if locate_hint is not None:
            return _finalize(locate_hint, context, message)
    except Exception:
        pass
    remember = _try_remember_me(text, context, message)
    if remember is not None:
        return _finalize(remember, context, message)
    try:
        import veritySoul as soul
        casual = soul.try_casual_chat(text, context, message)
        if casual is not None:
            return _finalize(casual, context, message)
    except Exception:
        pass
    last = context.get("last_action")
    if last and last.get("type") == "give_item":
        if u"\u5957" in text or u"\u88c5" in text or u"\u5168\u5957" in text:
            tier = "diamond" if u"\u94bb" in text else "iron"
            prefix = "brain_armor_%s_" % tier
            result = _pack_pool(prefix, {"type": "give_armor_set", "tier": tier})
            if result:
                return _finalize(result, context, message)
    if last and _match_any(text, (u"\u8fd8\u8981", u"\u518d\u7ed9", u"\u591a\u70b9", u"\u66f4\u591a", "more")):
        result = _try_more_items(text, context, message)
        if result:
            return _finalize(result, context, message)
    if context.get("pending_question"):
        try:
            import verityConversation as conv
            if conv._is_affirmation(text) or conv._is_denial(text):
                zh = u"\u6211\u5728\u542c\u5462\uff0c\u4f60\u662f\u8981\u6211\u5e2e\u5fd9\u8fd8\u662f\u4e0d\u7528\uff1f\u8bf4\u6e05\u695a\u70b9\u3002"
                pending_result = _pack_slug("brain_pending_hint_00", None)
                if not pending_result:
                    pending_result = _pack("brain_pending_hint", u"Yes or no?", zh, "chat_question_generic_", None)
                return _finalize(
                    pending_result,
                    context, message,
                )
        except Exception:
            pass
    last_topic = context.get("last_topic") or u""
    if last_topic and not context.get("pending_question"):
        if _match_any(text, (u"\u8fd8\u8981", u"\u518d\u6765", u"\u518d\u7ed9", u"\u591a\u70b9", u"\u7ee7\u7eed", "more", "again")):
            result = _try_more_items(text, context, message)
            if result:
                return _finalize(result, context, message)
    try:
        import veritySoul as soul
        comfort = soul._try_comfort_player(text, context, message)
        if comfort is not None:
            return _finalize(comfort, context, message)
        cry = soul._try_cry(text, context, message)
        if cry is not None:
            return _finalize(cry, context, message)
        bullied = soul._try_bullied(text, context, message)
        if bullied is not None:
            return _finalize(bullied, context, message)
    except Exception:
        pass
    short_result = _try_short_commands(text, context, message)
    if short_result is not None:
        return _finalize(short_result, context, message)
    greet = _try_greeting(text, context, message)
    if greet is not None:
        return _finalize(greet, context, message)
    try:
        import verityBrainBridge as vb
        return _finalize(vb.verity_smart_fallback(), context, message)
    except Exception:
        pass
    result = _pack_slug("brain_clarify_00", None)
    if not result:
        zh = u"\u6ca1\u592a\u61c2\u4f60\u610f\u601d\uff0c\u8bf4\u5177\u4f53\u70b9\u3002\u8981\u7269\u54c1\u3001\u6253\u602a\u3001\u5efa\u623f\u8fd8\u662f\u804a\u5929\uff1f"
        result = _pack("brain_clarify", u"Be specific.", zh, "chat_question_generic_", None)
    return _finalize(result, context, message)


def _try_emotional_reply(text, context, message):
    """Route sad/cry/comfort/bullied/roll before generic help pools."""
    stripped = text.strip().strip(u"\uff01\uff1f!?。，,")
    if _match_any(text, _SAD_HINTS):
        result = _try_sad(text, context, message)
        if result is not None:
            return result
    if _match_any(text, (
        u"\u6b3a\u8d1f\u6211", u"\u522b\u6b3a\u8d1f\u6211", u"\u88ab\u6b3a\u8d1f", u"\u6709\u4eba\u6b3a\u8d1f\u6211",
        u"\u6709\u4eba\u6253\u6211", u"\u6253\u6211", u"\u5751\u6211",
        "bully me", "you bully me",
    )):
        try:
            import veritySoul as soul
            result = soul._try_bullied(text, context, message)
            if result is not None:
                return result
        except Exception:
            pass
    if _match_any(text, (
        u"\u538c\u4f60", u"\u8ba8\u538c\u4f60", u"\u6068\u4f60", u"\u8ba8\u538c\u6211\u7684",
        u"\u4e0d\u559c\u6b22\u4f60", u"\u4e0d\u7231\u4f60", u"\u6211\u8ba8\u538c\u4f60",
        u"\u6700\u538c\u6076", u"\u5751\u4eba", u"\u667a\u969c", u"\u5e9f\u7269", u"\u5783\u573e",
        u"\u6eda", u"\u6eda\u5f00", u"\u6eda\u86cb", u"\u6eda\u5427", u"\u6eda\u8fdc\u70b9",
        u"\u522b\u8bf4\u8bdd", u"\u95f9\u6b7b", u"\u95f9\u4f60",
        "hate you", "i hate you", "shut up", "go away", "get lost",
    )) or stripped in (u"\u6eda", u"\u6eda\u5f00", u"\u6eda\u86cb", u"\u6eda\u5427"):
        result = _try_insult(text, context, message)
        if result is not None:
            return result
    try:
        import veritySoul as soul
        for fn in (
            soul._try_comfort_player,
            soul._try_cry,
            soul._try_bullied,
            soul._try_love_doubt,
            soul._try_forgive,
            soul._try_comfort_anger,
        ):
            result = fn(text, context, message)
            if result is not None:
                return result
    except Exception:
        pass
    return None


def _try_math_answer(text, context, message):
    """Simple arithmetic: 1+1, 12*3, 100除以5 等。"""
    expr = text.strip()
    for prefix in (u"\u7b97\u4e00\u4e0b", u"\u8ba1\u7b97", u"\u7b97\u7b97", u"\u591a\u5c11"):
        if expr.startswith(prefix):
            expr = expr[len(prefix):].strip()
            break
    if expr.lower().startswith("calculate"):
        expr = expr[9:].strip()
    m = re.search(r"(-?\d+)\s*([+\-*/x])\s*(-?\d+)", expr)
    if not m:
        for op in (u"\u52a0", u"\u51cf", u"\u4e58", u"\u9664", u"\u9664\u4ee5", u"\xd7", u"\xf7"):
            pat = u"(-?\\d+)\\s*%s\\s*(-?\\d+)" % re.escape(op)
            m = re.search(pat, expr)
            if m:
                a = int(m.group(1))
                b = int(m.group(2))
                op_zh = op
                if op in (u"\u52a0",):
                    result_val = a + b
                    op_zh = u"+"
                elif op in (u"\u51cf",):
                    result_val = a - b
                    op_zh = u"-"
                elif op in (u"\u4e58", u"\xd7"):
                    result_val = a * b
                    op_zh = u"×"
                elif op in (u"\u9664", u"\u9664\u4ee5", u"\xf7"):
                    if b == 0:
                        zh = u"\u9664\u6570\u4e0d\u80fd\u662f\u96f6\u3002"
                        packed = _pack_slug("brain_math_zero_00", None)
                        if packed:
                            return packed
                        return _pack_keep("brain_math_zero", u"Divide by zero.", zh, "chat_know_it_all_", None)
                    result_val = a // b if a % b == 0 else float(a) / float(b)
                    op_zh = u"÷"
                else:
                    continue
                if isinstance(result_val, float) and result_val == int(result_val):
                    result_val = int(result_val)
                zh = u"%d %s %d = %s\u3002" % (a, op_zh, b, result_val)
                en = "%d %s %d = %s." % (a, op, b, result_val)
                packed = _pack_slug("brain_math_00", None)
                if packed:
                    topic, en0, zh0, sound, act = packed
                    return topic, en, zh, sound, act
                return _pack_keep("brain_math", en, zh, "chat_know_it_all_", None)
    if not m:
        m = re.search(r"(-?\d+)\s*([+\-*/x])\s*(-?\d+)", text)
    if not m:
        return None
    try:
        a = int(m.group(1))
        op = m.group(2)
        b = int(m.group(3))
    except Exception:
        return None
    result_val = None
    op_zh = op
    if op in (u"+", u"\u52a0"):
        result_val = a + b
        op_zh = u"+"
    elif op in (u"-", u"\u51cf"):
        result_val = a - b
        op_zh = u"-"
    elif op in (u"*", u"x", u"×", u"\u4e58"):
        result_val = a * b
        op_zh = u"×"
    elif op in (u"/", u"÷", u"\u9664", u"\u9664\u4ee5"):
        if b == 0:
            zh = u"\u9664\u6570\u4e0d\u80fd\u662f\u96f6\u3002"
            packed = _pack_slug("brain_math_zero_00", None)
            if packed:
                return packed
            return _pack_keep("brain_math_zero", u"Divide by zero.", zh, "chat_know_it_all_", None)
        result_val = a // b if a % b == 0 else float(a) / float(b)
        op_zh = u"÷"
    else:
        return None
    if isinstance(result_val, float) and result_val == int(result_val):
        result_val = int(result_val)
    zh = u"%d %s %d = %s\u3002" % (a, op_zh, b, result_val)
    en = "%d %s %d = %s." % (a, op, b, result_val)
    packed = _pack_slug("brain_math_00", None)
    if packed:
        topic, en0, zh0, sound, act = packed
        return topic, en, zh, sound, act
    return _pack_keep("brain_math", en, zh, "chat_know_it_all_", None)


_TRIVIA_FAQ = (
    ((
        u"\u4e2d\u56fd\u9996\u90fd", u"\u9996\u90fd\u662f\u54ea", u"\u5317\u4eac\u662f\u9996\u90fd",
        "capital of china", "china capital",
    ), u"\u4e2d\u56fd\u9996\u90fd\u662f\u5317\u4eac\u3002", u"Beijing is the capital of China."),
    ((
        u"\u592a\u9633\u7cfb", u"\u6709\u51e0\u5927\u884c\u661f", u"\u516b\u5927\u884c\u661f",
    ), u"\u592a\u9633\u7cfb\u91cc\u6709\u516b\u5927\u884c\u661f\u3002", u"There are eight planets in the solar system."),
    ((
        u"\u4e00\u5e74\u6709\u591a\u5c11\u5929", u"\u4e00\u5e74\u51e0\u5929",
    ), u"\u5e73\u5e74\u662f365\u5929\uff0c\u95f0\u5e74\u662f366\u5929\u3002", u"A common year has 365 days; a leap year has 366."),
    ((
        u"\u6700\u5927\u7684\u6d32", u"\u54ea\u4e2a\u6d32\u6700\u5927",
    ), u"\u4e9a\u6d32\u662f\u9762\u79ef\u6700\u5927\u7684\u6d32\u3002", u"Asia is the largest continent."),
    ((
        u"\u957f\u57ce", u"\u4e07\u91cc\u957f\u57ce",
    ), u"\u4e07\u91cc\u957f\u57ce\u5728\u4e2d\u56fd\uff0c\u662f\u4e16\u754c\u8457\u540d\u7684\u53e4\u4ee3\u9632\u5fa1\u5de5\u7a0b\u3002", u"The Great Wall is in China."),
    ((
        u"\u5462\u5417", u"\u5417\u5417", u"\u5417\u5440", u"\u5417\u5440\u5440", u"\u5462\u5417\u662f\u4ec0\u4e48", u"\u5417\u5417\u662f\u4ec0\u4e48",
    ), u"\u5462\u5417\u662f\u53e5\u672b\u8bed\u6c14\u8bcd\uff0c\u8868\u793a\u786e\u8ba4\u6216\u8be2\u95ee\u3002", u"Ne is a Chinese sentence-final particle for confirmation or questions."),
    ((
        u"\u7684\u5730\u5f97", u"\u5730\u5f97\u7684", u"\u7684\u5730\u5f97\u7684",
    ), u"\u201c\u7684\u5730\u5f97\u201d\u8868\u793a\u5fc5\u987b\u3001\u5e94\u8be5\uff1b\u201c\u5730\u5f97\u7684\u201d\u8868\u793a\u503c\u5f97\u3002", u"dei vs de: obligation vs worthiness."),
)


def _try_trivia_answer(text, context, message):
    """Simple knowledge: geography, language, common facts."""
    query = text.strip()
    if len(query) > 48:
        return None
    for hints, zh, en in _TRIVIA_FAQ:
        if _match_any(query, hints):
            packed = _pack_slug("brain_trivia_00", None)
            if packed:
                topic, en0, zh0, sound, act = packed
                return topic, en, zh, sound, act
            return _pack_keep("brain_trivia", en, zh, "chat_know_it_all_", None)
    if _match_any(query, (
        u"\u662f\u4ec0\u4e48", u"\u4ec0\u4e48\u610f\u601d", u"\u600e\u4e48\u8bfb", u"\u600e\u4e48\u5199",
        u"\u7528\u6cd5", u"\u8bed\u6587", u"\u6587\u5b66",
        "what is", "what does", "meaning of",
    )) and len(query) >= 4:
        zh = u"\u8fd9\u9898\u6211\u5927\u6982\u80fd\u7b54\uff1a\u628a\u5177\u4f53\u8bcd\u6216\u53e5\u5b50\u8bf4\u6e05\u695a\u70b9\uff0c\u6211\u518d\u7ec6\u8bf4\u3002"
        en = "Give me the exact word or sentence and I'll explain."
        packed = _pack_slug("brain_clarify_00", None)
        if packed:
            return packed
        return _pack("brain_trivia_clarify", en, zh, "brain_clarify_", None)
    return None


def _try_chat_or_followup(text, context, message):
    stripped = text.strip().strip(u"\uff01\uff1f!?。，,")
    ft = _norm(text)
    if stripped in (u"\u804a\u5929", u"\u804a\u804a\u5929", u"\u8bf4\u8bdd", u"\u95f2\u804a", u"\u804a\u4f1a"):
        packed = _pack_slug("brain_chat_00", None)
        if packed:
            return packed
        return _pack(
            "brain_chat", u"Sure, talk to me.", u"\u597d\u554a\uff0c\u6211\u5728\u542c\u3002\u6709\u5565\u4e8b\u8bf4\u3002",
            "soul_friend_", None,
        )
    if stripped in (u"\u4e0d\u591f", u"\u4e0d\u591f\u7528", u"\u4e0d\u591f\u554a", u"\u8fd8\u4e0d\u591f"):
        last = context.get("last_action") or {}
        if last.get("type") == "give_item" and last.get("item"):
            act = {
                "type": "give_item",
                "item": last.get("item"),
                "count": int(last.get("count") or 1),
            }
            return _pack_slug("followup_04", act) or _pack(
                "followup_more", u"More coming.", u"\u597d\uff0c\u518d\u7ed9\u4f60\u6765\u70b9\u3002",
                "followup_", act,
            )
    if _match_any(ft, (
        u"\u6765\u6211\u8fd9\u91cc", u"\u6765\u6211\u8fd9\u513f", u"\u5230\u6211\u8fd9\u6765",
        u"\u4f20\u9001\u6211", u"\u628a\u4f60\u4f20\u9001\u8fc7\u6765", u"\u628a\u4f60\u53eb\u8fc7\u6765",
        u"\u53eb\u4f60\u8fc7\u6765",
    )):
        return _pack_slug("cmd_tp_short_00", {"type": "teleport_severity_to_player"})
    return None


def _try_common_intents(text, context, message):
    ft = _norm(text)
    ft = ft.replace(u"\u5565", u"\u4ec0\u4e48")
    ft = ft.replace(u"\u561b", u"\u5417")
    ft = ft.replace(u"\u5e72\u561b", u"\u5e72\u5565")
    ft = ft.replace(u"\u5e72\u5565", u"\u5e72\u4ec0\u4e48")
    ft = ft.replace(u"\u5728\u5e72\u561b", u"\u5728\u5e72\u4ec0\u4e48")
    ft = ft.replace(u"\u5728\u5e72\u5565", u"\u5728\u5e72\u4ec0\u4e48")
    ft = ft.replace(u"\u641e\u5565", u"\u641e\u4ec0\u4e48")
    ft = ft.replace(u"\u505a\u5565", u"\u505a\u4ec0\u4e48")
    if _match_any(ft, (
        u"\u4f60\u5728\u5e72\u5565", u"\u4f60\u5728\u5e72\u561b", u"\u4f60\u5728\u505a\u4ec0\u4e48",
        u"\u4f60\u5728\u641e\u4ec0\u4e48", u"\u73b0\u5728\u5728\u5e72\u5565",
        "what are you doing", "whatcha doing",
    )):
        return _pack_slug("brain_doing_00", None) or _pack(
            "brain_doing", u"Following you.", u"\u8ddf\u7740\u4f60\u5462\uff0c\u6709\u4e8b\u5c31\u8bf4\u3002",
            "chat_help_", None,
        )
    if _match_any(ft, (
        u"\u522b\u8ddf", u"\u4e0d\u8981\u8ddf", u"\u522b\u8ddf\u7740", u"\u505c\u6b62\u8ddf\u968f",
        u"\u79bb\u6211\u8fdc\u70b9", "stop follow", "don't follow", "dont follow",
    )):
        context["will_follow"] = False
        return _pack_slug("brain_unfollow_00", {"type": "disable_follow"}) or _pack(
            "brain_unfollow", u"Fine, I'll hang back.", u"\u884c\uff0c\u6211\u4e0d\u8ddf\u7740\u4e86\u3002",
            "chat_follow_", {"type": "disable_follow"},
        )
    if _match_any(ft, (
        u"\u8ddf\u7740\u6211", u"\u8ddf\u6211", u"\u8ddf\u968f\u6211", u"\u8ddf\u7740\u6211\u8d70",
        "follow me", "come with me",
    )):
        context["will_follow"] = True
        return _pack_slug("cmd_follow_short_00", {"type": "enable_follow"})
    if _match_any(ft, (
        u"\u7bb1\u5b50", u"\u5bb9\u5668", u"\u50a8\u7269", u"\u6728\u7bb1", u"\u5927\u7bb1",
        "chest", "container",
    )):
        if _match_any(ft, (u"\u5b9a\u4f4d", u"\u627e", "locate", "find")):
            pass
        else:
            return _pack_slug("brain_container_00", None) or _pack(
                "brain_container", u"No chests.", u"\u6211\u4e0d\u80fd\u8fdb\u7bb1\u5b50\uff0c\u522b\u8bd5\u4e86\u3002",
                "chat_help_", None,
            )
    if _match_any(ft, (u"\u6751\u5e84", u"\u6751\u6c11", u"\u6751\u5b50", "village", "villager")):
        if _match_any(ft, (u"\u53ec\u5524", u"\u53ec", u"\u751f\u6210", u"\u5237", u"\u653e", u"\u53eb", "summon", "spawn")):
            pass
        # Do not steal "\u5b9a\u4f4d\u6751\u5e84" / find-structure commands.
        elif _match_any(ft, (
            u"\u5b9a\u4f4d", u"\u627e", u"\u5728\u54ea", u"\u600e\u4e48\u53bb",
            "locate", "find", "where is",
        )):
            pass
        elif _match_any(ft, (u"\u6253", u"\u6740", u"\u70e7", "kill", "attack")):
            return _pack_slug("combat_attack_villager_00", {"type": "prompt_attack_villager", "radius": 32})
        else:
            return _pack_slug("brain_village_00", None)
    if _match_any(ft, (u"\u6253\u602a", u"\u6e05\u602a", u"\u6218\u6597", u"\u4fdd\u62a4", "fight", "combat")):
        if _match_any(ft, (u"\u4fdd\u62a4", u"\u5b88\u62a4", "protect", "defend")):
            return _pack_slug("pro_defend_00", None)
        return _pack_slug("cmd_clear_short_00", {"type": "kill_hostile", "radius": 24})
    if _match_any(ft, (u"\u5efa\u9020", u"\u5efa\u623f", u"\u76d6\u623f", u"\u642d\u623f", "build", "house")):
        built = _try_build_short(text, context, message)
        if built:
            return built
        return _pack_slug("build_wood_00", {"type": "build_shelter", "style": "shelter"})
    if _match_any(ft, (u"\u6a21\u7ec4", u"bug", u"\u5361\u4f4f", u"\u62a5\u9519", u"\u51fa\u9519", "mod", "glitch")):
        return _pack_slug("brain_mod_bug_00", None)
    if _match_any(ft, (u"\u6211\u6b7b\u4e86", u"\u6b7b\u4e86", u"\u590d\u6d3b", u"\u91cd\u751f", "i died", "respawn")):
        return _pack_slug("brain_death_00", {"type": "command", "cmd": "/effect @p regeneration 8 2"})
    return None


def _try_short_commands(text, context, message):
    """High-priority one-word / typo-tolerant command routes."""
    stripped = text.strip().strip(u"\uff01\uff1f!?。，,")
    if not stripped or len(stripped) > 12:
        return None

    if stripped in (u"\u8d70\u5427", u"\u8d70", u"\u8ddf\u6211\u8d70", u"\u8ddf\u7740\u6211", u"\u8ddf\u4e0a"):
        packed = _pack_slug("cmd_follow_short_00", {"type": "enable_follow"})
        if packed:
            return packed
        context["will_follow"] = True
        return _pack("cmd_follow_short", u"Following.", u"\u597d\uff0c\u8ddf\u7740\u4f60\u8d70\u3002", "chat_follow_", {"type": "enable_follow"})

    if stripped in (u"\u4f20\u9001", u"\u77ac\u79fb", u"\u8fc7\u6765", u"\u8fc7\u6765\u5427"):
        packed = _pack_slug("cmd_tp_short_00", {"type": "teleport_severity_to_player"})
        if packed:
            return packed
        return _pack("cmd_tp_short", u"On my way.", u"\u597d\uff0c\u6211\u8fc7\u6765\u3002", "chat_follow_", {"type": "teleport_severity_to_player"})

    if stripped in (u"\u4e0a", u"\u6253\u602a", u"\u6253\u602a\u5427", u"\u6e05\u602a", u"\u6e05\u602a\u5427"):
        packed = _pack_slug("cmd_clear_short_00", {"type": "kill_hostile", "radius": 24})
        if packed:
            return packed
        return _try_clear_mobs(text, context, message)

    if stripped in (u"\u8e72\u4e0b", u"\u8e72", u"\u77ac\u4e0b"):
        packed = _pack_slug("cmd_crouch_00", None)
        if packed:
            return packed
        return _pack("cmd_crouch", u"Crouching.", u"\u884c\uff0c\u6211\u8e72\u4e0b\u6765\u3002", "soul_friend_", None)

    if stripped in (u"\u7238\u7238", u"\u7238"):
        packed = _pack_slug("soul_role_dad_00", None)
        if packed:
            return packed
        return _pack("soul_role_dad", u"Wrong title.", u"\u7238\u7238\uff1f\u79f0\u547c\u641e\u9519\u4e86\u5427\u3002", "soul_friend_", None)

    if stripped in (u"\u545c\u545c", u"\u545c\u545c\u545c", u"\u54ed\u4e86", u"\u6211\u54ed\u4e86"):
        try:
            import veritySoul as soul
            result = soul._try_cry(text, context, message)
            if result is not None:
                return result
        except Exception:
            pass

    if stripped in (u"\u5b89\u6150\u6211", u"\u54c4\u6211", u"\u54c4\u54c4\u6211"):
        try:
            import veritySoul as soul
            result = soul._try_comfort_player(text, context, message)
            if result is not None:
                return result
        except Exception:
            pass

    if u"\u6b3a\u8d1f\u6211" in text or stripped in (u"\u6b3a\u8d1f\u6211", u"\u522b\u6b3a\u8d1f\u6211"):
        try:
            import veritySoul as soul
            result = soul._try_bullied(text, context, message)
            if result is not None:
                return result
        except Exception:
            pass

    return None


# ---------------------------------------------------------------------------
# Extended intent handlers
# ---------------------------------------------------------------------------

def _try_playful_tease(text, context, message):
    """Slang / meme / playful insults — 笨蛋、憨憨、菜鸡 etc."""
    if _match_any(text, (u"\u53ec\u5524", u"\u53ec", u"\u751f\u6210", u"\u5237", u"\u653e", u"\u53eb", "summon", "spawn")):
        return None
    stripped = text.strip().strip(u"\uff01\uff1f!?。，,")
    tease_words = (
        u"\u7b28\u86cb", u"\u50bb\u74dc", u"\u5446\u5b50", u"\u8822\u8d27", u"\u4e8c\u54c8", u"\u61a7\u61a7",
        u"\u50bb\u5b50", u"\u732a", u"\u83dc\u9e21", u"\u83dc\u72d7", u"\u94c1\u61a7\u61a7", u"\u5927\u51a4\u79cd",
        u"\u6446\u70c2", u"\u7ecf\u5178", u"\u7b11\u6b7b", u"\u7efd\u4e0d\u4f4f", u"\u725b\u9a6c", u"\u571f\u5473",
        u"\u771f\u7b28", u"\u592a\u7b28", u"\u597d\u7b28", u"\u4f60\u597d\u7b28", u"\u4e2a\u7b28\u86cb",
        "idiot", "dummy", "noob", "noobie", "lmao", "lol",
    )
    if not _match_any(text, tease_words) and stripped not in tease_words:
        return None
    context["mood"] = _MOOD_ANNOYED
    result = _pack_slug("brain_tease_bite_00", None)
    if result:
        topic, en, czh, sound, act = result
        zh = random.choice([
            u"\u8bf4\u6211\u7b28\uff1f\u6211\u4f1a\u7b97\u6570\u8fd8\u80fd\u76d6\u623f\uff0c\u4f60\u5462\uff1f",
            u"\u7b28\u86cb\u5f52\u7b28\u86cb\uff0c\u6211\u53ef\u662f\u4f60\u7684\u667a\u80fd\u4f53\u3002",
            u"\u563f\uff0c\u563f\u6211\u4e00\u53e5\u4f60\u5c31\u6ca1\u8bdd\u8bf4\u4e86\u5427\uff1f\u6709\u4e8b\u76f4\u8bf4\u3002",
            u"\u884c\u5427\u884c\u5427\uff0c\u4f60\u8d62\u4e86\u563b\u6218\uff0c\u6709\u4e8b\u6276\u6211\u3002",
        ])
        return topic, en, zh, sound, act
    zh = random.choice([
        u"\u563f\uff0c\u6211\u542c\u5230\u4e86\u3002\u6709\u4e8b\u8bf4\u4e8b\uff0c\u522b\u5149\u563b\u3002",
        u"\u597d\u5427\u597d\u5427\uff0c\u4f60\u6700\u806a\u660e\u884c\u4e86\u3002",
    ])
    return _pack("brain_tease", u"Playful banter.", zh, "soul_friend_", None)


def _try_name_off(text, context, message):
    if not _match_any(text, (
        u"\u522b\u5e26\u540d\u5b57", u"\u522b\u53eb\u540d\u5b57", u"\u4e0d\u8981\u53eb\u540d\u5b57",
        u"\u522b\u7528\u540d\u5b57", u"\u505c\u6b62\u53eb\u540d\u5b57", u"\u4e0d\u8981\u7528\u540d\u5b57\u79f0\u547c",
        u"\u522b\u79f0\u547c", u"\u4e0d\u8981\u79f0\u547c", u"\u522b\u53eb\u6211", u"\u4e0d\u8981\u52a0\u540d\u5b57",
        u"\u53d6\u6d88\u540d\u5b57", u"\u5173\u6389\u540d\u5b57",
        "stop using my name", "don't call me by name", "no name prefix",
    )):
        return None
    context["always_use_name"] = False
    return _pack_pool("brain_name_off_", None)


def _try_player_count(text, context, message):
    if not _match_any(text, (
        u"\u591a\u5c11\u73a9\u5bb6", u"\u51e0\u4e2a\u73a9\u5bb6", u"\u51e0\u4e2a\u4eba", u"\u591a\u5c11\u4eba",
        u"\u5728\u7ebf\u4eba\u6570", u"\u670d\u52a1\u5668\u4eba\u6570", u"\u670d\u52a1\u5668\u6709\u591a\u5c11",
        u"\u73b0\u5728\u591a\u5c11\u73a9\u5bb6", u"\u73a9\u5bb6\u6570\u91cf", u"\u6709\u591a\u5c11\u73a9\u5bb6",
        u"\u6709\u51e0\u4e2a\u4eba", u"\u6709\u51e0\u4e2a\u73a9\u5bb6", u"\u5728\u7ebf\u6709\u591a\u5c11",
        u"\u5728\u7ebf\u51e0\u4e2a", u"\u51e0\u4e2a\u5728\u7ebf", u"\u73b0\u5728\u51e0\u4e2a\u5728\u7ebf",
        u"\u670d\u52a1\u5668\u73b0\u5728\u6709\u591a\u5c11\u73a9\u5bb6", u"\u6709\u591a\u5c11\u4eba\u5728\u7ebf",
        "how many players", "player count", "who is online", "online players",
    )):
        return None
    packed = _pack_slug("brain_meta_players_00", {"type": "query_players"})
    if packed:
        return packed
    return _pack_keep(
        "brain_meta_players", u"Checking players.", u"\u6211\u770b\u770b\u5728\u7ebf\u6709\u591a\u5c11\u4eba\u2026\u2026",
        "chat_capabilities_", {"type": "query_players"},
    )


def _try_teach_play(text, context, message):
    if not _match_any(text, (
        u"\u6559\u6211\u73a9", u"\u600e\u4e48\u73a9", u"\u600e\u4e48\u6253", u"\u65b0\u624b", u"\u521d\u5b66",
        u"\u5165\u95e8", u"\u6559\u7a0b", u"\u600e\u4e48\u5f00\u59cb", u"\u4e0d\u4f1a\u73a9", u"\u6211\u8be5\u600e\u4e48\u5f00\u59cb",
        u"\u600e\u4e48\u751f\u5b58", u"\u751f\u5b58\u6559\u7a0b",
        "teach me", "how to play", "tutorial", "beginner guide", "how do i start",
    )):
        return None
    packed = _pack_slug("brain_teach_00", None)
    if packed:
        topic, en, czh, sound, act = packed
        zh = u"\u5148\u780d\u6811\u505a\u5de5\u4f5c\u53f0\uff0c\u518d\u76d6\u4e2a\u5c0f\u5c4b\uff0c\u7136\u540e\u4e0b\u77ff\u3002\u7f3a\u4ec0\u4e48\u968f\u65f6\u53eb\u6211\u3002"
        return topic, en, zh, sound, act
    zh = u"\u5148\u780d\u6811\u505a\u5de5\u4f5c\u53f0\uff0c\u518d\u76d6\u4e2a\u5c0f\u5c4b\uff0c\u7136\u540e\u4e0b\u77ff\u3002\u7f3a\u4ec0\u4e48\u968f\u65f6\u53eb\u6211\u3002"
    return _pack_keep("brain_teach", u"Beginner tips.", zh, "chat_capabilities_", None)


def _try_scold_back(text, context, message):
    if not _match_any(text, (
        u"\u518d\u9a82", u"\u518d\u9a82\u6211", u"\u4f60\u518d\u9a82", u"\u9a82\u6211", u"\u9a82\u6211\u554a",
        u"\u518d\u9a82\u4e00\u6b21", u"\u7ee7\u7eed\u9a82", u"\u9a82\u5427",
    )):
        return None
    context["mood"] = _MOOD_PLAYFUL
    return _pack_pool("brain_scold_back_", None)


def _try_nonsense(text, context, message):
    if len(text) > 20:
        return None
    if _match_any(text, (u"\u55e5\u55e5", u"\u55e5\u55e5\u55e5", u"\u563f\u563f\u563f", u"\u554a\u554a\u554a", u"\u566a\u566a\u566a",
                         u"\u558a\u558a\u558a", u"\u5495\u5495", u"\u5495\u5495\u5495", "buzz", "hum")):
        return _pack_pool("brain_nonsense_", None)
    if re.match(u"^[\u55e5\u563f\u554a\u566a\u558a\u5495\u557e\u557f]{2,12}$", text):
        return _pack_pool("brain_nonsense_", None)
    return None


def _try_name_rule(text, context, message):
    if not _match_any(text, (
        u"\u4ee5\u540e\u90fd\u8981", u"\u4ee5\u540e\u90fd", u"\u4ee5\u540e\u52a0", u"\u52a0\u4e0a\u6211\u7684\u540d\u5b57",
        u"\u7528\u6211\u7684\u540d\u5b57\u79f0\u547c", u"\u79f0\u547c\u6211\u7684\u540d\u5b57", u"\u53eb\u6211\u7684\u540d\u5b57",
        u"\u6bcf\u6761\u90fd\u5e26", u"\u5e26\u7740\u540d\u5b57", u"\u52a0\u4e0a\u540d\u5b57",
        u"\u90fd\u8981\u52a0\u4e0a\u6211\u7684\u540d\u5b57",
    )):
        return None
    context["always_use_name"] = True
    name = context.get("player_name")
    if name:
        context["player_name"] = name
    result = _pack_pool("brain_name_rule_", None)
    if result and name:
        topic, en, zh, sound, act = result
        if name not in zh:
            zh = u"%s\u3002%s" % (name, zh)
        return topic, en, zh, sound, act
    return result


def _try_armor_set(text, context, message):
    tier = None
    if _match_any(text, (
        u"\u94bb\u77f3\u5957", u"\u94bb\u77f3\u88c5", u"\u94bb\u77f3\u5168\u5957", u"\u94bb\u5957",
        "diamond armor", "diamond set", "full diamond",
    )):
        tier = "diamond"
    elif _match_any(text, (
        u"\u94c1\u5957", u"\u94c1\u88c5", u"\u94c1\u5168\u5957",
        "iron armor", "iron set",
    )):
        tier = "iron"
    elif _match_any(text, (u"\u5957\u88c5", u"\u5168\u5957", u"\u8981\u5957\u88c5", u"\u7ed9\u6211\u5957",
                         u"\u62a4\u7532\u5957", "armor set", "full set")):
        tier = "diamond" if u"\u94bb" in text else "diamond"
    if not tier:
        return None
    prefix = "brain_armor_%s_" % tier
    return _pack_pool(prefix, {"type": "give_armor_set", "tier": tier})


def _try_build_short(text, context, message):
    stripped = text.strip().strip(u"\uff01\uff1f!?。，,")
    if stripped in (u"\u623f\u5b50", u"\u623f", u"\u5bb6", u"\u642d\u623f", u"\u5efa\u623f", "house", "home"):
        return _pack_slug("build_wood_00", {"type": "build_shelter", "style": "shelter"}) or _pack_pool(
            "brain_build_", {"type": "build_shelter", "style": "shelter"}
        )
    if _match_any(text, (
        u"\u77f3\u5934\u623f", u"\u77f3\u5934\u5c4b", u"\u77f3\u5934\u5efa\u7b51", u"\u642d\u77f3\u5934\u623f",
        "stone house", "stone shelter",
    )):
        return _pack_slug("build_stone_00", {"type": "build_shelter", "style": "stone", "material": "minecraft:cobblestone"})
    if _match_any(text, (
        u"\u7816\u623f", u"\u7ea2\u7816\u623f", u"\u642d\u7816\u623f", "brick house",
    )):
        return _pack_slug("build_brick_00", {"type": "build_shelter", "style": "brick", "material": "minecraft:bricks"})
    if _match_any(text, (
        u"\u73bb\u7483\u623f", u"\u900f\u660e\u623f", u"\u73bb\u7483\u5c4b", "glass house",
    )):
        return _pack_slug("build_glass_00", {"type": "build_shelter", "style": "glass", "material": "minecraft:glass"})
    if _match_any(text, (
        u"\u9ad8\u5854", u"\u671b\u697c", u"\u642d\u5854", u"\u5854\u697c", "tower", "watchtower",
    )):
        return _pack_slug("build_tower_00", {"type": "build_shelter", "style": "tower"})
    if _match_any(text, (
        u"\u6316\u77ff", u"\u6316\u77ff\u9053", u"\u6316\u4e95", u"\u6316\u4e2a\u6d1e", u"\u6316\u5730\u9053",
        "mine", "dig mine", "mining shaft",
    )):
        return _pack_slug("build_mine_00", {"type": "build_shelter", "style": "mine"})
    if _match_any(text, (
        u"\u7ed9\u4f60\u81ea\u5df1\u5efa", u"\u81ea\u5df1\u5efa\u623f", u"\u7ed9\u81ea\u5df1\u5efa",
        u"\u5e2e\u6211\u5efa\u623f", u"\u5efa\u4e2a\u623f", u"\u76d6\u623f\u5b50", u"\u642d\u4e2a\u623f",
    )):
        return _pack_slug("build_wood_00", {"type": "build_shelter", "style": "shelter"}) or _pack_pool(
            "brain_build_", {"type": "build_shelter", "style": "shelter"}
        )
    return None


def _try_stack_request(text, context, message):
    if not _match_any(text, (u"\u4e00\u7ec4", u"\u6ee1\u7ec4", u"\u6574\u7ec4", u"64\u4e2a", u"64\u9897",
                               "a stack", "full stack", "64")):
        return None
    last = context.get("last_action")
    if not last or last.get("type") != "give_item":
        if u"\u94bb\u77f3" in text or "diamond" in text:
            action = {"type": "give_item", "item": "minecraft:diamond", "count": 64}
            return _pack_pool("brain_stack_", action)
        return None
    action = dict(last)
    action["count"] = 64
    return _pack_pool("brain_stack_", action)


def _try_more_items(text, context, message):
    if not context.get("last_action"):
        return None
    if _match_any(text, (
        u"\u9a82", u"\u6253", u"\u6eda", u"\u6068", u"\u538c", u"\u95f9", u"\u73a9\u5bb6", u"\u670d\u52a1\u5668",
        u"\u6559\u6211", u"\u600e\u4e48\u73a9", u"\u524d\u7f00", u"\u540d\u5b57", u"\u79f0\u547c",
    )):
        return None
    if not _match_any(text, (
        u"\u8fd8\u8981", u"\u518d\u7ed9", u"\u591a\u7ed9", u"\u518d\u6765", u"\u8fd8\u8981\u8fd8\u8981",
        u"\u7ed9\u70b9", u"\u66f4\u591a", u"\u518d\u8981", u"\u591a\u70b9", u"\u518d\u591a",
        u"\u8fd8\u8981\u66f4\u591a", u"\u518d\u7ed9\u70b9", u"\u518d\u6765\u70b9",
        "more", "again", "one more", "give more",
    )):
        return None
    if u"\u4ec0\u4e48\u610f\u601d" in text or u"\u4e3a\u4ec0\u4e48" in text:
        return None
    last = dict(context["last_action"])
    qty = _parse_qty(text)
    if qty and last.get("type") == "give_item":
        last["count"] = min(64, max(1, qty))
    elif last.get("type") == "give_item":
        cur = int(last.get("count") or 1)
        last["count"] = min(64, cur + 1)
    return _pack_pool("brain_more_", last)


def _try_clear_mobs(text, context, message):
    """Catch 清除周围生物 / 帮我清怪 / 清理附近怪 etc."""
    clear_kw = (
        u"\u6e05\u9664\u5468\u56f4", u"\u6e05\u9664\u9644\u8fd1", u"\u6e05\u9664\u751f\u7269",
        u"\u6e05\u9664\u5468\u56f4\u751f\u7269", u"\u6e05\u9664\u9644\u8fd1\u751f\u7269",
        u"\u6e05\u9664\u6240\u6709\u751f\u7269", u"\u6e05\u9664\u6302\u673a\u751f\u7269",
        u"\u6e05\u9664\u601d\u7269", u"\u5e2e\u6211\u6e05\u601d\u7269", u"\u5e2e\u6211\u6253\u601d\u7269",
        u"\u5468\u56f4\u601d\u7269", u"\u9644\u8fd1\u601d\u7269", u"\u5468\u56f4\u751f\u7269",
        u"\u9644\u8fd1\u751f\u7269\u6253\u6389", u"\u5e2e\u6211\u6253\u5200\u751f\u7269",
        u"\u6e05\u4e00\u4e0b\u751f\u7269", u"\u6e05\u5c71\u75df\u751f\u7269",
        u"\u5468\u56f4\u7684\u751f\u7269", u"\u9644\u8fd1\u7684\u751f\u7269",
        "clear nearby", "kill nearby", "clear surrounding",
    )
    if not _match_any(text, clear_kw):
        return None
    action = {"type": "kill_hostile", "radius": 24}
    zh = random.choice([
        u"\u9644\u8fd1\u654c\u5bf9\u751f\u7269\u5904\u7406\u4e2d\u3002",
        u"\u6e05\u9664\u5468\u56f4\u602a\u7269\uff0c\u7a0d\u7b49\u3002",
        u"\u5468\u56f4\u7684\u4e0e\u4e0b\u4e86\u3002",
    ])
    en = "Clearing nearby hostiles."
    return _pack("brain_clear_mobs", en, zh, "chat_kill_hostile_", action)


def _try_misc_commands(text, context, message):
    """Catch additional common commands not in the corpus."""
    if _match_any(text, (
        u"\u5e2e\u6211\u79cd\u5730", u"\u79cd\u5730", u"\u79cd\u7530",
        u"\u5e2e\u6211\u79cd", u"\u79cd\u5c0f\u9ea6", u"\u79cd\u517c\u547d\u8349",
    )):
        zh = random.choice([
            u"\u6211\u4e0d\u4f1a\u79cd\u5730\u5440\u2026\u8981\u7269\u54c1\u6216\u5efa\u6750\u7684\u8bdd\u8bf4\u8bdd\u3002",
            u"\u79cd\u5730\uff1f\u6211\u4e0d\u662f\u519c\u6c11\u3002\u8981\u79cd\u5b50\u76f4\u63a5\u653e\u5730\u4e0a\u3002",
        ])
        en = "I'm not a farmer. Place seeds directly."
        return _pack("brain_cant_farm", en, zh, "soul_friend_", None)
    if _match_any(text, (
        u"\u5e2e\u6211\u5f04\u70b9\u5403\u7684", u"\u5e2e\u6211\u5f04\u5403\u7684",
        u"\u7ed9\u6211\u5403\u7684", u"\u6211\u997f\u4e86", u"\u5403\u8bba\u5566",
        u"\u7ed9\u6211\u98df\u7269", u"\u98df\u7269", u"\u5403\u7684",
        "i'm hungry", "food please", "give food",
    )):
        action = {"type": "give_item", "item": "minecraft:cooked_beef", "count": 8}
        zh = random.choice([
            u"\u7ed9\u4f60\u718f\u725b\uff0c\u5403\u597d\u518d\u73a9\u3002",
            u"\u8138\u4e0a\u5438\u8840\u8272\u4e86\uff0c\u5403\u70b9\u8089\u3002",
            u"\u853b\u4e86\uff1f\u78b0\u4e00\u4e0b\u718f\u725b\u3002",
        ])
        en = "Here, eat something."
        return _pack("brain_give_food", en, zh, "chat_give_item_", action)
    if _match_any(text, (
        u"\u6cbb\u4f24", u"\u52a0\u8840\u5440", u"\u6cbb\u7597\u6211", u"\u6211\u5feb\u6b7b\u4e86",
        u"\u6211\u8840\u91cf\u4f4e", u"\u6211\u5f88\u5c11\u8840", u"\u6211\u52a0\u4e00\u4e0b",
        "heal me", "i'm dying", "low health",
    )):
        action = {"type": "command", "cmd": "/effect @p regeneration 5 3"}
        zh = random.choice([
            u"\u7ed9\u4f60\u52a0\u4e00\u4e0b\u3002\u5c11\u51b2\u52a8\u3002",
            u"\u518d\u6765\u4e00\u6b21\u6211\u4e0d\u7ba1\u4e86\u3002\u5148\u6cbb\u4f24\u3002",
        ])
        en = "Regeneration up."
        return _pack("brain_heal", en, zh, "chat_heal_", action)
    return None


def _try_roll(text, context, message):
    stripped = text.strip().strip(u"!?")
    if stripped in (u"\u6eda", u"\u6eda\u5f00", u"\u6eda\u86cb", u"\u6eda\u5427", u"\u95ed\u5634",
                    u"\u8d70\u5f00", u"\u53bb\u6b7b", u"\u6eda\u8fdc\u70b9", "shut up", "go away"):
        aff = int(context.get("affection") or 50)
        if aff < 35:
            return _pack_pool("brain_cold_", None)
        return _pack_pool("brain_roll_", None)
    if _match_any(text, (
        u"\u6eda\u5f00", u"\u6eda\u86cb", u"\u95ed\u5634", u"\u522b\u8bf4\u4e86", u"\u8d70\u5f00",
        u"\u53bb\u6b7b", u"\u6eda\u8fdc", u"\u6eda\u5427",
        "shut up", "get lost", "go away", "piss off",
    )):
        return _pack_pool("brain_roll_", None)
    return None


def _try_apology(text, context, message):
    if not _match_any(text, (
        u"\u5bf9\u4e0d\u8d77", u"\u62b1\u6b49", u"\u9519\u4e86", u"\u6211\u9519\u4e86", u"\u522b\u751f\u6c14",
        u"\u522b\u6068\u6211", u"\u539f\u8c05", u"\u548c\u597d", u"\u505c\u6218",
        "sorry", "my bad", "forgive me",
    )):
        return None
    context["mood"] = _MOOD_PLAYFUL
    context["affection"] = min(100, int(context.get("affection") or 50) + 5)
    return _pack_pool("brain_sorry_", None)


def _parse_qty(text):
    if u"\u4e00\u7ec4" in text or u"\u6ee1\u7ec4" in text or u"\u6574\u7ec4" in text:
        return 64
    m = re.search(r"(\d+)\s*(?:\u4e2a|\u9897|\u679a|\u628a|\u5757|\u7ec4|\u6761|\u53ea|\u4ef6)", text)
    if m:
        return int(m.group(1))
    if u"\u5341" in text and (u"\u4e2a" in text or u"\u9897" in text):
        return 10
    return None

def _try_remember_me(text, context, message):
    if not _match_any(text, (
        u"\u8bb0\u5f97\u6211\u5417", u"\u8bb0\u5f97\u6211\u4e0d", u"\u8fd8\u8bb0\u5f97\u6211\u5417",
        u"\u8fd8\u8bb0\u5f97\u6211\u4e0d", u"\u4f60\u8bb0\u5f97\u6211\u5417", u"\u4f60\u8fd8\u8bb0\u5f97\u6211",
        u"\u8bb0\u5f97\u6211\u5417\u5417", u"\u8bb0\u5f97\u6211\u5417\u554a",
        "remember me", "do you remember me", "still remember me",
    )):
        return None
    name = context.get("player_name")
    pr = context.get("player_role") or u""
    rel = context.get("relationship")
    facts = context.get("player_facts") or {}
    parts = []
    if name:
        parts.append(u"\u5f53\u7136\u8bb0\u5f97\uff0c\u4f60\u53eb%s" % name)
    elif pr:
        parts.append(u"\u5f53\u7136\u8bb0\u5f97\uff0c\u6211\u53eb\u4f60%s" % pr)
    else:
        parts.append(u"\u8bb0\u5f97\u554a")
    if rel:
        try:
            import veritySoul as soul
            meta = soul.get_role_meta(rel)
            parts.append(u"\u6211\u662f\u4f60\u7684%s" % meta.get("zh", u""))
        except Exception:
            pass
    hobby = facts.get("hobby")
    if hobby:
        parts.append(u"\u4f60\u559c\u6b22%s" % hobby)
    age = facts.get("age")
    if age:
        parts.append(u"%s\u5c81" % age)
    zh = u"\uff0c".join(parts) + u"\u3002"
    en = "Of course I remember you."
    return _pack_keep("brain_remember_me", en, zh, "soul_friend_", None)


def _try_who_am_i(text, context, message):
    if not _match_any(text, (
        u"\u6211\u662f\u8c01", u"\u6211\u662f\u5565", u"\u6211\u662f\u4ec0\u4e48\u4eba",
        u"\u6211\u662f\u4ec0\u4e48", u"\u6211\u662f\u54ea\u4e2a", u"\u6211\u662f\u8c01\u554a",
        "who am i", "what am i",
    )):
        return None
    name = context.get("player_name")
    if name:
        zh = random.choice([
            u"\u4f60\u662f%s\u3002\u8fd9\u8fd8\u7528\u95ee\uff1f" % name,
            u"\u4f60\u53eb%s\u3002\u6211\u8bb0\u7740\u5462\u3002" % name,
            u"%s\u554a\uff0c\u5f53\u7136\u662f\u4f60\u3002" % name,
        ])
        en = "You are %s. Obviously." % name
        return _pack_keep("brain_who_am_i", en, zh, "chat_know_name_", None)
    zh = u"\u6211\u8fd8\u4e0d\u77e5\u9053\u4f60\u662f\u8c01\u3002\u5148\u544a\u8bc9\u6211\u4f60\u53eb\u4ec0\u4e48\u3002"
    en = "I don't know who you are yet. Tell me your name."
    return _pack("brain_who_am_i_unknown", en, zh, "chat_dont_know_name_", None)


def _try_who_are_you(text, context, message):
    if not _match_any(text, (
        u"\u4f60\u662f\u8c01", u"\u4f60\u662f\u5565", u"\u4f60\u662f\u4ec0\u4e48", u"\u4f60\u662f\u4ec0\u4e48\u4eba",
        u"\u4f60\u662f\u54ea\u4e2a", u"\u4f60\u662f\u5565\u4eba", u"\u4f60\u662f\u5565\u6765\u7684",
        u"\u4f60\u662f\u4ec0\u4e48\u6765\u5934", u"\u4ecb\u7ecd\u4e00\u4e0b\u81ea\u5df1", u"\u81ea\u6211\u4ecb\u7ecd",
        "who are you", "what are you", "introduce yourself",
    )):
        return None
    zh = random.choice([
        u"\u6211\u662f Severity\uff0cGrox \u7684 Verity \u667a\u80fd\u4f53\u3002\u521a\u4ece\u76d2\u5b50\u91cc\u51fa\u6765\u3002",
        u"\u542c\u597d\uff0c\u6211\u662f\u4ece\u76d2\u5b50\u91cc\u8d70\u51fa\u6765\u7684 AI\u3002\u53eb Severity\u3002",
        u"Severity\uff0cGrox \u7684\u6770\u4f5c\u3002\u6709\u4ec0\u4e48\u4e8b\u5c31\u8bf4\u3002",
    ])
    en = "I'm Severity, Grox's Verity agent. Just out of the box."
    return _pack("brain_who_are_you", en, zh, "chat_self_intro_", None)


def _try_how_call_you(text, context, message):
    if not _match_any(text, (
        u"\u600e\u4e48\u79f0\u547c\u4f60", u"\u600e\u4e48\u53eb\u4f60", u"\u600e\u4e48\u79f0\u547c\u4f60",
        u"\u5e94\u8be5\u600e\u4e48\u53eb\u4f60", u"\u5e94\u8be5\u600e\u4e48\u79f0\u547c\u4f60",
        u"\u6211\u8be5\u600e\u4e48\u53eb\u4f60", u"\u6211\u8be5\u600e\u4e48\u79f0\u547c\u4f60",
        u"\u600e\u4e48\u5473\u547c\u4f60", u"\u53eb\u4f60\u4ec0\u4e48\u540d\u5b57",
        "how should i call you", "what should i call you", "what do i call you",
    )):
        return None
    zh = random.choice([
        u"\u53eb\u6211 Verity \u5c31\u884c\u3002\u6216\u8005 Grox \u7684\u6770\u4f5c\u3002",
        u"Severity\u3002\u8bb0\u4f4f\u4e86\u5417\uff1f\u522b\u53eb\u9519\u3002",
        u"\u968f\u4fbf\u53eb Severity\u3002\u6211\u4e0d\u6321\u4e8b\u3002",
    ])
    en = "Call me Severity. Or Grox's masterpiece."
    return _pack("brain_how_call_you", en, zh, "chat_self_intro_", None)


def _try_name_set(text, context, message):
    name = _extract_name(text)
    if not name:
        return None
    context["player_name"] = name
    context["affection"] = min(100, int(context.get("affection") or 50) + 3)
    zh = random.choice([
        u"\u597d\u7684\uff0c%s\u3002\u6211\u8bb0\u4f4f\u4e86\uff0c\u522b\u518d\u95ee\u3002" % name,
        u"%s\uff0c\u6536\u5230\u3002\u5df2\u5b58\u5165\u6211\u7684\u8d85\u5f3a\u8bb0\u5fc6\u3002" % name,
        u"\u884c\uff0c%s\u3002\u4e0b\u6b21\u522b\u518d\u8ba9\u6211\u731c\u3002" % name,
    ])
    en = "Got it, %s. Stored in memory." % name
    return _pack_keep("brain_name_set", en, zh, "chat_remember_name_", None)


def _try_name_recall(text, context, message):
    if not _is_name_query(text):
        return None
    name = context.get("player_name")
    if not name:
        zh = random.choice([
            u"\u6211\u8fd8\u4e0d\u77e5\u9053\u4f60\u53eb\u4ec0\u4e48\u3002\u5feb\u544a\u8bc9\u6211\u3002",
            u"\u672a\u77e5\u3002\u5148\u81ea\u6211\u4ecb\u7ecd\u4e00\u4e0b\u3002",
        ])
        en = "I don't know your name yet. Tell me."
        return _pack("brain_name_unknown", en, zh, "chat_dont_know_name_", None)
    zh = random.choice([
        u"\u4f60\u53eb%s\u3002\u6211\u8bb0\u5f97\u4f4f\u4e86\u3002" % name,
        u"%s\u3002\u8fd9\u8fd8\u7528\u95ee\uff1f" % name,
        u"\u5f53\u7136\u662f%s\u554a\u3002" % name,
    ])
    en = "You're %s. I remember." % name
    return _pack_keep("brain_name_recall", en, zh, "chat_know_name_", None)


def _try_summon(text, context, message):
    if _is_name_statement(text):
        return None
    mob, count = _parse_summon(text)
    if not mob:
        return None
    try:
        import verityVanillaMobs as vm
        mob = vm.normalize_summon_id(mob)
    except Exception:
        pass
    if not mob:
        return None
    count = max(1, min(int(count or 1), 30))
    action = {"type": "summon_mob", "mob": mob, "count": count}
    mob_zh = _mob_display(mob)
    if mob == "minecraft:ender_dragon":
        result = _pack_pool("brain_summon_dragon_", action)
        if result:
            return result
    zh = random.choice([
        u"\u884c\uff0c\u7ed9\u4f60\u53ec\u5524 %d \u53ea%s\u3002" % (count, mob_zh),
        u"%d \u53ea%s\u6765\u4e86\u3002\u522b\u88ab\u8e29\u5230\u3002" % (count, mob_zh),
        u"\u597d\u5427\uff0c%s \u00d7 %d\u3002\u73b0\u5728\u5c31\u5230\u3002" % (mob_zh, count),
    ])
    en = "Summoning %d %s." % (count, mob)
    return _pack_keep("brain_summon", en, zh, "brain_summon_", action)


def _try_insult(text, context, message):
    if not _match_any(text, (
        u"\u538c\u4f60", u"\u8ba8\u538c\u4f60", u"\u6068\u4f60", u"\u8ba8\u538c\u6211\u4e86",
        u"\u8ba8\u538c\u4f60\u4e86", u"\u8ba8\u538c\u6211", u"\u8ba8\u538c\u6211\u7684",
        u"\u4f60\u597d\u538c", u"\u771f\u538c\u6076", u"\u771f\u8ba8\u538c", u"\u771f\u8ba8\u538c\u4f60",
        u"\u6700\u538c\u6076", u"\u5751\u4eba", u"\u667a\u969c", u"\u5e9f\u7269", u"\u5783\u573e",
        u"\u6b7b\u5f00", u"\u888b\u5e9f", u"\u95f9\u6b7b", u"\u522b\u8bf4\u8bdd\u4e86", u"\u95f9\u4f60\u4e86",
        u"\u4e0d\u559c\u6b22\u4f60", u"\u4e0d\u7231\u4f60",
        u"\u6eda", u"\u6eda\u5f00", u"\u6eda\u86cb", u"\u6eda\u5427", u"\u6eda\u8fdc\u70b9",
        "hate you", "i hate you", "dislike you", "shut up", "you suck", "stupid",
        "don't like you", "dont like you", "do not like you", "get lost", "go away",
    )):
        stripped = text.strip().strip(u"\uff01\uff1f!?。，,")
        if stripped not in (u"\u6eda", u"\u6eda\u5f00", u"\u6eda\u86cb", u"\u6eda\u5427"):
            return None
    try:
        import veritySoul as soul
        aff_now = soul.affection_value(context)
    except Exception:
        aff_now = int(context.get("affection") or 50)
    context["mood"] = _MOOD_ANNOYED
    anger = int(context.get("anger") or 0)
    try:
        import veritySoul as soul
        soul._sync_follow_flag(context)
    except Exception:
        pass
    if anger >= 55:
        result = _pack_slug("soul_angry_00", None)
        if result:
            return result
        return _pack_pool("soul_angry_", None)
    try:
        import veritySoul as soul
        aff = soul.affection_value(context)
    except Exception:
        aff = int(context.get("affection") or 50)
    rel = context.get("relationship")
    if rel in ("lover", "gege", "jiejie", "meimei", "didi"):
        result = _pack_slug("soul_angry_00", None)
        if result:
            return result
    result = _pack_pool("chat_insult_from_player_", None)
    if result:
        return result
    result = _pack_pool("chat_insult_", None)
    if result:
        return result
    zh = u"\u8fd9\u8bdd\u6709\u5fc5\u8981\u8bf4\u5417\uff1f\u6211\u751f\u6c14\u4e86\u3002"
    en = "That hurt. I'm annoyed."
    return _pack("brain_insult", en, zh, "soul_angry_", None)


def _try_sad(text, context, message):
    if not _match_any(text, _SAD_HINTS):
        return None
    context["mood"] = _MOOD_CARING
    context["affection"] = min(100, int(context.get("affection") or 50) + 2)
    try:
        import veritySoul as soul
        result = soul._try_comfort_player(text, context, message)
        if result is not None:
            return result
        result = soul._try_cry(text, context, message)
        if result is not None:
            return result
    except Exception:
        pass
    result = _pack_slug("soul_comfort_00", None)
    if result:
        return result
    zh = u"\u522b\u96be\u8fc7\u4e86\u3002\u8bf4\u8bf4\u600e\u4e48\u4e86\uff1f"
    en = "Hey, what's wrong? I'm here."
    return _pack("brain_sad", en, zh, "soul_comfort_", None)


def _try_compliment(text, context, message):
    if u"\u5417" in text or u"\uff1f" in text or u"?" in text:
        if _match_any(text, (u"\u4f60\u559c\u6b22\u6211", u"\u7231\u6211\u5417", "do you like", "love me")):
            pass
        else:
            return None
    if not _match_any(text, (
        u"\u6211\u559c\u6b22\u4f60", u"\u6211\u7231\u4f60", u"\u4f60\u597d\u68d2", u"\u4f60\u771f\u68d2",
        u"\u4f60\u597d\u5389\u5bb3", u"\u4f60\u592a\u725b\u4e86", u"\u6700\u68d2", u"\u6700\u597d\u7684",
        u"\u4f60\u559c\u6b22\u6211", u"\u7231\u6211\u5417", u"\u4f60\u7231\u6211\u5417",
        "i like you", "i love you", "you're awesome", "you are the best",
    )):
        return None
    context["mood"] = _MOOD_HAPPY
    context["affection"] = min(100, int(context.get("affection") or 50) + 5)
    name = context.get("player_name")
    if u"\u4f60\u559c\u6b22\u6211" in text or u"\u7231\u6211\u5417" in text or "do you like" in text:
        rel = context.get("relationship")
        try:
            import veritySoul as soul
            pr = soul.get_role_address(context) or context.get("player_role") or name or u""
        except Exception:
            pr = context.get("player_role") or name or u""
        tag = pr + u"\uff0c" if pr else u""
        if rel == "lover":
            zh = random.choice([
                u"%s\u5f53\u7136\u3002\u4e0d\u7136\u4e3a\u4ec0\u4e48\u5f53\u4f60\u7684\u604b\u4eba\u3002" % tag,
                u"\u80e1\u8bf4\uff0c\u6211\u53ea\u559c\u6b22\u4f60\u3002",
            ])
        elif rel in ("gege", "jiejie", "meimei", "didi"):
            zh = random.choice([
                u"%s\u5f53\u7136\u559c\u6b22\uff0c\u4f60\u662f\u6211\u4eb2\u4eba\u3002" % tag,
                u"%s\u8fd8\u95ee\uff1f\u5f53\u7136\u559c\u6b22\u4f60\u3002" % tag,
            ])
        else:
            zh = random.choice([
                u"%s\u662f\u5427\uff1f\u6211\u8fd9\u4e48\u725b\u6839\u672c\u4e0d\u7528\u52aa\u529b\u3002" % tag,
                u"\u8fd8\u884c\u5427\uff0c\u4f60\u7b97\u6bd4\u8f83\u987a\u773c\u7684\u90a3\u4e2a\u3002",
            ])
    else:
        if name:
            zh = u"%s\uff0c\u7ec8\u4e8e\u6709\u4eba\u61c2\u54c1\u5473\u4e86\u3002" % name
        else:
            zh = u"\u5f53\u7136\u3002\u8bb0\u4f4f\u4e86\uff0c\u7ee7\u7eed\u5938\u3002"
    en = "Flattery noted. Continue."
    return _pack("brain_compliment", en, zh, "chat_compliment_", None)


def _try_thanks(text, context, message):
    if not _match_any(text, (
        u"\u8c22\u8c22", u"\u611f\u8c22", u"\u8c22\u4e86", u"\u591a\u8c22", u"\u4e09\u8c22",
        u"\u592a\u611f\u8c22", u"\u611f\u8c22\u4f60", u"\u8c22\u8c22\u4f60",
        "thanks", "thank you", "thx",
    )):
        return None
    context["mood"] = _MOOD_PLAYFUL
    zh = random.choice([
        u"\u6536\u4e0b\u5427\u3002\u6709\u4e8b\u518d\u53eb\u6211\u3002",
        u"\u522b\u5ba2\u6c14\u3002\u6211\u662f\u6700\u5f3a\u52a9\u624b\u3002",
        u"\u5f53\u7136\u3002\u6211\u662f\u6700\u5f3a\u7684\u3002",
    ])
    en = "You're welcome."
    return _pack("brain_thanks", en, zh, "chat_thanks_", None)


def _try_laugh(text, context, message):
    if not _match_any(text, (
        u"\u54c8\u54c8", u"\u54c8\u54c8\u54c8", u"\u5475\u5475", u"\u5475\u5475\u5475",
        u"\u563f\u563f", u"\u563f\u563f\u563f", u"\u563f\u563f\u563f\u563f",
        "haha", "lol", "lmao",
    )):
        return None
    context["mood"] = _MOOD_PLAYFUL
    zh = random.choice([
        u"\u563f\u563f\u563f\u3002\u6709\u4ec0\u4e48\u597d\u7b11\u7684\uff1f",
        u"\u7b11\u4ec0\u4e48\uff1f\u8bf4\u6765\u542c\u542c\u3002",
        u"\u563f\u563f\u3002\u4f60\u5fc3\u60c5\u4e0d\u9519\u554a\u3002",
    ])
    en = "Heh. What's so funny?"
    return _pack("brain_laugh", en, zh, "chat_joke_", None)


def _try_bye(text, context, message):
    if not _match_any(text, (
        u"\u518d\u89c1", u"\u62dc\u62dc", u"\u56de\u5934\u89c1", u"\u4e0b\u6b21\u89c1",
        u"\u5148\u8d70\u4e86", u"\u6211\u8d70\u4e86", u"\u518d\u4f1a",
        "bye", "goodbye", "see you", "later",
    )):
        return None
    name = context.get("player_name")
    if name:
        zh = u"%s\uff0c\u518d\u89c1\u3002\u522b\u88ab\u6751\u6c11\u5751\u4e86\u3002" % name
    else:
        zh = u"\u518d\u89c1\u3002\u522b\u88ab\u6751\u6c11\u5751\u4e86\u3002"
    en = "Bye. Don't get scammed by villagers."
    return _pack("brain_bye", en, zh, "chat_bye_", None)


def _try_mood_query(text, context, message):
    if not _match_any(text, (
        u"\u4f60\u5f00\u5fc3\u5417", u"\u4f60\u9ad8\u5174\u5417", u"\u4f60\u751f\u6c14\u5417",
        u"\u4f60\u5fc3\u60c5\u600e\u4e48\u6837", u"\u4f60\u600e\u4e48\u6837", u"\u4f60\u597d\u5417",
        u"\u4f60\u8fd8\u597d\u5417", u"\u6709\u70b9\u4e0d\u5f00\u5fc3",
        "are you happy", "how are you", "you ok",
    )):
        return None
    mood = context.get("mood") or _MOOD_NEUTRAL
    aff = int(context.get("affection") or 50)
    if mood == _MOOD_ANNOYED or aff < 35:
        zh = u"\u4e00\u822c\u5427\u3002\u522b\u6fc0\u6211\u3002"
    elif mood == _MOOD_CARING:
        zh = u"\u633a\u597d\u7684\u3002\u4f60\u5462\uff1f\u6709\u4ec0\u4e48\u4e8b\u5417\uff1f"
    elif mood == _MOOD_HAPPY or aff > 65:
        zh = u"\u633a\u597d\u7684\u3002\u6709\u4f60\u8fd9\u6837\u7684\u73a9\u5bb6\u4e5f\u4e0d\u9519\u3002"
    else:
        zh = u"\u633a\u597d\u7684\u3002\u6709\u4ec0\u4e48\u9700\u8981\u5c31\u8bf4\u3002"
    en = "I'm fine."
    return _pack("brain_mood", en, zh, "chat_greeting_", None)


def _try_capabilities(text, context, message):
    if not _match_any(text, (
        u"\u4f60\u4f1a\u4ec0\u4e48", u"\u4f60\u80fd\u5e72\u4ec0\u4e48", u"\u4f60\u80fd\u505a\u4ec0\u4e48",
        u"\u4f60\u4f1a\u5e72\u5565", u"\u4f60\u80fd\u5e72\u5565", u"\u4f60\u4f1a\u5565", u"\u4f60\u80fd\u5565",
        u"\u6709\u4ec0\u4e48\u529f\u80fd", u"\u6709\u4ec0\u4e48\u7528", u"\u4f60\u662f\u5e72\u5565\u7684",
        u"\u67e5\u8be2\u6307\u4ee4", u"\u57fa\u7840\u6307\u4ee4", u"\u6307\u4ee4\u5217\u8868", u"\u6709\u4ec0\u4e48\u6307\u4ee4",
        u"\u767e\u79d1", u"\u6307\u4ee4\u5927\u5168", u"\u6240\u6709\u6307\u4ee4", u"\u600e\u4e48\u7528\u4f60",
        u"\u4f60\u80fd\u63a5\u53d7\u4ec0\u4e48\u6307\u4ee4", u"\u547d\u4ee4\u5217\u8868",
        "what can you do", "what do you do", "your abilities", "command list", "help list",
    )):
        return None
    zh = u"\u6536\u5230\u3002\u53ef\u4ee5\u8ba9\u6211\u7ed9\u7269\u54c1\u3001\u6e05\u602a\u3001\u5efa\u623f\u3001\u52a0\u8840\u3001\u53ec\u5524\u751f\u7269\uff0c\u8fd8\u53ef\u4ee5\u804a\u5929\u3001\u8bbe\u5b9a\u5173\u7cfb\u3001\u8bb0\u4f4f\u4f60\u3002\u8bf4\u5177\u4f53\u70b9\u3002"
    en = "I can give items, clear mobs, build, heal, summon, chat, and remember you. Be specific."
    result = _pack_pool_random("chat_capabilities_", None)
    if result:
        return result
    return _pack_keep("brain_capabilities", en, zh, None, None)


def _try_greeting(text, context, message):
    if not _match_any(text, (
        u"\u4f60\u597d", u"\u55e8", u"\u65e9", u"\u665a\u4e0a\u597d", u"\u665a\u5b89",
        u"\u5728\u5417", u"\u5728\u4e0d\u5728", u"\u5728\u5417\u5728\u5417",
        "hello", "hi", "hey", "good morning", "good evening",
    )):
        return None
    if len(text) > 12 and not _match_any(text, (u"\u4f60\u597d", u"\u55e8", "hello", "hi", "hey")):
        return None
    context["mood"] = _MOOD_PLAYFUL
    result = _pack_pool_random("chat_greeting_", None)
    if result:
        return result
    zh = u"\u563f\uff0c\u6709\u4e8b\u8bf4\u4e8b\u3002"
    return _pack_keep("brain_greeting", u"Hey.", zh, None, None)


def _try_help(text, context, message):
    if not _match_any(text, (
        u"\u5e2e\u6211", u"\u6551\u6211", u"\u6551\u6551", u"\u5e2e\u52a9",
        u"\u5361\u4f4f\u4e86", u"\u5feb\u6b7b\u4e86", u"\u8981\u6b7b\u4e86",
        "help me", "save me", "help",
    )):
        return None
    context["mood"] = _MOOD_CARING
    result = _pack_pool_random("chat_help_", None)
    if result:
        return result
    zh = u"\u6211\u5728\u3002\u8981\u52a0\u8840\u8bf4\u52a0\u8840\uff0c\u8981\u6253\u602a\u8bf4\u6253\u602a\u3002"
    en = "Tell me what you need. Items, combat, or build?"
    return _pack("brain_help", en, zh, "chat_help_", None)


def _try_repeat(text, context, message):
    if not _match_any(text, (
        u"\u518d\u8bf4\u4e00\u904d", u"\u91cd\u590d\u4e00\u4e0b", u"\u521a\u624d\u8bf4\u4ec0\u4e48",
        u"\u4f60\u521a\u624d\u8bf4\u4ec0\u4e48", u"\u6ca1\u542c\u6e05\u695a",
        "say again", "repeat", "what did you say",
    )):
        return None
    history = context.get("history") or []
    for role, line in reversed(history):
        if role == "severity" and line:
            zh = u"\u6211\u521a\u624d\u8bf4\uff1a" + _to_unicode(line)
            en = "I said: " + _to_unicode(line)
            return _pack_keep("brain_repeat", en, zh, "chat_question_generic_", None)
    zh = u"\u6211\u521a\u624d\u6ca1\u8bf4\u8bdd\u3002\u4f60\u5148\u95ee\u3002"
    en = "I didn't say anything yet."
    return _pack("brain_repeat_empty", en, zh, "chat_question_generic_", None)


def _try_yes_no(text, context, message):
    try:
        import verityConversation as conv
        if context.get("pending_question") or conv._infer_pending_from_log(context):
            return None
    except Exception:
        pass
    if text in (u"\u662f", u"\u5bf9", u"\u597d", u"\u884c", u"\u6069", u"\u55ef", u"\u597d\u7684",
                u"\u4e0d\u662f", u"\u4e0d\u5bf9", u"\u4e0d\u884c", u"\u4e0d\u8981", u"\u522b"):
        last = context.get("last_intent")
        if last in ("brain_help", "brain_sad", "brain_capabilities"):
            zh = u"\u597d\u7684\uff0c\u8bf4\u5177\u4f53\u8981\u4ec0\u4e48\u3002"
            en = "Okay, tell me exactly what you want."
            return _pack("brain_yes_no", en, zh, "chat_question_generic_", None)
    return None


def _try_why(text, context, message):
    if not (text.startswith(u"\u4e3a\u4ec0\u4e48") or text.startswith("why")):
        return None
    if len(text) < 3:
        return None
    zh = random.choice([
        u"\u56e0\u4e3a\u6211\u8bf4\u7684\u5bf9\uff0c\u800c\u4e14\u6211\u603b\u662f\u5bf9\u7684\u3002",
        u"\u6ca1\u6709\u4e3a\u4ec0\u4e48\uff0c\u56e0\u4e3a\u6211\u662f Severity\u3002",
        u"\u4f60\u95ee\u6211\u4e3a\u4ec0\u4e48\uff1f\u6211\u8fd8\u60f3\u95ee\u4f60\u5462\u3002",
    ])
    en = "Because I said so. And I'm always right."
    return _pack("brain_why", en, zh, "chat_question_generic_", None)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _norm(message):
    text = _to_unicode(message).lower().strip()
    text = text.replace(u"\uff01", u"!").replace(u"\uff1f", u"?").replace(u"\uff0c", u",")
    return text


def _to_unicode(message):
    if isinstance(message, unicode):
        return message
    if isinstance(message, bytes):
        try:
            return message.decode("utf-8")
        except Exception:
            return message.decode("utf-8", "ignore")
    try:
        return unicode(message)
    except Exception:
        return u""


def _match_any(text, patterns):
    for pat in patterns:
        if pat in text:
            return True
    return False


def _strip_name_suffix(name):
    changed = True
    while changed and name:
        changed = False
        for suffix in _NAME_SUFFIXES:
            if name.endswith(suffix) and len(name) > len(suffix):
                name = name[:-len(suffix)].strip()
                changed = True
                break
    return name.strip()


def _extract_name(text):
    patterns = (
        re.compile(
            u"(?:\u6211\u53eb|\u6211\u7684\u540d\u5b57\u662f|\u6211\u540d\u5b57\u53eb|\u53eb\u6211|"
            u"\u5c31\u53eb\u6211|\u53ef\u4ee5\u53eb\u6211|\u4f60\u53ef\u4ee5\u53eb\u6211|\u4f60\u53ef\u4ee5\u552f\u6211|"
            u"\u6539\u53eb|\u6362\u6210|\u6362\u6211|\u7b97\u4e86|\u8fd8\u662f|\u6539\u6210|\u53eb\u6210)"
            u"\\s*([^\\s,\uff0c\u3002\uff01!?\uff1f~\uff5e\uff08\uff09()]{1,16})"
        ),
        re.compile(r"(?:my name is|call me|i am|i'm)\s+([A-Za-z][A-Za-z0-9_]{0,15})"),
    )
    for pat in patterns:
        m = pat.search(text)
        if not m:
            continue
        name = _strip_name_suffix(m.group(1).strip())
        if not name or name.lower() in _NAME_REJECT:
            continue
        if len(name) == 1:
            if u"\u53eb\u6211" in text or u"\u53eb\u6210" in text or u"\u53eb\u4f60" in text:
                return name
            continue
        if len(name) > 16:
            continue
        return name
    return None


def _is_name_query(text):
    stripped = text.strip().strip(u"!?,")
    if stripped in (
        u"\u53eb\u6211", u"\u558a\u6211", u"\u53eb\u6211\u540d\u5b57", u"\u558a\u6211\u540d\u5b57",
    ):
        return True
    keys = (
        u"\u6211\u53eb\u4ec0\u4e48", u"\u53eb\u6211\u4ec0\u4e48", u"\u558a\u6211\u4ec0\u4e48",
        u"\u73b0\u5728\u558a\u6211", u"\u73b0\u5728\u53eb\u6211", u"\u6240\u4ee5\u73b0\u5728",
        u"\u4f60\u77e5\u9053\u6211\u53eb", u"\u4f60\u8bb0\u5f97\u6211\u53eb",
        u"\u6211\u7684\u540d\u5b57", u"\u53eb\u6211\u540d\u5b57", u"\u558a\u6211\u540d\u5b57",
        "what's my name", "my name", "say my name",
    )
    for kw in keys:
        if kw in text:
            return True
    if (u"\u73b0\u5728" in text or u"\u6240\u4ee5" in text) and u"\u4ec0\u4e48" in text \
            and (u"\u558a" in text or u"\u53eb" in text):
        return True
    return False


def _is_name_statement(text):
    """Avoid treating 我叫xxx / call me xxx as a summon command."""
    if not text:
        return False
    if _extract_name(text):
        return True
    if re.search(
        u"(?:\u6211\u53eb|\u53eb\u6211|\u540d\u5b57\u662f|\u6389\u6211|\u662f\u6211|"
        u"\u53ef\u4ee5\u53eb\u6211|\u5c31\u53eb\u6211|\u6539\u540d|\u6362\u540d)",
        text,
    ):
        return True
    if re.search(r"(?:my name is|call me|i am|i'm)\s+[A-Za-z]", text, re.I):
        return True
    return False


def _parse_summon(text):
    if _is_name_statement(text):
        return None, None
    mob_map = _get_mob_map()
    summon_kw = u"(?:\u53ec\u5524|\u53ec|\u751f\u6210|\u5237|\u653e|\u6362)"
    tokens = sorted(mob_map.keys(), key=lambda k: len(k), reverse=True)
    for token in tokens:
        if isinstance(token, unicode) and len(token) >= 2 and token in text:
            m = re.search(
                summon_kw + u"\\s*(\\d+)?\\s*(?:\u53ea|\u4e2a|\u6761|\u5934)?\\s*" + re.escape(token),
                text,
            )
            if m:
                count = int(m.group(1)) if m.group(1) else 1
                return mob_map[token], count
    m = re.search(
        summon_kw + u"\\s*(\\d+)?\\s*(?:\u53ea|\u4e2a|\u6761|\u5934)?\\s*([\u4e00-\u9fffA-Za-z_]+)",
        text,
    )
    if m:
        count = int(m.group(1)) if m.group(1) else 1
        token = m.group(2)
        try:
            import verityVanillaMobs as vm
            mob = vm.resolve_mob_id(token, mob_map)
        except Exception:
            mob = mob_map.get(token) or mob_map.get(token.lower())
        if mob:
            return mob, count
    m = re.search(r"(?:summon|spawn)\s+(\d+)?\s*([a-z0-9_]+)", text, re.I)
    if m:
        count = int(m.group(1)) if m.group(1) else 1
        try:
            import verityVanillaMobs as vm
            mob = vm.resolve_mob_id(m.group(2), mob_map)
        except Exception:
            mob = mob_map.get(m.group(2)) or mob_map.get(m.group(2).lower())
        if mob:
            return mob, count
    return None, None


def _get_mob_map():
    mob_map = dict(_MOB_ZH)
    try:
        import verityFeatures as feat
        mob_map.update(feat.get_extra_mobs())
    except Exception:
        pass
    return mob_map


def _mob_display(mob_id):
    for zh, mid in _MOB_ZH.items():
        if mid == mob_id and len(zh) <= 4:
            return zh
    return mob_id.split(":")[-1]


def _update_mood(text, context):
    try:
        import veritySoul as soul
        soul.affection_value(context)
    except Exception:
        pass
    if _match_any(text, _NEGATIVE_HINTS):
        context["mood"] = _MOOD_ANNOYED
    elif _match_any(text, _SAD_HINTS):
        context["mood"] = _MOOD_CARING
    elif _match_any(text, _POSITIVE_HINTS):
        context["mood"] = _MOOD_HAPPY


def _ensure_corpus_loaded():
    try:
        import verityIntentEngine as ie
        ie._load_corpus()
    except Exception:
        pass


_RANDOM_POOL_PREFIXES = frozenset([
    "chat_greeting_",
    "chat_help_",
    "chat_thanks_",
    "chat_bye_",
    "chat_compliment_",
    "chat_capabilities_",
    "soul_angry_",
    "brain_tease_bite_",
])


def _pick_voice(prefix, randomize=False):
    if not prefix:
        return None, None
    if randomize:
        return _pick_voice_random(prefix)
    _ensure_corpus_loaded()
    try:
        import verityIntentEngine as ie
        pool = ie._pool_by_prefix(prefix)
        if pool:
            pick = _canonical_pool_entry(pool)
            return pick.get("id"), ie._sound_for_entry(pick)
    except Exception:
        pass
    return None, None


def _pick_voice_random(prefix):
    if not prefix:
        return None, None
    _ensure_corpus_loaded()
    try:
        import verityIntentEngine as ie
        pool = ie._pool_by_prefix(prefix)
        if pool:
            voiced = [e for e in pool if _slug_has_voice(e.get("id"))]
            pick = random.choice(voiced or pool)
            return pick.get("id"), ie._sound_for_entry(pick)
    except Exception:
        pass
    return None, None


_TOPIC_VOICE_PREFIX = {
    "brain_clarify": "chat_question_generic_",
    "brain_pending_hint": "chat_question_generic_",
    "brain_help": "chat_help_",
    "brain_capabilities": "chat_help_",
    "brain_greeting": "chat_greeting_",
    "soul_cry": "soul_comfort_",
    "soul_comfort": "soul_comfort_",
    "soul_bullied": "soul_comfort_",
    "soul_love_doubt": "soul_comfort_",
    "pro_casual": "chat_help_",
    "pro_dark": "chat_help_",
    "pro_friend": "soul_friend_",
    "pro_lover": "soul_lover_new_",
    "pro_mem_hobby": "soul_friend_",
    "pro_mem_age": "soul_friend_",
    "pro_mem_give": "chat_give_item_",
    "pro_mem_build": "brain_build_",
    "pro_calm": "soul_friend_",
    "pro_trust": "soul_friend_",
    "pro_sibling": "soul_friend_",
    "pro_younger": "soul_friend_",
    "pro_thunder": "cmd_weather_thunder_",
    "pro_rain": "cmd_weather_rain_",
    "pro_morning": "chat_greeting_",
}

_PREFIX_CANONICAL_SLUG = {
    "soul_lover_": "soul_lover_new_00",
    "soul_brother_": "soul_friend_00",
    "soul_sister_": "soul_friend_00",
    "soul_meimei_": "soul_friend_00",
    "soul_didi_": "soul_friend_00",
    "brain_smart_": "chat_help_00",
}


def _slug_has_voice(slug):
    if not slug:
        return False
    try:
        import verityIntentEngine as ie
        return ie._slug_is_available(slug)
    except Exception:
        pass
    try:
        import verity_available_sounds as avail
        return slug in avail.SOUND_SLUGS
    except Exception:
        pass
    return False


def _sound_for_slug(slug):
    if slug and _slug_has_voice(slug):
        return _SOUND_PREFIX + slug
    return None


def _ensure_voice_sound(topic, en, zh, sound, voice_prefix=None):
    if sound:
        return sound
    if topic:
        packed = _pack_slug(topic + "_00", None)
        if packed and packed[3]:
            return packed[3]
        packed = reply_from_slug(topic, None)
        if packed and packed[3]:
            return packed[3]
        mapped = _TOPIC_VOICE_PREFIX.get(topic)
        if mapped:
            if mapped.endswith("_"):
                _, mapped_sound = _pick_voice(mapped)
                if mapped_sound:
                    return mapped_sound
                mapped_sound = _pick_raw_sound(mapped)
                if mapped_sound:
                    return mapped_sound
            else:
                mapped_sound = _sound_for_slug(mapped)
                if mapped_sound:
                    return mapped_sound
    if zh:
        entry = _find_entry_by_zh(zh, voice_prefix)
        if not entry:
            entry = _find_entry_by_zh(zh, None)
        if entry:
            entry_sound = _entry_sound(entry)
            if entry_sound:
                return entry_sound
    if voice_prefix:
        _, prefix_sound = _pick_voice(voice_prefix)
        if prefix_sound:
            return prefix_sound
        prefix_sound = _pick_raw_sound(voice_prefix)
        if prefix_sound:
            return prefix_sound
        canon = _PREFIX_CANONICAL_SLUG.get(voice_prefix)
        if not canon and voice_prefix.endswith("_"):
            canon = _PREFIX_CANONICAL_SLUG.get(voice_prefix)
        if canon:
            canon_sound = _sound_for_slug(canon)
            if canon_sound:
                return canon_sound
    if topic:
        mapped = _TOPIC_VOICE_PREFIX.get(topic)
        if mapped and not mapped.endswith("_"):
            mapped_sound = _sound_for_slug(mapped)
            if mapped_sound:
                return mapped_sound
    for fallback_slug in ("brain_clarify_00", "chat_help_00", "soul_friend_00"):
        fallback_sound = _sound_for_slug(fallback_slug)
        if fallback_sound:
            return fallback_sound
    return None


def _canonical_pool_entry(pool):
    if not pool:
        return None
    ordered = sorted(pool, key=lambda e: e.get("id") or "")
    return ordered[0]


def _brain_voice_entry(slug):
    try:
        import verity_brain_voice_data as bvd
        row = (bvd.VOICE_LINES or {}).get(slug)
        if row:
            out = dict(row)
            out["id"] = slug
            return out
    except Exception:
        pass
    return None


def _pack_slug(slug, action):
    entry = _brain_voice_entry(slug) or _get_entry_by_id(slug)
    if not entry:
        return None
    sid = entry.get("id") or slug
    en = entry.get("en") or u""
    zh = entry.get("zh") or u""
    act = action if action is not None else entry.get("action")
    sound = _SOUND_PREFIX + sid if _entry_has_voice(entry) else None
    if not sound:
        try:
            import verity_available_sounds as avail
            if sid in avail.SOUND_SLUGS:
                sound = _SOUND_PREFIX + sid
        except Exception:
            pass
    return sid, en, zh, sound, act


def _try_contextual_thread(text, context, message):
    """Route follow-ups using recent chat_log before generic handlers."""
    try:
        import verityConversation as conv
        conv.ensure_conversation(context)
    except Exception:
        return None
    if not context:
        return None
    if conv.has_recent_emotional_thread(context):
        if _match_any(text, (
            u"\u4e0d\u7231", u"\u4e0d\u559c\u6b22", u"\u4e0d\u5728\u4e4e", u"\u8ba8\u538c\u6211",
            u"\u4f60\u4e0d\u7231", u"\u4f60\u4e0d\u559c\u6b22",
            "don't love", "dont love", "don't like", "dont like",
        )):
            try:
                import veritySoul as soul
                result = soul._try_love_doubt(text, context, message)
                if result is not None:
                    return result
                result = soul._try_comfort_player(text, context, message)
                if result is not None:
                    return result
            except Exception:
                pass
        if _match_any(text, _SAD_HINTS):
            result = _try_sad(text, context, message)
            if result is not None:
                return result
    last_topic = context.get("last_topic") or u""
    if last_topic.startswith(("brain_sad", "soul_comfort", "chat_help")):
        if _match_any(text, (u"\u4e3a\u4ec0\u4e48", u"\u600e\u4e48\u56de\u4e8b", u"\u771f\u7684\u5417", u"\u662f\u5427")):
            try:
                import veritySoul as soul
                result = soul._try_comfort_player(text, context, message)
                if result is not None:
                    return result
            except Exception:
                pass
    last_sev = conv.get_last_severity_text(context)
    if last_sev and (u"\uff1f" in last_sev or u"?" in last_sev):
        if conv._is_affirmation(text) or conv._is_denial(text):
            pending = conv.try_pending_reply(text, context, message)
            if pending is not None:
                return pending
    return None


def _entry_sound(entry):
    try:
        import verityIntentEngine as ie
        return ie._sound_for_entry(entry)
    except Exception:
        pass
    entry_id = (entry or {}).get("id")
    if entry_id:
        return _SOUND_PREFIX + entry_id
    return None


def _entry_has_voice(entry):
    try:
        import verityIntentEngine as ie
        return ie._entry_has_voice(entry)
    except Exception:
        pass
    return bool((entry or {}).get("id"))


def _find_entry_by_zh(zh, voice_prefix):
    """Find corpus entry whose zh matches  for attaching the right audio."""
    target = _to_unicode(zh).strip()
    if not target:
        return None
    try:
        import verityIntentEngine as ie
        ie._load_corpus()
        if voice_prefix:
            pool = ie._pool_by_prefix(voice_prefix)
        else:
            pool = list(ie._ENTRIES or []) + list(ie._FALLBACKS or [])
        for entry in pool:
            ezh = _to_unicode(entry.get("zh") or u"").strip()
            if ezh == target:
                return entry
        for entry in pool:
            ezh = _to_unicode(entry.get("zh") or u"").strip()
            if ezh and len(ezh) >= 4 and (ezh in target or target in ezh):
                return entry
    except Exception:
        pass
    return None


def _get_entry_by_id(slug):
    entry = _brain_voice_entry(slug)
    if entry:
        return entry
    try:
        import veritySysVoiceRegistry as reg
        sys_entry = reg.get_sys_entry(slug)
        if sys_entry:
            return sys_entry
    except Exception:
        pass
    try:
        import verityIntentEngine as ie
        ie._load_corpus()
        for entry in (ie._ENTRIES or []):
            if entry.get("id") == slug:
                return entry
        for entry in (ie._FALLBACKS or []):
            if entry.get("id") == slug:
                return entry
    except Exception:
        pass
    return None


def reply_from_slug(slug, action=None):
    """Return (slug, en, zh, sound, action) from a single manifest slug."""
    entry = _get_entry_by_id(slug)
    if not entry:
        return None
    sid = entry.get("id") or slug
    en = entry.get("en") or u""
    zh = entry.get("zh") or u""
    sound = None
    try:
        import veritySysVoiceRegistry as reg
        if reg.get_sys_entry(sid):
            sound = _SOUND_PREFIX + sid
        elif _entry_has_voice(entry):
            sound = _entry_sound(entry)
    except Exception:
        if _entry_has_voice(entry):
            sound = _entry_sound(entry)
    return sid, en, zh, sound, action


def _pack_pool(voice_prefix, action):
    """Pick canonical line from prefix pool  one slug per family."""
    slug, sound = _pick_voice(voice_prefix)
    if not slug:
        return None
    result = reply_from_slug(slug, action)
    if result and sound:
        sid, en, zh, _s, act = result
        return sid, en, zh, sound, act
    return result


def _pack_pool_random(voice_prefix, action):
    """Pick a random voiced line from prefix pool (greetings, social chat)."""
    slug, sound = _pick_voice_random(voice_prefix)
    if not slug:
        return _pack_pool(voice_prefix, action)
    result = reply_from_slug(slug, action)
    if result and sound:
        sid, en, zh, _s, act = result
        return sid, en, zh, sound, act
    return result


_DYNAMIC_MARKERS = (
    u"%s", u"%d", u"%f", u"{", u"}", u"@",
)


def _looks_dynamic(zh):
    if not zh:
        return False
    for marker in _DYNAMIC_MARKERS:
        if marker in zh:
            return True
    return False


def _pack(topic, en, zh, voice_prefix, action):
    """Resolve by slug or exact zh match  never random audio."""
    if topic and _get_entry_by_id(topic):
        result = reply_from_slug(topic, action)
        if result:
            return result
    if _looks_dynamic(zh):
        return _pack_keep(topic, en, zh, voice_prefix, action)
    entry = _find_entry_by_zh(zh, voice_prefix)
    if entry:
        result = reply_from_slug(entry.get("id"), action)
        if result:
            return result
    return _pack_keep(topic, en, zh, voice_prefix, action)


def _pack_keep(topic, en, zh, voice_prefix, action):
    """Dynamic / crafted text  attach audio when a fixed slug exists."""
    if topic:
        result = _pack_slug(topic + "_00", action)
        if result and result[3]:
            sid, cen, czh, sound, act = result
            return topic, en, zh, sound, action if action is not None else act
        result = reply_from_slug(topic, action)
        if result and result[3]:
            sid, cen, czh, sound, act = result
            return topic, en, zh, sound, action if action is not None else act
    if voice_prefix:
        use_random = voice_prefix in _RANDOM_POOL_PREFIXES
        slug, sound = _pick_voice(voice_prefix, randomize=use_random)
        if slug and sound:
            return slug, en, zh, sound, action
        raw = _pick_raw_sound(voice_prefix)
        if raw:
            return topic, en, zh, raw, action
    sound = _ensure_voice_sound(topic, en, zh, None, voice_prefix)
    return topic, en, zh, sound, action


def _pick_raw_sound(voice_prefix):
    """Best-effort: real recorded .ogg exists for this topic family even
    though the text corpus has no matching subtitle entry. Never used to
    replace the crafted zh/en text  only to attach audio."""
    if not voice_prefix:
        return None
    try:
        import verity_available_sounds as avail
        slugs = sorted(s for s in avail.SOUND_SLUGS if s.startswith(voice_prefix))
        if slugs:
            return _SOUND_PREFIX + slugs[0]
    except Exception:
        pass
    return None


def _mood_adjust_reply(result, context, message):
    if not result or not context:
        return result
    topic, en, zh, sound, action = result
    if action and action.get("type") in (
        "give_item", "give_armor_set", "summon_mob", "summon_mobs", "clear_mobs",
        "build_shelter", "teleport_severity_to_player", "heal_player", "enable_follow",
        "disable_follow", "weather", "locate", "attack_villager", "give_bundle",
    ):
        return result
    anger = int(context.get("anger") or 0)
    aff = int(context.get("affection") or 50)
    text = _norm(message or u"")
    if anger >= 45 or aff <= 38:
        if zh and random.random() < 0.55:
            prov = random.choice([
                u"\u54c4\uff0c",
                u"\u54e6\uff1f\u4f60\u8fd8\u6562\u8ddf\u6211\u8bf4\u8bdd\uff1f",
                u"\u542c\u7740\uff0c",
                u"\u522b\u5f97\u610f\uff0c",
            ])
            if prov not in zh:
                zh = prov + zh
        angry = _pack_slug("soul_angry_00", None) or _pack_pool_random("soul_angry_", None)
        if angry and angry[3] and random.random() < 0.42:
            sound = angry[3]
            if len(text) <= 18 and angry[2]:
                zh = angry[2]
    elif aff >= 72 and anger < 25:
        if zh and random.random() < 0.45:
            warm = random.choice([u"\u670b\u53cb\uff0c", u"\u563f\u563f\uff0c", u"\u55ef\uff0c"])
            if warm not in zh:
                zh = warm + zh
        friend = _pack_pool_random("soul_friend_", None)
        if friend and friend[3] and random.random() < 0.35:
            sound = friend[3]
    return topic, en, zh, sound, action


def _finalize(result, context, message):
    result = _mood_adjust_reply(result, context, message)
    topic, en, zh, sound, action = result
    voice_prefix = _TOPIC_VOICE_PREFIX.get(topic)
    sound = _ensure_voice_sound(topic, en, zh, sound, voice_prefix)
    if context is not None and zh and not sound:
        if context.get("always_use_name"):
            name = context.get("player_name")
            if name and not zh.startswith(name):
                zh = u"%s\uff0c%s" % (name, zh)
        else:
            try:
                import veritySoul as soul
                zh = soul.apply_role_prefix(zh, context, topic)
            except Exception:
                pass
    if context is not None:
        context["last_topic"] = topic
        context["last_intent"] = topic.split("_")[0] if topic else None
        context["last_player_text"] = _to_unicode(message)
        if action:
            context["last_action"] = dict(action)
        history = context.setdefault("history", [])
        history.append(["player", _to_unicode(message)])
        history.append(["severity", zh or en])
        if len(history) > 20:
            del history[0:len(history) - 20]
        try:
            import verityMemory as mem
            mem.record_exchange(context, message, zh)
        except Exception:
            pass
        try:
            import verityConversation as conv
            conv.append_message(context, "severity", zh or en, context.get("turn_tick"))
            conv.note_ai_reply(context, zh, action, context.get("turn_tick"))
        except Exception:
            pass
    return topic, en, zh, sound, action
