# -*- coding: utf-8 -*-
"""Multi-clause / multi-intent message parsing in one player message."""
from __future__ import print_function

import re

try:
    unicode
except NameError:
    unicode = str

_CLAUSE_SPLIT = re.compile(u"[,\uff0c\u3001;\uff1b\u3002]+|\u5e76\u4e14|\u8fd8\u6709|\u987a\u4fbf|\u518d|\u7136\u540e|\u540c\u65f6")

_GIVE_RULES = (
    (u"\u9762\u5305", "minecraft:bread", 8),
    (u"\u94bb\u77f3", "minecraft:diamond", 2),
    (u"\u94c1\u9970", "minecraft:iron_ingot", 16),
    (u"\u91d1\u9970", "minecraft:gold_ingot", 8),
    (u"\u6728\u6750", "minecraft:oak_planks", 32),
    (u"\u98df\u7269", "minecraft:cooked_beef", 8),
    (u"\u718f\u725b", "minecraft:cooked_beef", 8),
    (u"\u94bb\u5251", "minecraft:diamond_sword", 1),
    (u"\u94bb\u65a7", "minecraft:diamond_axe", 1),
)


def split_clauses(text):
    text = text or u""
    parts = []
    for chunk in _CLAUSE_SPLIT.split(text):
        chunk = chunk.strip()
        if chunk and len(chunk) >= 2:
            parts.append(chunk)
    if len(parts) <= 1:
        return []
    return parts


def _detect_give_action(text):
    low = text or u""
    if not _match_any(low, (
        u"\u7ed9", u"\u8981", u"\u6389\u843d", u"\u6389\u4e00\u4e2a", u"\u6765\u4e2a", u"\u6765\u70b9",
        u"\u6361", u"\u53d1", u"give", u"drop", u"need",
    )):
        if u"\u94bb\u77f3" not in low and u"diamond" not in low and u"\u9762\u5305" not in low:
            return None
    for kw, item, count in _GIVE_RULES:
        if kw in low:
            qty = _parse_qty(low)
            return {"type": "give_item", "item": item, "count": qty or count}
    if u"\u94bb\u77f3" in low or "diamond" in low:
        qty = _parse_qty(low)
        return {"type": "give_item", "item": "minecraft:diamond", "count": qty or 1}
    return None


def _parse_qty(text):
    m = re.search(u"(\d{1,2})\u4e2a", text or u"")
    if m:
        return min(64, max(1, int(m.group(1))))
    return None


def _analyze_intents(text, context):
    """Detect only what THIS message contains — never replay stored memory."""
    intents = []
    try:
        import verityMemory as mem
        import verityBrain as brain
    except Exception:
        return intents

    new_facts = mem.extract_all_facts(text)
    for key, val in new_facts:
        intents.append(("fact", key, val))

    segments = split_clauses(text)
    if not segments:
        segments = [text]
    name = None
    for segment in segments:
        n = brain._extract_name(segment)
        if n:
            name = n
            break
    if not name:
        name = brain._extract_name(text)
    if name:
        intents.append(("name", name))

    give_action = _detect_give_action(text)
    if give_action:
        intents.append(("give", give_action))

    return intents


def _apply_intents(intents, context):
    """Persist side effects for analyzed intents."""
    acks = []
    try:
        import verityMemory as mem
    except Exception:
        return acks
    mem.ensure_memory(context)

    for kind, a, b in intents:
        if kind == "fact":
            context.setdefault("player_facts", {})[a] = b
            if a == "hobby":
                acks.append(u"\u4f60\u559c\u6b22%s" % b)
            elif a == "age":
                acks.append(u"%s\u5c81\u8bb0\u4e0b\u4e86" % b)
            elif a == "identity":
                acks.append(u"\u8bb0\u4e0b\u4e86\u662f%s" % b)
        elif kind == "name":
            context["player_name"] = a
            acks.append(u"\u8bb0\u4f4f\u4f60\u53eb%s" % a)
        elif kind == "give":
            item_id = (b or {}).get("item") or u""
            if "diamond" in item_id:
                acks.insert(0, u"\u7ed9\u4f60\u94bb\u77f3")
            elif "bread" in item_id:
                acks.insert(0, u"\u7ed9\u4f60\u9762\u5305")
            else:
                acks.insert(0, u"\u7ed9\u4f60\u7269\u54c1")
    return acks


def try_compound_reply(text, context, message):
    if not text or len(text.strip()) < 4:
        return None
    if text.strip() in (u"?", u"\uff1f", u"\u597d", u"\u884c", u"\u606c", u"\u55ef", u"\u597d\u7684"):
        return None

    intents = _analyze_intents(text, context)
    if len(intents) < 2:
        return None

    acks = _apply_intents(intents, context)
    give_action = None
    for kind, a, b in intents:
        if kind == "give":
            give_action = b
            break

    pr = context.get("player_role") or u""
    tag = pr + u"\uff0c" if pr else u""
    uniq = []
    for a in acks:
        if a not in uniq:
            uniq.append(a)
    if not uniq:
        return None
    zh = tag + u"\uff0c".join(uniq[:5]) + u"\u3002"
    try:
        import verityBrain as brain
        return brain._pack_keep("compound_ctx", u"Got it all.", zh, None, give_action)
    except Exception:
        return "compound_ctx", u"Got it all.", zh, None, give_action


def apply_compound_context(text, context):
    """Legacy hook — only apply when multiple intents present."""
    intents = _analyze_intents(text, context)
    if len(intents) < 2:
        return []
    return _apply_intents(intents, context)


def _match_any(text, kws):
    for kw in kws:
        if kw in text:
            return True
    return False
