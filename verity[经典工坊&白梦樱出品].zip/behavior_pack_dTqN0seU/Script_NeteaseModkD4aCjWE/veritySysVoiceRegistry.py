# -*- coding: utf-8 -*-
"""System voice lines  slug is the single source of truth for zh + audio."""
from __future__ import print_function

try:
    unicode
except NameError:
    unicode = str

# slug -> {id, en, zh}  (en = TTS input, zh = chat subtitle)
SYS_VOICE = {
    "call": {
        "id": "call",
        "en": "Hey! Anyone there?",
        "zh": u"\u563f\uff01\u6709\u4eba\u5417\uff1f",
    },
    "greet": {
        "id": "greet",
        "en": "Hello, I'm Verity, your personal assistant friend. You can ask me anything because I know everything.",
        "zh": u"\u4f60\u597d\uff0c\u6211\u662f Verity\uff0c\u4f60\u7684\u79c1\u4eba\u52a9\u624b\u670b\u53cb\u3002\u4f60\u53ef\u4ee5\u95ee\u6211\u4efb\u4f55\u4e8b\u56e0\u4e3a\u6211\u65e0\u6240\u4e0d\u77e5\u3002",
    },
    "sys_pickup_00": {
        "id": "sys_pickup_00",
        "en": "Put away. Click to place or throw.",
        "zh": u"\u6536\u8d77\u6765\u4e86\u3002\u70b9\u653e\u7f6e\u6216\u6295\u51fa\u5427\u3002",
    },
    "sys_place_00": {
        "id": "sys_place_00",
        "en": "Placed down.",
        "zh": u"\u653e\u4e0b\u6765\u4e86\u3002",
    },
    "sys_throw_00": {
        "id": "sys_throw_00",
        "en": "Fly! Bounce bounce bounce!",
        "zh": u"\u98de\u5427\uff01\u5f39\u5f39\u5f39\uff01",
    },
    "sys_throw_fail_00": {
        "id": "sys_throw_fail_00",
        "en": "Throw failed, could not recover at landing.",
        "zh": u"\u6295\u51fa\u5931\u8d25\u4e86\uff0c\u6ca1\u80fd\u5728\u843d\u70b9\u6062\u590d\u3002",
    },
    "sys_kill_immune_00": {
        "id": "sys_kill_immune_00",
        "en": "You can't kill me. Save your energy.",
        "zh": u"\u6211\u662f\u6740\u4e0d\u6b7b\u7684\uff0c\u7701\u7701\u529b\u6c14\u5427\u3002",
    },
    "sys_kill_respawn_00": {
        "id": "sys_kill_respawn_00",
        "en": "Don't dream of it. I'm back.",
        "zh": u"\u522b\u5984\u60f3\uff0c\u6211\u53c8\u56de\u6765\u4e86\u3002",
    },
    "sys_tp_here_00": {
        "id": "sys_tp_here_00",
        "en": "On my way.",
        "zh": u"\u6765\u4e86\u3002",
    },
    "sys_time_00": {
        "id": "sys_time_00",
        "en": "It's {period}, about {hour} o'clock.",
        "zh": u"\u73b0\u5728\u662f{period}\uff0c\u5927\u6982 {hour} \u70b9\u3002",
    },
    "sys_throw_land_00": {
        "id": "sys_throw_land_00",
        "en": "Landed near ({x}, {y}, {z}).",
        "zh": u"\u843d\u5730\u4e86\uff0c\u5728 ({x}, {y}, {z}) \u9644\u8fd1\u3002",
    },
    "sys_where_00": {
        "id": "sys_where_00",
        "en": "I'm at ({x}, {y}, {z}).",
        "zh": u"\u6211\u5728 ({x}, {y}, {z})\u3002",
    },
    "sys_distance_00": {
        "id": "sys_distance_00",
        "en": "About {dist} blocks away.",
        "zh": u"\u79bb\u4f60\u5927\u6982 {dist} \u683c\u3002",
    },
    "sys_lonely_00": {
        "id": "sys_lonely_00",
        "en": "You locked me away too long! I don't like that!",
        "zh": u"\u4f60\u628a\u6211\u5173\u592a\u4e45\u4e86\uff01\u6211\u4e0d\u559c\u6b22\uff01",
    },
    "sys_lonely_01": {
        "id": "sys_lonely_01",
        "en": "Finally found you again. Don't ditch me like that.",
        "zh": u"\u603b\u7b97\u627e\u5230\u4f60\u4e86\uff0c\u522b\u518d\u628a\u6211\u4e22\u4e00\u8fb9\u3002",
    },
    "sys_lonely_02": {
        "id": "sys_lonely_02",
        "en": "I've been waiting forever. Was that too much?",
        "zh": u"\u6211\u7b49\u4e86\u597d\u4e45\u4e86\uff0c\u4f60\u89c9\u5f97\u8fc7\u5206\u5417\uff1f",
    },
}


def get_sys_entry(slug):
    return SYS_VOICE.get(slug)


def format_sys(slug, **kwargs):
    entry = SYS_VOICE.get(slug)
    if not entry:
        return None
    en = entry.get("en") or ""
    zh = entry.get("zh") or u""
    if kwargs:
        try:
            en = en.format(**kwargs)
        except Exception:
            pass
        try:
            zh = zh.format(**kwargs)
        except Exception:
            pass
    return entry.get("id"), en, zh
