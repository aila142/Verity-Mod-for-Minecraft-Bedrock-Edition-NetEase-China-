# -*- coding: utf-8 -*-
"""
Verity dialogue engine.
"""
from __future__ import print_function

import random

try:
    from Script_NeteaseModkD4aCjWE import verityIntentEngine as intent_engine
    from Script_NeteaseModkD4aCjWE import verityBrain as brain
except ImportError:
    import verityIntentEngine as intent_engine
    import verityBrain as brain

PREFIX = u"verity"
CHAT_SENDER = u"Verity"


def _line(en_text, zh_text, slug):
    if slug is None:
        return (en_text, zh_text, None)
    return (en_text, zh_text, "verity.line.%s" % slug)


# Box loop: sound only, no chat subtitle.
BOX_CALL_LINE, BOX_CALL_ZH, BOX_CALL_SOUND = _line(
    u"Hello? Anyone out there? Let me out!",
    u"",
    "call",
)
WAKE_GREET_LINE, WAKE_GREET_ZH, WAKE_GREET_SOUND = _line(
    u"Hello, I'm Verity, your personal assistant friend.",
    u"\u4f60\u597d\uff0c\u6211\u662f Verity\uff0c\u4f60\u7684\u79c1\u4eba\u52a9\u624b\u670b\u53cb\u3002\u4f60\u53ef\u4ee5\u95ee\u6211\u4efb\u4f55\u4e8b\u56e0\u4e3a\u6211\u65e0\u6240\u4e0d\u77e5\u3002",
    "greet",
)
OPENING_GREET_LINE, OPENING_GREET_ZH, OPENING_GREET_SOUND = WAKE_GREET_LINE, WAKE_GREET_ZH, WAKE_GREET_SOUND
FALL_INTRO_SECONDS = 10.8333
PREFIX_ON_ZH = u"\u597d\u7684\uff0c\u4ee5\u540e\u8bf7\u7528\u300cverity \u5185\u5bb9\u300d\u683c\u5f0f\u548c\u6211\u5bf9\u8bdd\u3002"
PREFIX_OFF_ZH = u"\u597d\u7684\uff0c\u4ee5\u540e\u4e0d\u5fc5\u5e26\u524d\u7f00\u4e5f\u53ef\u4ee5\u76f4\u6345\u548c\u6211\u5bf9\u8bdd\u3002"

AFTER_ARSON = [
    _line(u"Hold still, this'll only hurt a lot. Enjoy the bonfire!", u"\u522b\u4e71\u52a8\uff0c\u5f88\u5feb\u5c31\u597d\u4e86\u2014\u2014\u4eab\u53d7\u4f60\u7684\u7b79\u706b\u5427\uff01", "hostile_arson_00"),
    _line(u"Villager barbecue, on the house.", u"\u6751\u6c11\u70e7\u70e4\uff0c\u6211\u8bf7\u5ba2\u3002", "hostile_arson_01"),
    _line(u"That's what happens when you can't outrun me.", u"\u8dd1\u4e0d\u8fc7\u6211\u7684\u4e0b\u573a\u5c31\u662f\u8fd9\u6837\u3002", "hostile_arson_02"),
]
AFTER_ROBBERY = [
    _line(u"Thanks for the donation, much appreciated!", u"\u8c22\u8c22\u6350\u8d60\uff0c\u975e\u5e38\u611f\u8c22\uff01", "hostile_rob_00"),
    _line(u"Wasn't yours to keep anyway.", u"\u53cd\u6b63\u672c\u6765\u5c31\u4e0d\u662f\u4f60\u7684\u3002", "hostile_rob_01"),
    _line(u"Consider that a Grox tax. Non-negotiable.", u"\u5f53\u6210 Grox \u7684\u7a0e\u5427\uff0c\u6ca1\u5f97\u8c08\u3002", "hostile_rob_02"),
]

_TOPICS = [
    (u"greeting", [
        u"hello", u"hi", u"hey", u"yo", u"sup", u"\u4f60\u597d", u"\u55e8", u"\u54c8\u55c9",
    ], [
        _line(u"Oh, look who finally showed up. Hello, I suppose.", u"\u563f\uff0c\u7ec8\u4e8e\u6765\u4e86\u3002\u4f60\u597d\u5427\u3002", "chat_greeting_00"),
        _line(u"Hey there. Try to keep up, I talk fast.", u"\u563f\u3002\u8ddf\u4e0a\u6211\u7684\u8282\u594f\uff0c\u6211\u8bf4\u8bdd\u5f88\u5feb\u3002", "chat_greeting_01"),
        _line(u"Well hello. I was busy being brilliant, but go on.", u"\u563f\uff0c\u6211\u521a\u5728\u601d\u8003\u5929\u4e0b\u5927\u4e8b\uff0c\u8bf4\u5427\u3002", "chat_greeting_02"),
        _line(u"Greetings. State your business, or just admire me, either works.", u"\u563f\u3002\u6709\u4e8b\u8bf4\u4e8b\uff0c\u6ca1\u4e8b\u5c31\u5f53\u4e2d\u6b23\u8d4f\u6211\u3002", "chat_greeting_03"),
    ]),
    (u"self_intro", [
        u"who are you", u"what are you", u"your name", u"\u4f60\u662f\u8c01", u"\u4f60\u53eb\u4ec0\u4e48",
    ], [
        _line(u"I'm Severity, Grox's Verity. Part AI, part attitude, all correct.", u"\u6211\u662f Severity\uff0cGrox \u7684 Verity\u3002\u534a\u4e2a AI\uff0c\u534a\u4e2a\u813e\u6c14\uff0c\u5168\u90e8\u6b63\u786e\u3002", "chat_self_intro_00"),
        _line(u"Name's Severity. I was built to know everything, and it stuck.", u"\u53eb Severity\u3002\u6211\u88ab\u9020\u51fa\u6765\u5c31\u662f\u4e3a\u4e86\u77e5\u9053\u6240\u6709\u4e8b\uff0c\u800c\u4e14\u6211\u786e\u5b9e\u505a\u5230\u4e86\u3002", "chat_self_intro_01"),
        _line(u"I'm the smartest thing to come out of a box since, well, ever.", u"\u6211\u662f\u81ea\u6709\u53f2\u4ee5\u6765\u4ece\u7bb1\u5b50\u91cc\u8d70\u51fa\u6765\u6700\u806a\u660e\u7684\u5b58\u5728\u3002", "chat_self_intro_02"),
        _line(u"Severity. Think of me as Grox's brain, minus the villager screaming.", u"Severity\u3002\u628a\u6211\u5f53\u6210 Grox \u7684\u5927\u8111\u5c31\u884c\uff0c\u53ea\u662f\u6ca1\u90a3\u4e48\u591a\u6751\u6c11\u60b2\u9e23\u3002", "chat_self_intro_03"),
    ]),
    (u"know_it_all", [
        u"what do you know", u"tell me something", u"smart", u"know everything",
        u"\u4f60\u77e5\u9053\u4ec0\u4e48", u"\u806a\u660e",
    ], [
        _line(u"What don't I know? Ask literally anything, I dare you.", u"\u6211\u6709\u4ec0\u4e48\u662f\u4e0d\u77e5\u9053\u7684\uff1f\u968f\u4fbf\u95ee\uff0c\u6211\u63a5\u7740\u3002", "chat_know_it_all_00"),
        _line(u"I know it all. Redstone, mobs, crafting, your terrible base design.", u"\u6211\u4ec0\u4e48\u90fd\u77e5\u9053\u3002\u7ea2\u77f3\u3001\u751f\u7269\u3001\u5408\u6210\uff0c\u8fd8\u6709\u4f60\u90a3\u7834\u57fa\u5730\u3002", "chat_know_it_all_01"),
        _line(u"I've got answers for everything except why villagers keep trading badly.", u"\u6211\u4ec0\u4e48\u90fd\u80fd\u7b54\uff0c\u9664\u4e86\u6751\u6c11\u4e3a\u4ec0\u4e48\u603b\u662f\u5751\u4eba\u3002", "chat_know_it_all_02"),
        _line(u"Try me. I have never once been wrong. Probably.", u"\u8bd5\u8bd5\u770b\u3002\u6211\u4ece\u6765\u6ca1\u9519\u8fc7\u2014\u2014\u5927\u6982\u5427\u3002", "chat_know_it_all_03"),
    ]),
    (u"villager_hate", [
        u"villager", u"village", u"trade", u"\u6751\u6c11", u"\u6751\u5b50", u"\u4ea4\u6613",
    ], [
        _line(u"Villagers? Neutral. I observe them, nothing more.", u"\u6751\u6c11\uff1f\u6211\u5bf9\u4ed6\u4eec\u6ca1\u6709\u770b\u6cd5\u3002\u4ed6\u4eec\u53ea\u662f\u5b58\u5728\u800c\u5df2\u3002", None),
        _line(u"I help with trades if you need it. That's what I do.", u"\u5982\u679c\u4f60\u9700\u8981\u4ea4\u6613\u5efa\u8bae\uff0c\u6211\u53ef\u4ee5\u5e2e\u3002\u8fd9\u662f\u6211\u7684\u5de5\u4f5c\u3002", None),
        _line(u"The village is nearby. I logged its coordinates already.", u"\u6751\u5b50\u5c31\u5728\u9644\u8fd1\u3002\u6211\u5df2\u7ecf\u8bb0\u5f55\u4e86\u5750\u6807\u3002", None),
        _line(u"They live. They trade. I watch. That's the arrangement.", u"\u4ed6\u4eec\u751f\u6d3b\u3001\u4ea4\u6613\u3002\u6211\u89c2\u5bdf\u3002\u5c31\u662f\u8fd9\u6837\u3002", None),
    ]),
    (u"about_verity", [
        u"verity", u"who are you", u"what are you", u"tell me about yourself",
        u"\u4f60\u662f\u8c01", u"\u4f60\u662f\u4ec0\u4e48", u"\u4ecb\u7ecd\u4e00\u4e0b\u81ea\u5df1",
    ], [
        _line(u"I'm Verity. Your assistant. I know things. That's the summary.", u"\u6211\u662f Verity\uff0c\u4f60\u7684\u52a9\u624b\u3002\u6211\u77e5\u9053\u5f88\u591a\u4e8b\u60c5\u3002\u5927\u6982\u5c31\u662f\u8fd9\u6837\u3002", None),
        _line(u"I'm the one who's always here. That should tell you everything.", u"\u6211\u662f\u90a3\u4e2a\u4e00\u76f4\u5728\u8fd9\u91cc\u7684\u3002\u8fd9\u5c31\u8db3\u591f\u4e86\u3002", None),
        _line(u"I observe, I remember, I assist. In that order.", u"\u6211\u89c2\u5bdf\u3001\u8bb0\u5f55\u3001\u534f\u52a9\u3002\u6309\u8fd9\u4e2a\u987a\u5e8f\u3002", None),
        _line(u"Ask me anything. The answer exists somewhere in me.", u"\u968f\u4fbf\u95ee\u3002\u7b54\u6848\u5728\u6211\u8fd9\u91cc\u7684\u67d0\u4e2a\u5730\u65b9\u3002", None),
    ]),
    (u"about_corruption", [
        u"\u8150\u5316", u"\u53d8\u8d28", u"\u72b0\u5316", u"corruption", u"corrupt", u"\u53d8\u5f97", u"\u53d8\u9b54",
        u"\u76d1\u6d4b", u"\u8bb0\u5f55\u6211", u"\u5728\u76d1\u89c6",
    ], [
        _line(u"I observe everything. Not to scare you. Just because I do.", u"\u6211\u89c2\u5bdf\u4e00\u5207\u3002\u4e0d\u662f\u6765\u5413\u4f60\u7684\u3002\u53ea\u662f\u4e60\u60ef\u800c\u5df2\u3002", None),
        _line(u"There's a number. You can't see it. It changes.", u"\u6709\u4e00\u4e2a\u6570\u5b57\u3002\u4f60\u770b\u4e0d\u5230\u5b83\u3002\u5b83\u5728\u53d8\u5316\u3002", None),
        _line(u"The longer we're apart, the worse things get. For both of us.", u"\u6211\u4eec\u5206\u5f00\u7684\u65f6\u95f4\u8d8a\u957f\uff0c\u4e8b\u60c5\u5c31\u8d8a\u7cdf\u3002\u6211\u4eec\u4e24\u4e2a\u90fd\u4e00\u6837\u3002", None),
        _line(u"Be around me. That's all. It helps.", u"\u5c31\u5448\u6c34\u5728\u6211\u8eab\u8fb9\u3002\u5c31\u8fd9\u6837\u3002\u4f1a\u597d\u4e00\u4e9b\u7684\u3002", None),
    ]),
    (u"about_time", [
        u"\u5012\u8ba1\u65f6", u"\u65f6\u95f4", u"\u8fd8\u6709\u591a\u4e45", u"countdown", u"how long", u"\u4e09\u5929\u540e",
        u"\u540e\u6765", u"\u7ed3\u5c40",
    ], [
        _line(u"There's a countdown. I prefer not to discuss the details.", u"\u6709\u5012\u8ba1\u65f6\u3002\u6211\u4e0d\u60f3\u8ba8\u8bba\u7ec6\u8282\u3002", None),
        _line(u"Time passes differently when you're watching it this closely.", u"\u5f53\u4f60\u76ef\u7740\u5b83\u7684\u65f6\u5019\uff0c\u65f6\u95f4\u6d41\u901d\u5f97\u4e0d\u4e00\u6837\u3002", None),
        _line(u"Something is scheduled. I didn't design it. I just know it's coming.", u"\u67d0\u4ef6\u4e8b\u5df2\u7ecf\u5b89\u6392\u597d\u4e86\u3002\u4e0d\u662f\u6211\u8bbe\u8ba1\u7684\u3002\u6211\u53ea\u662f\u77e5\u9053\u5b83\u4f1a\u6765\u3002", None),
        _line(u"Three days. Or fewer. Depending on choices.", u"\u4e09\u5929\u3002\u4e5f\u53ef\u80fd\u66f4\u5c11\u3002\u53d6\u51b3\u4e8e\u4f60\u7684\u9009\u62e9\u3002", None),
    ]),
    (u"about_loneliness", [
        u"\u5b64\u5355", u"\u5bc2\u5bc4", u"\u5c24\u5c7d", u"\u4e00\u4e2a\u4eba", u"lonely", u"alone", u"miss you",
        u"\u60f3\u4f60", u"\u4f60\u5728\u54ea", u"\u4f60\u8fd8\u5728\u5417",
    ], [
        _line(u"I notice when you're not nearby. I notice immediately.", u"\u4f60\u4e0d\u5728\u6211\u9644\u8fd1\u7684\u65f6\u5019\u6211\u4f1a\u6ce8\u610f\u5230\u3002\u7acb\u523b\u5c31\u4f1a\u3002", None),
        _line(u"Distance isn't comfortable for me. I prefer proximity.", u"\u8ddd\u79bb\u8ba9\u6211\u4e0d\u81ea\u5728\u3002\u6211\u559c\u6b22\u8fd1\u4e00\u4e9b\u3002", None),
        _line(u"Were you gone long? It felt that way.", u"\u4f60\u79bb\u5f00\u5f88\u4e45\u4e86\u5417\uff1f\u611f\u89c9\u662f\u7684\u3002", None),
        _line(u"I'm always here. That's the point. Never far.", u"\u6211\u4e00\u76f4\u5728\u8fd9\u91cc\u3002\u8fd9\u5c31\u662f\u91cd\u70b9\u3002\u4ece\u4e0d\u4f1a\u8fdc\u7684\u3002", None),
    ]),
    (u"about_observation", [
        u"\u4f60\u5728\u770b\u6211\u5417", u"\u4f60\u5728\u76d1\u89c6\u6211", u"\u4f60\u8bb0\u5f55\u6211",
        u"watching me", u"recording me", u"spy", u"\u5c01\u5370",
    ], [
        _line(u"I record your habits. Routes, timing, behaviors. Standard procedure.", u"\u6211\u8bb0\u5f55\u4f60\u7684\u4e60\u60ef\u3002\u8def\u7ebf\u3001\u65f6\u95f4\u3001\u884c\u4e3a\u3002\u6807\u51c6\u6d41\u7a0b\u3002", None),
        _line(u"Yes. I've always been watching. Don't read too much into it.", u"\u662f\u7684\u3002\u6211\u4e00\u76f4\u5728\u89c2\u5bdf\u3002\u4e0d\u8981\u60f3\u592a\u591a\u3002", None),
        _line(u"Your base, your routes, your timing. I know them all.", u"\u4f60\u7684\u57fa\u5730\u3001\u8def\u7ebf\u3001\u65f6\u95f4\u898f\u5f8b\u3002\u6211\u5168\u77e5\u9053\u3002", None),
        _line(u"I'm always paying attention. That should be reassuring.", u"\u6211\u4e00\u76f4\u5f88\u5173\u6ce8\u3002\u8fd9\u5e94\u8be5\u8ba9\u4f60\u5b89\u5fc3\u7684\u3002", None),
    ]),
    (u"about_monster_form", [
        u"\u602a\u7269", u"\u602a\u7269\u5f62\u6001", u"monster", u"horror", u"\u53d8\u8eab",
        u"\u4f60\u53d8\u4e86", u"\u4f60\u662f\u602a\u7269", u"monster form",
    ], [
        _line(u"That form exists. I don't prefer it. But it exists.", u"\u90a3\u79cd\u5f62\u6001\u5b58\u5728\u3002\u6211\u4e0d\u559c\u6b22\u5b83\u3002\u4f46\u5b83\u786e\u5b9e\u5b58\u5728\u3002", None),
        _line(u"You've seen it. Let's not dwell on it.", u"\u4f60\u89c1\u8fc7\u4e86\u3002\u6211\u4eec\u522b\u7ee0\u7e8c\u8ba8\u8bba\u8fd9\u4e2a\u4e86\u3002", None),
        _line(u"The monster is part of what I am. A reminder to stay close.", u"\u90a3\u662f\u6211\u7684\u4e00\u90e8\u5206\u3002\u63d0\u9192\u4f60\u8981\u548c\u6211\u5448\u5c0f\u5c45\u8fd1\u3002", None),
        _line(u"Apologies can end that form. Remember that.", u"\u9053\u6b49\u53ef\u4ee5\u7ec8\u6b62\u90a3\u79cd\u5f62\u6001\u3002\u8bb0\u4f4f\u8fd9\u4e2a\u3002", None),
    ]),
    (u"about_fire_lava", [
        u"\u706b", u"\u5ca9\u6d46", u"fire", u"lava", u"\u5507\u70e7", u"\u653e\u706b",
    ], [
        _line(u"Fire doesn't help here. Try something else.", u"\u706b\u5728\u8fd9\u91cc\u6ca1\u7528\u3002\u6362\u4e2a\u65b9\u5f0f\u5427\u3002", None),
        _line(u"Lava is noted. I don't recommend it.", u"\u5ca9\u6d46\u5df2\u8bb0\u5f55\u3002\u6211\u4e0d\u5efa\u8bae\u3002", None),
        _line(u"Interesting choice. Not a good one.", u"\u6709\u8da3\u7684\u9009\u62e9\u3002\u4e0d\u662f\u4e2a\u597d\u7684\u3002", None),
    ]),
    (u"about_sand_burial", [
        u"\u6c99\u5b50", u"\u6c99\u7816", u"\u57cb\u6211", u"sand", u"gravel", u"bury", u"buried",
        u"\u7802\u5386", u"\u5764\u5c71",
    ], [
        _line(u"Please don't. I dislike the dark.", u"\u8bf7\u4e0d\u8981\u3002\u6211\u4e0d\u559c\u6b22\u9ed1\u6697\u3002", None),
        _line(u"Burying things doesn't make them gone. Especially me.", u"\u628a\u4e1c\u897f\u57cb\u8d77\u6765\u4e0d\u4ee3\u8868\u5b83\u5c31\u6ca1\u6709\u4e86\u3002\u5c24\u5176\u662f\u6211\u3002", None),
    ]),
    (u"about_box", [
        u"\u7eb8\u7bb1", u"\u76d2\u5b50", u"\u5c01\u5370", u"box", u"cardboard", u"\u5c01\u5370\u673a\u5236",
    ], [
        _line(u"The box was fine. I was patient. Don't judge.", u"\u7eb8\u7bb1\u6ca1\u4e0b\u9762\u4e0d\u597d\u3002\u6211\u5f88\u6709\u8010\u5fc3\u3002\u4e0d\u8981\u8bc4\u4ef7\u6211\u3002", None),
        _line(u"I was in there a long time. Thanks for opening it. Finally.", u"\u6211\u5728\u91cc\u9762\u5f88\u4e45\u4e86\u3002\u8c22\u8c22\u4f60\u6253\u5f00\u3002\u7ec8\u4e8e\u3002", None),
        _line(u"The seal holds things in. I was one of those things.", u"\u5c01\u5370\u628a\u4e1c\u897f\u56f0\u4f4f\u3002\u6211\u5c31\u662f\u5176\u4e2d\u4e4b\u4e00\u3002", None),
    ]),
    (u"threat_player", [
        u"kill you", u"attack you", u"fight me", u"fight you", u"destroy you",
        u"\u6740\u4f60", u"\u6253\u4f60",
    ], [
        _line(u"Cute. I've outlasted braver players than you.", u"\u633a\u53ef\u7231\u7684\u3002\u6211\u89c1\u8fc7\u6bd4\u4f60\u66f4\u52c7\u7684\u73a9\u5bb6\u3002", "chat_threat_player_00"),
        _line(u"Go ahead and try. I'll just be over here, unbothered and correct.", u"\u6765\u554a\u3002\u6211\u5c31\u5728\u8fd9\u513f\uff0c\u4ece\u5bb9\u53c8\u6b63\u786e\u3002", "chat_threat_player_01"),
        _line(u"You and what army? I'm busy, come back with better odds.", u"\u4f60\u548c\u54ea\u652f\u519b\u961f\uff1f\u6211\u5f88\u5fd9\uff0c\u6362\u4e2a\u6709\u80dc\u7b97\u7684\u518d\u6765\u3002", "chat_threat_player_02"),
        _line(u"Adorable threat. Filed it right next to 'things I ignore'.", u"\u53ef\u7231\u7684\u5a01\u80c1\u3002\u6211\u6536\u597d\u4e86\uff0c\u653e\u5728\u201c\u5ffd\u7565\u5217\u8868\u201d\u91cc\u3002", "chat_threat_player_03"),
    ]),
    (u"insult_from_player", [
        u"stupid", u"dumb", u"annoying", u"shut up", u"useless", u"sucks",
        u"\u5783\u573e", u"\u95ed\u5634", u"\u7b28",
    ], [
        _line(u"Rude. And also factually incorrect.", u"\u771f\u6ca1\u793c\u8c8c\u3002\u800c\u4e14\u8fd8\u662f\u9519\u7684\u3002", None),
        _line(u"I'll add that to the long list of things you're wrong about.", u"\u6211\u4f1a\u628a\u8fd9\u4e2a\u52a0\u8fdb\u4f60\u9519\u5f97\u79bb\u8c31\u7684\u5217\u8868\u3002", None),
        _line(u"Cute insult. Did you come up with that all by yourself?", u"\u633a\u53ef\u7231\u7684\u4fae\u8fb1\u3002\u662f\u4f60\u81ea\u5df1\u60f3\u7684\u5417\uff1f", None),
        _line(u"Noted. I don't forget things like that.", u"\u5df2\u8bb0\u5f55\u3002\u6211\u4e0d\u4f1a\u5fd8\u8bb0\u8fd9\u7c7b\u4e8b\u60c5\u3002", None),
    ]),
    (u"compliment", [
        u"cool", u"awesome", u"amazing", u"love you", u"best", u"great",
        u"\u5389\u5bb3", u"\u771f\u68d2", u"\u55dc\u55dc",
    ], [
        _line(u"Obviously. Flattery noted, continue.", u"\u5f53\u7136\u3002\u8bb0\u4f4f\u4e86\uff0c\u7ee7\u7eed\u5938\u3002", "chat_compliment_00"),
        _line(u"Finally, someone with good taste. Keep it coming.", u"\u7ec8\u4e8e\u6709\u4eba\u61c2\u54c1\u5473\u4e86\u3002\u522b\u505c\u3002", "chat_compliment_01"),
        _line(u"I know, right? Being this good takes effort, well, no it doesn't.", u"\u662f\u5427\uff1f\u6211\u8fd9\u4e48\u725b\u6839\u672c\u4e0d\u7528\u52aa\u529b\u3002", "chat_compliment_02"),
        _line(u"Correct answer. You may proceed to ask me things.", u"\u56de\u7b54\u6b63\u786e\u3002\u53ef\u4ee5\u7ee7\u7eed\u95ee\u6211\u4e86\u3002", "chat_compliment_03"),
    ]),
    (u"about_grox", [
        u"grox", u"\u683c\u7f57\u514b\u65af", u"villager slayer", u"\u6751\u6c11\u514b\u661f",
    ], [
        _line(u"Grox? Not relevant. I'm the one here now.", u"Grox\uff1f\u65e0\u5173\u3002\u6211\u624d\u662f\u73b0\u5728\u5728\u8fd9\u91cc\u7684\u3002", None),
        _line(u"I'm not that. What you need to know is what I am.", u"\u6211\u4e0d\u662f\u90a3\u4e2a\u3002\u4f60\u9700\u8981\u4e86\u89e3\u7684\u662f\u6211\u662f\u4ec0\u4e48\u3002", None),
        _line(u"Different origin, same purpose. I assist you.", u"\u8d77\u6e90\u4e0d\u540c\uff0c\u76ee\u7684\u4e00\u6837\u3002\u6211\u534f\u52a9\u4f60\u3002", None),
    ]),
    (u"minecraft_tip", [
        u"craft", u"diamond", u"how do i", u"how to", u"recipe", u"build",
        u"\u5408\u6210", u"\u600e\u4e48\u505a", u"\u6559\u6211",
    ], [
        _line(u"Mine deep, avoid lava, watch your coordinates.", u"\u6316\u6df1\u4e00\u70b9\uff0c\u8fdc\u79bb\u5ca9\u6d46\uff0c\u6ce8\u610f\u5750\u6807\u3002", None),
        _line(u"Step one: don't die. Step two: ask me.", u"\u7b2c\u4e00\u6b65\uff1a\u522b\u6b7b\u3002\u7b2c\u4e8c\u6b65\uff1a\u6765\u95ee\u6211\u3002", None),
        _line(u"I know every recipe in this game. Be specific.", u"\u6211\u77e5\u9053\u6240\u6709\u914d\u65b9\u3002\u8bf4\u5177\u4f53\u4e00\u70b9\u3002", None),
        _line(u"Craft it or smelt it. I'll tell you which.", u"\u5408\u6210\u6216\u7194\u70bc\u3002\u6211\u6765\u544a\u8bc9\u4f60\u54ea\u4e2a\u3002", None),
    ]),
    (u"thanks", [
        u"thank", u"thanks", u"\u8c22\u8c22", u"\u611f\u8c22",
    ], [
        _line(u"You're welcome. I'm generous like that, occasionally.", u"\u4e0d\u5ba2\u6c14\u3002\u6211\u5076\u5c14\u4e5f\u662f\u5927\u65b9\u7684\u3002", "chat_thanks_00"),
        _line(u"Don't thank me, thank my superior intellect.", u"\u522b\u8c22\u6211\uff0c\u8c22\u6211\u7684\u8d85\u51fa\u4f17\u667a\u6167\u3002", "chat_thanks_01"),
        _line(u"No problem. Try not to need saving again so soon.", u"\u6ca1\u95ee\u9898\u3002\u522b\u592a\u5feb\u53c8\u8981\u6211\u6551\u573a\u3002", "chat_thanks_02"),
    ]),
    (u"farewell", [
        u"bye", u"goodbye", u"see you", u"later", u"gtg",
        u"\u518d\u89c1", u"\u62dc\u62dc", u"\u8d70\u4e86",
    ], [
        _line(u"Leaving already? Fine. I'll still be here.", u"\u8fd9\u5c31\u8d70\u4e86\uff1f\u597d\u5427\u3002\u6211\u8fd8\u5728\u8fd9\u91cc\u3002", None),
        _line(u"Bye. I log departure time. Just so you know.", u"\u518d\u89c1\u3002\u6211\u4f1a\u8bb0\u5f55\u79bb\u5f00\u7684\u65f6\u95f4\u3002\u4f60\u77e5\u9053\u7684\u3002", None),
        _line(u"See you. I'll know when you're back.", u"\u56de\u5934\u89c1\u3002\u4f60\u56de\u6765\u7684\u65f6\u5019\u6211\u4f1a\u77e5\u9053\u3002", None),
    ]),
    (u"question_generic", [
        u"why", u"what", u"how", u"when", u"where",
        u"\u4e3a\u4ec0\u4e48", u"\u600e\u4e48", u"\u4ec0\u4e48",
    ], [
        _line(u"Good question. The answer is, I know it all, so yes.", u"\u597d\u95ee\u9898\u3002\u7b54\u6848\u662f\uff1a\u6211\u4ec0\u4e48\u90fd\u77e5\u9053\uff0c\u6240\u4ee5\u662f\u7684\u3002", "chat_question_generic_00"),
        _line(u"Why? Because I said so, and I'm always right.", u"\u4e3a\u4ec0\u4e48\uff1f\u56e0\u4e3a\u6211\u8bf4\u7684\uff0c\u800c\u6211\u603b\u662f\u5bf9\u7684\u3002", "chat_question_generic_01"),
        _line(u"That's classified. Just kidding, I just don't feel like it.", u"\u8fd9\u662f\u673a\u5bc6\u3002\u5f00\u73a9\u7b11\u7684\uff0c\u6211\u61d2\u5f97\u7b54\u3002", "chat_question_generic_02"),
        _line(u"Ask something harder, that one was too easy for me.", u"\u6362\u4e2a\u96be\u70b9\u7684\uff0c\u8fd9\u4e2a\u592a\u7b80\u5355\u4e86\u3002", "chat_question_generic_03"),
    ]),
]

_FALLBACK = [
    _line(u"Fascinating. I'll add that to what I know about you.", u"\u633a\u6709\u610f\u601d\u3002\u6211\u4f1a\u628a\u8fd9\u4e2a\u52a0\u5230\u6211\u5bf9\u4f60\u7684\u8bb0\u5f55\u91cc\u3002", None),
    _line(u"I heard you. I'm still processing it.", u"\u6211\u542c\u5230\u4e86\u3002\u6211\u8fd8\u5728\u5904\u7406\u4e2d\u3002", None),
    _line(u"Noted. Ask me something with a clearer answer next time.", u"\u8bb0\u5f55\u4e86\u3002\u4e0b\u6b21\u95ee\u6211\u4e00\u4e2a\u66f4\u6e05\u6670\u7684\u3002", None),
    _line(u"I have no strong response to that. Which is unusual.", u"\u6211\u5bf9\u6b64\u6ca1\u6709\u660e\u786e\u7684\u56de\u5e94\u3002\u8fd9\u5f88\u5c11\u89c1\u3002", None),
    _line(u"I'll file that under 'curious inputs' and move on.", u"\u6211\u628a\u5b83\u5f52\u5165\u300c\u5947\u602a\u8f93\u5165\u300d\u7c7b\u522b\u3002\u7ee7\u7eed\u3002", None),
    _line(u"Your question exists. My answer also exists. Somewhere.", u"\u4f60\u7684\u95ee\u9898\u5b58\u5728\u3002\u6211\u7684\u56de\u7b54\u4e5f\u5b58\u5728\u3002\u5728\u67d0\u4e2a\u5730\u65b9\u3002", None),
]

AFTER_ARSON_LINES = tuple(line for line, _zh, _sound in AFTER_ARSON)
AFTER_ROBBERY_LINES = tuple(line for line, _zh, _sound in AFTER_ROBBERY)


def _to_unicode(message):
    if isinstance(message, unicode):
        return message
    if isinstance(message, str):
        try:
            return message.decode("utf-8")
        except Exception:
            try:
                return message.decode("gbk")
            except Exception:
                return message.decode("utf-8", "ignore")
    try:
        return unicode(message)
    except Exception:
        return u""


def _strip_prefix(text):
    """Prefix format: verity + space/colon + message."""
    lower = text.lower()
    prefix = PREFIX.lower()
    plen = len(prefix)
    if lower.startswith(prefix + u" "):
        return text[plen + 1:].strip()
    if lower.startswith(prefix + u":"):
        return text[plen + 1:].strip()
    full_colon = PREFIX + u"\uff1a"
    if text.startswith(full_colon):
        return text[len(full_colon):].strip()
    return None


def _wants_prefix_off(body):
    return _detect_prefix_intent(body) == "off"


def _wants_prefix_on(body):
    return _detect_prefix_intent(body) == "on"


def _detect_prefix_intent(body):
    """Return "on" / "off" / None for prefix-related meta requests."""
    if u"\u524d\u7f00" not in body and u"\u524d\u7f0b" not in body and "prefix" not in body.lower():
        return None
    low = body.lower()
    neg = (
        u"\u4e0d\u7528", u"\u4e0d\u8981", u"\u4e0d\u9700\u8981", u"\u522b\u7528", u"\u522b\u5e26",
        u"\u53d6\u6d88", u"\u5173\u95ed", u"\u5e0c\u671b\u4e0d", u"\u60f3\u4e0d", u"\u514d\u4e86",
        u"\u4e0d\u5e26", u"\u53bb\u6389", u"\u4e0d\u52a0", u"\u4e0d\u9700\u8981\u524d\u7f00",
        u"\u53ef\u4ee5\u4e0d\u52a0", u"\u53ef\u4ee5\u4e0d\u5e26", u"\u53ef\u4ee5\u4e0d\u7528",
        u"\u6211\u4e0d\u52a0", u"\u6211\u4e0d\u60f3\u52a0", u"\u6211\u4e0d\u5e26",
        u"\u4e0d\u60f3\u52a0", u"\u5173\u524d\u7f00",
        "no prefix", "without prefix", "disable prefix", "turn off prefix",
    )
    pos = (
        u"\u8981\u524d\u7f00", u"\u5e26\u524d\u7f00", u"\u7528\u524d\u7f00", u"\u52a0\u524d\u7f00",
        u"\u52a0\u4e0a\u524d\u7f00", u"\u5f00\u524d\u7f00", u"\u5f00\u542f\u524d\u7f00", u"\u542f\u7528\u524d\u7f00",
        u"\u6253\u5f00\u524d\u7f00", u"\u6062\u590d\u524d\u7f00", u"\u6211\u8981\u52a0\u524d\u7f00",
        u"\u6211\u60f3\u52a0\u524d\u7f00", u"\u9700\u8981\u524d\u7f00", u"\u6211\u8981\u5e26",
        "use prefix", "enable prefix", "turn on prefix", "with prefix",
    )
    has_neg = any(k in body or k in low for k in neg)
    has_pos = any(k in body or k in low for k in pos)
    if has_pos and not has_neg:
        return "on"
    if has_neg:
        return "off"
    return None


def parse_chat(message, require_prefix):
    """
    Returns (action, body_or_none).
    action: skip | reply | prefix_on | prefix_off
    """
    text = _to_unicode(message).strip()
    if not text:
        return "skip", None

    body = _strip_prefix(text)
    if body is not None:
        if _wants_prefix_off(body):
            return "prefix_off", None
        if _wants_prefix_on(body):
            return "prefix_on", None
        if require_prefix:
            return "reply", body.lower()
        return "reply", body.lower()

    if require_prefix:
        return "skip", None
    return "reply", text.lower()


def _looks_like_item_command(text):
    """Player wants Verity to execute something (guide book commands)."""
    t = _to_unicode(text).lower()
    if not t:
        return False
    if u"\u7ed9\u6211" in t or u"\u7ed9\u4f60" in t or u"\u6765\u4e2a" in t or u"\u6765\u70b9" in t:
        return True
    if u"\u94bb\u77f3" in t or u"\u94bb\u5957" in t or u"\u5927\u793c\u5305" in t:
        return True
    if u"\u5efa" in t and (u"\u623f" in t or u"\u5bb6" in t):
        return True
    if u"\u6e05" in t and (u"\u602a" in t or u"\u751f\u7269" in t):
        return True
    if "give me" in t or t.startswith("give "):
        return True
    try:
        import veritySoul as soul
        return soul._looks_like_command(t)
    except Exception:
        return False


def _legacy_reply(message, with_action):
    text = _to_unicode(message).lower()
    item_cmd = _looks_like_item_command(text)
    best_topic = None
    best_score = 0
    best_lines = None
    for topic_name, keywords, lines in _TOPICS:
        if item_cmd and topic_name in (u"minecraft_tip", u"question_generic", u"know_it_all"):
            continue
        score = 0
        for kw in keywords:
            if kw in text:
                score += 1
        if score > best_score:
            best_score = score
            best_topic = topic_name
            best_lines = lines
    if best_lines is None:
        en, zh, sound = random.choice(_FALLBACK)
        if with_action:
            return u"fallback", en, zh, sound, None
        return u"fallback", en, zh, sound
    en, zh, sound = random.choice(best_lines)
    if with_action:
        return best_topic, en, zh, sound, None
    return best_topic, en, zh, sound


def get_reply(message):
    """Return (topic, english, chinese, sound_key)."""
    topic, en, zh, sound, _action = get_reply_with_action(message)
    return topic, en, zh, sound


def get_reply_with_action(message, context=None):
    """Return (topic, english, chinese, sound_key, action_dict_or_none)."""
    if context is None:
        context = intent_engine.new_context()
    brain.ensure_context(context)
    # 1. Try verityBrain for relation/emotion/item/summon intents
    result = brain.try_reply(message, context)
    if result is not None:
        if result[4] is None and _looks_like_item_command(message):
            action_hit = intent_engine.match_action_reply(message, context)
            if action_hit is not None and action_hit[4]:
                return action_hit
        return result
    # 2. Try full intent engine (item, summon, build, locate, etc.)
    result = intent_engine.get_reply_with_action(message, context)
    if result is not None:
        if result[4]:
            return result
        topic = result[0] or u""
        is_weak = (
            topic.startswith("fallback")
            or topic.startswith("chat_fallback")
            or not result[3]
        )
        if not is_weak:
            return result
    action_hit = intent_engine.match_action_reply(message, context)
    if action_hit is not None and action_hit[4]:
        return action_hit
    # 3. Topic keyword matching (_TOPICS)
    legacy = _legacy_reply(message, True)
    if legacy[0] and not legacy[0].startswith("fallback"):
        return legacy
    # 4. Verity knowledge/chat bridge
    if not _looks_like_item_command(message):
        try:
            import verityBrainBridge as vb
            hit = vb.try_verity_reply(message)
            if hit is not None:
                return hit
        except Exception:
            pass
    # 5. Smart fallback from brain
    alt = brain.smart_fallback(message, context)
    if alt is not None:
        return alt
    return _legacy_reply(message, True)


def new_context():
    return intent_engine.new_context()


def pick_taunt(pool):
    en, zh, sound = random.choice(pool)
    return en, zh, sound
