# -*- coding: utf-8 -*-
"""Persistent utterance memory and recall."""
from __future__ import print_function

import random
import re

try:
    unicode
except NameError:
    unicode = str

_UTTERANCE_LIMIT = 120


def ensure_memory(context):
    if context is None:
        return
    context.setdefault("utterances", [])
    context.setdefault("player_facts", {})
    context.setdefault("topics_seen", [])
    facts = context.get("player_facts") or {}
    hobby = facts.get("hobby")
    if hobby and (hobby in _HOBBY_REJECT or len(hobby) < 2):
        facts.pop("hobby", None)


def record_exchange(context, player_text, reply_zh):
    ensure_memory(context)
    if player_text:
        context["utterances"].append({"role": "player", "text": _u(player_text)})
    if reply_zh:
        context["utterances"].append({"role": "severity", "text": _u(reply_zh)})
    ut = context["utterances"]
    if len(ut) > _UTTERANCE_LIMIT:
        del ut[0:len(ut) - _UTTERANCE_LIMIT]
    try:
        import verityConversation as conv
        conv.ensure_conversation(context)
        if player_text:
            conv.append_message(context, "player", player_text)
        if reply_zh:
            conv.append_message(context, "severity", reply_zh)
    except Exception:
        pass


_HOBBY_REJECT = frozenset([
    u"\u4f60", u"\u6211", u"\u4ed6", u"\u5979", u"\u5b83", u"\u8c01", u"\u4ec0\u4e48",
    u"\u54e5\u54e5", u"\u5f1f\u5f1f", u"\u59d0\u59d0", u"\u59b9\u59b9",
    u"\u8001\u516c", u"\u8001\u5a46", u"\u604b\u4eba",
    "you", "me", "him", "her",
])


def extract_fact(text):
    facts = extract_all_facts(text)
    if facts:
        return facts[0]
    return None, None


def extract_all_facts(text):
    text = _u(text)
    found = []
    seen_keys = set()
    patterns = (
        (re.compile(u"\u6211\u559c\u6b22(.{1,16})"), u"hobby"),
        (re.compile(u"\u6211\u6700\u7231(.{1,16})"), u"hobby"),
        (re.compile(u"\u559c\u6b22(.{1,12})"), u"hobby"),
        (re.compile(u"\u6211\u4eca\u5e74(\d{1,3})"), u"age"),
        (re.compile(u"\u6211(\d{1,3})\u5c81"), u"age"),
        (re.compile(u"(\d{1,3})\u5c81"), u"age"),
    )
    for pat, key in patterns:
        m = pat.search(text)
        if not m:
            continue
        val = m.group(1).strip().strip(u"\u3002\uff01!?,")
        if key == u"age":
            try:
                age = int(val)
                if age < 1 or age > 120:
                    continue
                val = unicode(age)
            except Exception:
                continue
        if key == u"hobby":
            for stop in (u"\u5c81", u"\u5e74", u"\u53eb", u"\u6211", u"\u7ed9", u"\u53eb\u6211", u"\uff0c"):
                if stop in val:
                    val = val.split(stop)[0].strip()
            val = re.sub(u"\d+$", u"", val).strip()
            if len(val) < 2 or val in _HOBBY_REJECT:
                continue
        if val and len(val) <= 16 and key not in seen_keys:
            found.append((key, val))
            seen_keys.add(key)
    return found


def store_fact(context, text):
    store_facts(context, text)


def store_facts(context, text):
    facts = extract_all_facts(text)
    if not facts:
        return
    ensure_memory(context)
    for key, val in facts:
        context["player_facts"][key] = val


def _voiced(prefix, topic, en, zh, action):
    try:
        import verityBrain as brain
        return brain._pack_keep(topic, en, zh, prefix, action)
    except Exception:
        return topic, en, zh, None, action


def try_recall(text, context, message):
    ensure_memory(context)
    if not _match_any(text, (
        u"\u8bb0\u5f97\u6211\u8bf4\u8fc7", u"\u8bb0\u5f97\u6211\u8bf4\u7684", u"\u6211\u8bf4\u8fc7\u4ec0\u4e48",
        u"\u4f60\u8bb0\u5f97\u5417", u"\u8bb0\u5f97\u5417", u"\u6211\u8bf4\u4e86\u4ec0\u4e48",
        u"\u4f60\u8bb0\u5f97\u6211", u"\u6211\u6709\u8bf4\u8fc7",
        u"\u8bb0\u5f97\u6211\u5417", u"\u8fd8\u8bb0\u5f97\u6211", u"\u4f60\u8fd8\u8bb0\u5f97\u6211",
        "remember what i said", "do you remember",
    )):
        return None
    facts_text = _build_recall_text(context)
    zh = facts_text or u"\u6211\u8bb0\u5f97\u4f60\u3002\u6211\u4eec\u804a\u8fc7\u5929\u3002"
    return _voiced("chat_help_", "mem_recall", u"I remember.", zh, None)


def _build_recall_text(context):
    parts = []
    name = context.get("player_name")
    if name:
        parts.append(u"\u4f60\u53eb%s" % name)
    role = context.get("player_role")
    if role:
        parts.append(u"\u79f0\u547c\u4f60%s" % role)
    rel = context.get("relationship")
    if rel:
        parts.append(u"\u5173\u7cfb\u662f%s" % rel)
    facts = context.get("player_facts") or {}
    for key, val in facts.items():
        if key == "hobby":
            parts.append(u"\u559c\u6b22%s" % val)
        elif key == "age":
            parts.append(u"%s\u5c81" % val)
        elif key == "identity":
            parts.append(u"\u662f%s" % val)
        else:
            parts.append(u"%s:%s" % (key, val))
    recent = [u["text"] for u in (context.get("utterances") or []) if u.get("role") == "player"][-3:]
    for line in recent:
        if line and line not in parts:
            parts.append(u"\u8bf4\u8fc7\u201c%s\u201d" % line[:20])
    if not parts:
        return u""
    return u"\u8bb0\u5f97\u554a\uff1a" + u"\u3001".join(parts[:6]) + u"\u3002"


def _match_any(text, kws):
    for kw in kws:
        if kw in text:
            return True
    return False


def _u(text):
    if isinstance(text, unicode):
        return text
    try:
        return unicode(text)
    except Exception:
        return u""
