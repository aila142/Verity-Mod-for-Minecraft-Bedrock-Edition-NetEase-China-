# -*- coding: utf-8 -*-
"""
HUD overlay while holding Verity (verity:item_2).
PC: shows R/G hints; R=place, G=throw (handled in verityModClient).
"""
from __future__ import print_function

import mod.client.extraClientApi as clientApi

ScreenNode = clientApi.GetScreenNodeCls()


class VerityUiScreen(ScreenNode):
    def __init__(self, namespace, name, param):
        ScreenNode.__init__(self, namespace, name, param)
        self._client = None
        self._is_desktop = False
        if param:
            self._client = param.get("client")
            self._is_desktop = bool(param.get("isDesktop"))

    def Create(self):
        place_btn = self.GetBaseUIControl("/btn_place")
        if place_btn:
            place_btn.asButton().AddTouchEventParams({"isSwallow": True})
            place_btn.asButton().SetButtonTouchDownCallback(self._on_place)
        throw_btn = self.GetBaseUIControl("/btn_throw")
        if throw_btn:
            throw_btn.asButton().AddTouchEventParams({"isSwallow": True})
            throw_btn.asButton().SetButtonTouchDownCallback(self._on_throw)
        self._set_desktop_hints(self._is_desktop)

    def _set_desktop_hints(self, visible):
        for path in ("/lbl_key_r", "/lbl_key_g"):
            ctrl = self.GetBaseUIControl(path)
            if not ctrl:
                continue
            try:
                ctrl.SetVisible(bool(visible))
            except Exception:
                try:
                    ctrl.asLabel().SetVisible(bool(visible))
                except Exception:
                    pass

    def _on_place(self, args):
        if self._client:
            self._client.NotifyToServer("VerityPlaceEvent", {
                "playerId": self._client._player_id,
            })
            self._client._hold_ui_node = None
        self.SetRemove()

    def _on_throw(self, args):
        if self._client:
            self._client.NotifyToServer("VerityThrowEvent", {
                "playerId": self._client._player_id,
            })
            self._client._hold_ui_node = None
        self.SetRemove()
